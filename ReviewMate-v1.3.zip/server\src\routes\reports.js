const express = require('express');
const { getDb } = require('../db/init');
const { getAiConfig } = require('../utils/aiConfig');
const analyst = require('../services/analyst');
const reviewer = require('../services/reviewer');
const collector = require('../services/collector');

const router = express.Router();

/**
 * 使用 AI 生成报告内容
 * @returns {string|null} AI 生成的 Markdown 内容，失败返回 null
 */
async function generateReportWithAI(reportType, stats, startDate, endDate, goals = []) {
  const aiConfig = getAiConfig();
  if (!aiConfig.apiKey) return null;

  const typeLabel = { weekly: '周报', monthly: '月报', summary: '工作总结' }[reportType] || '复盘报告';

  // 构建给 AI 的 prompt
  const goalText = goals.map(g => {
    const pct = g.target_value > 0 ? Math.round(g.actual_value / g.target_value * 100) : 0;
    return `- ${g.title}: ${pct}% (${g.actual_value}/${g.target_value} ${g.metric}) | 权重${g.weight} | ${g.status}`;
  }).join('\n');

  const tagsText = Object.entries(stats.tag_distribution || {})
    .sort((a, b) => b[1] - a[1])
    .map(([tag, count]) => `  - ${tag}: ${count}项 (${((count / stats.total_tasks) * 100).toFixed(1)}%)`)
    .join('\n');

  const projectsText = Object.entries(stats.project_distribution || {})
    .sort((a, b) => b[1] - a[1])
    .map(([proj, count]) => {
      const hours = (stats.project_hours || {})[proj] || 0;
      return `  - ${proj}: ${count}项任务, ${Number(hours).toFixed(2)}小时`;
    }).join('\n');

  const prompt = `请根据以下工作数据，生成一份专业的${typeLabel}。

## 基本信息
- 报告类型：${typeLabel}
- 时间周期：${startDate} 至 ${endDate}
- 工作日数：${stats.work_days}天

## 核心数据
- 总任务数：${stats.total_tasks}项
- 已完成：${stats.completed_tasks}项
- 完成率：${Math.round(stats.completion_rate * 100)}%
- 总工时：${Number(stats.total_hours).toFixed(2)}小时
- 日均产出密度：${stats.output_density}项/天
${stats.estimation_accuracy > 0 ? `- 预估准确率：${Math.round(stats.estimation_accuracy * 100)}%` : ''}
${stats.goal_achievement_rate > 0 ? `- 目标达成率：${Math.round(stats.goal_achievement_rate * 100)}%` : ''}

## 项目分布
${projectsText || '无项目数据'}

## 工作类型分布（标签）
${tagsText || '无标签数据'}

## 目标进度
${goalText || '无目标数据'}

## 亮点
${(stats.highlights || []).map(h => `- ${h}`).join('\n') || '无'}

## 待改进
${(stats.lowlights || []).map(l => `- ${l}`).join('\n') || '无'}

---
请按照以下结构生成报告（Markdown 格式），使用具体数据支撑每项结论，给出有洞察力的分析和可操作的建议：

${reportType === 'weekly' ? `
# 📊 周报 (${startDate} ~ ${endDate})
## 本周完成
（按项目分组，列出主要产出和关键成果）
## 未完成事项及原因
（分析未完成的原因，给出建议）
## 时间投入分布
（分析工作类型占比，评价时间利用效率）
## 关键数据
（重要指标速览 + 数据解读）
## 复盘建议
（基于数据的改进建议，具体可操作）
## 下周计划
` : reportType === 'monthly' ? `
# 📊 月报 (${startDate} ~ ${endDate})
## 月度目标达成
（目标完成情况 + 差距分析）
## 重点项目进展
（各项目进度、产出、风险）
## 时间投入分布
（工作类型占比 + 效率分析）
## 产出量化统计
（关键数据 + 趋势解读）
## 能力成长亮点
（技能提升 + 经验积累）
## 经验教训
（遇到的问题、解决方案、可复用的经验）
## 下月规划
` : `
# 📊 工作总结 (${startDate} ~ ${endDate})
## 周期关键成果
（最重要的产出和贡献，量化呈现）
## 能力成长曲线
（技能提升 + 领域拓展）
## 价值贡献量化
（用数据说明贡献）
## 经验教训与知识沉淀
（可复用的方法论和最佳实践）
## 下一阶段规划
（目标拆解和行动路径）
`}
请用中文输出，保持专业、客观、有数据支撑，避免空洞的套话。`;

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 120000); // 2 分钟超时
  try {
    const res = await fetch(`${aiConfig.baseURL}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${aiConfig.apiKey}`,
      },
      body: JSON.stringify({
        model: aiConfig.model,
        messages: [
          {
            role: 'system',
            content: '你是一个专业的职场复盘助手，擅长根据工作数据生成结构清晰、有洞察力的复盘报告。你写的中文专业、准确、直接，用数据说话。'
          },
          { role: 'user', content: prompt }
        ],
        temperature: 0.7,
        max_tokens: 4096,
      }),
      signal: controller.signal,
    });

    if (!res.ok) {
      clearTimeout(timeoutId);
      console.error('AI 报告生成失败:', res.status, await res.text());
      return null;
    }

    const data = await res.json();
    clearTimeout(timeoutId);
    const content = data.choices?.[0]?.message?.content;
    return content || null;
  } catch (e) {
    clearTimeout(timeoutId);
    if (e.name === 'AbortError') {
      console.error('AI 报告生成超时（2 分钟）');
    } else {
      console.error('AI 报告生成异常:', e.message);
    }
    return null;
  }
}

// POST /api/reports/generate - 生成复盘报告
router.post('/generate', async (req, res) => {
  let db;
  try {
    db = getDb();
    const { reportType, startDate, endDate, includeFiles, dirPath } = req.body;
    if (!reportType || !startDate || !endDate) {
      return res.status(400).json({ error: 'reportType, startDate, endDate 为必填项' });
    }

    // 1. 采集：从数据库查询工作记录
    let records = db.prepare(
      'SELECT * FROM work_records WHERE date >= ? AND date <= ?'
    ).all(startDate, endDate);

    // 2. 采集：同时扫描文件目录
    let fileEntries = [];
    if (includeFiles && dirPath) {
      const files = collector.scanDirectory(dirPath, startDate, endDate);
      fileEntries = await collector.parseFiles(files);

      const insert = db.prepare(
        'INSERT OR IGNORE INTO work_records (date, project, task, duration_hours, tags, status, source_file) VALUES (?,?,?,?,?,?,?)'
      );
      const mergeTx = db.transaction((entries) => {
        for (const e of entries) {
          insert.run(e.date, e.project, e.task, e.duration_hours, e.tags, e.status, e.source_file);
        }
      });
      mergeTx(fileEntries);

      records = db.prepare(
        'SELECT * FROM work_records WHERE date >= ? AND date <= ?'
      ).all(startDate, endDate);
    }

    // 3. 分析
    const goals = db.prepare('SELECT * FROM goals WHERE status = ?').all('active');
    const stats = analyst.computeMetrics(records, goals, 0);

    // 4. 生成报告：优先使用 AI，降级使用模板
    const title = {
      weekly: `周报 (${startDate} ~ ${endDate})`,
      monthly: `月报 (${startDate} ~ ${endDate})`,
      summary: `工作总结 (${startDate} ~ ${endDate})`,
    }[reportType];

    let content;
    let aiGenerated = false;

    // 尝试用 AI 生成
    const aiContent = await generateReportWithAI(reportType, stats, startDate, endDate, goals);
    if (aiContent) {
      content = aiContent;
      aiGenerated = true;
    } else {
      // 降级：使用模板引擎生成
      let report;
      switch (reportType) {
        case 'weekly':
          report = reviewer.generateWeeklyReport(stats, startDate, endDate);
          break;
        case 'monthly':
          report = reviewer.generateMonthlyReport(stats, startDate, endDate, goals);
          break;
        case 'summary':
          report = reviewer.generateSummaryReport(stats, startDate, endDate, goals);
          break;
        default:
          return res.status(400).json({ error: '不支持的报告类型' });
      }
      content = report.content;
    }

    // 5. 存储报告
    db.prepare(
      'INSERT INTO review_reports (report_type, title, period_start, period_end, content, stats_json) VALUES (?,?,?,?,?,?)'
    ).run(reportType, title, startDate, endDate, content, JSON.stringify(stats));

    // 保存绩效指标
    const metricData = db.prepare(
      'SELECT * FROM performance_metrics WHERE period_type = ? AND period_start = ? AND period_end = ?'
    ).get(reportType === 'weekly' ? 'weekly' : 'monthly', startDate, endDate);

    if (!metricData) {
      db.prepare(`
        INSERT INTO performance_metrics (period_type, period_start, period_end, total_tasks, completed_tasks,
          total_hours, planned_hours, completion_rate, estimation_accuracy, output_density,
          goal_achievement_rate, tag_distribution, highlights, lowlights)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
      `).run(
        reportType === 'weekly' ? 'weekly' : 'monthly',
        startDate, endDate,
        stats.total_tasks, stats.completed_tasks,
        stats.total_hours, stats.planned_hours || 0,
        stats.completion_rate, stats.estimation_accuracy || 0,
        stats.output_density, stats.goal_achievement_rate || 0,
        JSON.stringify(stats.tag_distribution),
        JSON.stringify(stats.highlights),
        JSON.stringify(stats.lowlights)
      );
    }

    res.json({
      title,
      content,
      stats,
      aiGenerated,
      fileEntriesImported: fileEntries.length,
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  } finally {
    if (db) db.close();
  }
});

// GET /api/reports - 查询历史报告
router.get('/', (req, res) => {
  let db;
  try {
    db = getDb();
    const { type, limit, offset } = req.query;
    let sql = 'SELECT id, report_type, title, period_start, period_end, created_at FROM review_reports WHERE 1=1';
    const params = [];
    if (type) { sql += ' AND report_type = ?'; params.push(type); }
    sql += ' ORDER BY created_at DESC';
    if (limit) { sql += ' LIMIT ?'; params.push(parseInt(limit)); }
    if (offset) { sql += ' OFFSET ?'; params.push(parseInt(offset)); }

    const reports = db.prepare(sql).all(...params);
    const total = db.prepare('SELECT COUNT(*) as count FROM review_reports' +
      (type ? ' WHERE report_type = ?' : ''))
      .get(...(type ? [type] : []));

    res.json({ data: reports, total: total?.count || 0 });
  } catch (e) {
    res.status(500).json({ error: e.message });
  } finally {
    if (db) db.close();
  }
});

// GET /api/reports/:id - 获取报告详情
router.get('/:id', (req, res) => {
  let db;
  try {
    db = getDb();
    const report = db.prepare('SELECT * FROM review_reports WHERE id = ?').get(req.params.id);
    if (!report) return res.status(404).json({ error: '报告不存在' });
    report.stats_json = JSON.parse(report.stats_json || '{}');
    res.json(report);
  } catch (e) {
    res.status(500).json({ error: e.message });
  } finally {
    if (db) db.close();
  }
});

// DELETE /api/reports/:id
router.delete('/:id', (req, res) => {
  let db;
  try {
    db = getDb();
    const result = db.prepare('DELETE FROM review_reports WHERE id = ?').run(req.params.id);
    if (result.changes === 0) return res.status(404).json({ error: '报告不存在' });
    res.json({ deleted: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  } finally {
    if (db) db.close();
  }
});

module.exports = router;
