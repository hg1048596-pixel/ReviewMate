const { getDb } = require('./init');

function seedData() {
  const db = getDb();

  const insertRecord = db.prepare(`
    INSERT INTO work_records (date, project, task, duration_hours, tags, status, notes)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);

  const insertMetric = db.prepare(`
    INSERT INTO performance_metrics (period_type, period_start, period_end, total_tasks, completed_tasks,
      total_hours, planned_hours, completion_rate, estimation_accuracy, output_density,
      goal_achievement_rate, tag_distribution, highlights, lowlights)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const insertGoal = db.prepare(`
    INSERT INTO goals (title, description, metric, weight, target_value, actual_value, deadline, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);

  // 种子工作记录 - 最近4周
  const projects = ['用户系统', '数据分析平台', '移动端App', '基础设施'];
  const tasks = [
    ['完成认证模块开发', 4, '["开发","核心功能"]'],
    ['修复登录页面样式', 0.5, '["Bug修复","前端"]'],
    ['需求评审会议', 1, '["会议"]'],
    ['编写单元测试', 2, '["测试"]'],
    ['Code Review', 1, '["协作"]'],
    ['API文档更新', 1.5, '["文档"]'],
    ['性能优化', 3, '["优化","核心功能"]'],
    ['数据库迁移脚本', 2, '["基础设施"]'],
    ['技术方案设计', 2.5, '["设计"]'],
    ['学习新技术框架', 2, '["学习"]'],
    ['解决线上问题', 1.5, '["Bug修复"]'],
    ['迭代回顾会议', 1, '["会议"]'],
  ];

  const now = new Date();
  for (let week = 0; week < 4; week++) {
    for (let day = 0; day < 5; day++) {
      const d = new Date(now);
      d.setDate(d.getDate() - (week * 7 + day + 2));
      const dateStr = d.toISOString().split('T')[0];

      const taskCount = 2 + Math.floor(Math.random() * 3);
      for (let i = 0; i < taskCount; i++) {
        const t = tasks[Math.floor(Math.random() * tasks.length)];
        const project = projects[Math.floor(Math.random() * projects.length)];
        insertRecord.run(dateStr, project, t[0], t[1] * (0.8 + Math.random() * 0.4), t[2], 'completed', '');
      }
    }
  }

  // 种子绩效指标 - 最近4周
  for (let week = 0; week < 4; week++) {
    const end = new Date(now);
    end.setDate(end.getDate() - (week * 7));
    const start = new Date(end);
    start.setDate(start.getDate() - 6);
    const s = start.toISOString().split('T')[0];
    const e = end.toISOString().split('T')[0];

    const total = 10 + Math.floor(Math.random() * 15);
    const completed = Math.floor(total * (0.7 + Math.random() * 0.3));
    const totalH = 25 + Math.floor(Math.random() * 15);
    const plannedH = totalH * (0.8 + Math.random() * 0.4);

    insertMetric.run(
      'weekly', s, e,
      total, completed,
      totalH, plannedH,
      parseFloat((completed / total).toFixed(2)),
      parseFloat((plannedH / totalH).toFixed(2)),
      parseFloat((completed / 5).toFixed(1)),
      parseFloat((0.7 + Math.random() * 0.3).toFixed(2)),
      JSON.stringify({ 开发: 55, 会议: 15, 文档: 10, 学习: 10, 其他: 10 }),
      JSON.stringify(['按时交付核心模块', '单元测试覆盖率达到85%']),
      JSON.stringify(['需求变更导致2个任务延期'])
    );
  }

  // 种子目标
  const goals = [
    ['提升代码质量', '单元测试覆盖率从70%提升到85%', '覆盖率(%)', 0.3, 85, 82, null, 'active'],
    ['完成用户系统重构', '完成用户认证、授权、个人中心三大模块重构', '模块数', 0.4, 3, 2, null, 'active'],
    ['学习Go语言', '完成Go基础学习和一个小项目实践', '学习时长(h)', 0.15, 40, 25, null, 'active'],
    ['优化系统性能', 'API平均响应时间降低30%', '响应时间下降(%)', 0.15, 30, 22, null, 'active'],
  ];
  for (const g of goals) {
    insertGoal.run(...g);
  }

  console.log('种子数据插入完成');
  db.close();
}

if (require.main === module) {
  seedData();
}
