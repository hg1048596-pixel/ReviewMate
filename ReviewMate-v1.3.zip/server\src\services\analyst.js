/**
 * 统计分析代理 - 对工作数据进行多维度统计和量化分析
 */
class AnalystAgent {
  /**
   * 计算基础统计
   */
  analyze(records) {
    if (!records || records.length === 0) {
      return this._emptyStats();
    }

    const totalTasks = records.length;
    const completedTasks = records.filter(r => r.status === 'completed').length;
    const totalHours = records.reduce((sum, r) => sum + (parseFloat(r.duration_hours) || 0), 0);

    // 任务完成率
    const completionRate = totalTasks > 0 ? completedTasks / totalTasks : 0;

    // 标签分布
    const tagDistribution = {};
    for (const r of records) {
      let tags = [];
      try {
        tags = typeof r.tags === 'string' ? JSON.parse(r.tags) : (r.tags || []);
      } catch (e) { tags = []; }
      for (const t of tags) {
        tagDistribution[t] = (tagDistribution[t] || 0) + 1;
      }
    }

    // 项目分布
    const projectDistribution = {};
    const projectHours = {};
    for (const r of records) {
      const p = r.project || '未分类';
      projectDistribution[p] = (projectDistribution[p] || 0) + 1;
      projectHours[p] = (projectHours[p] || 0) + (parseFloat(r.duration_hours) || 0);
    }

    // 按日期分组
    const dailyRecords = {};
    for (const r of records) {
      const d = r.date || 'unknown';
      if (!dailyRecords[d]) dailyRecords[d] = [];
      dailyRecords[d].push(r);
    }
    const workDays = Object.keys(dailyRecords).length;
    const outputDensity = workDays > 0 ? completedTasks / workDays : 0;

    // 识别亮点：任务完成率高、产出多的日期
    const highlights = this._findHighlights(dailyRecords);
    const lowlights = this._findLowlights(records, dailyRecords);

    return {
      total_tasks: totalTasks,
      completed_tasks: completedTasks,
      total_hours: parseFloat(totalHours.toFixed(2)),
      completion_rate: parseFloat(completionRate.toFixed(2)),
      output_density: parseFloat(outputDensity.toFixed(1)),
      tag_distribution: tagDistribution,
      project_distribution: projectDistribution,
      project_hours: projectHours,
      work_days: workDays,
      highlights,
      lowlights,
      daily_breakdown: dailyRecords
    };
  }

  /**
   * 对比分析：将当前统计与历史周期对比
   */
  compareStats(current, previous) {
    if (!previous || !previous.total_tasks) return null;

    const taskChange = previous.total_tasks > 0
      ? parseFloat(((current.total_tasks - previous.total_tasks) / previous.total_tasks * 100).toFixed(1))
      : 0;

    const hourChange = previous.total_hours > 0
      ? parseFloat(((current.total_hours - previous.total_hours) / previous.total_hours * 100).toFixed(1))
      : 0;

    const completionChange = parseFloat((current.completion_rate - (previous.completion_rate || 0)).toFixed(2));

    return {
      task_change_pct: taskChange,
      hour_change_pct: hourChange,
      completion_change: completionChange,
      trend: completionChange >= 0 ? 'up' : 'down'
    };
  }

  /**
   * 计算绩效指标
   */
  computeMetrics(records, goals = [], plannedHours = 0) {
    const stats = this.analyze(records);
    const totalHours = stats.total_hours;

    // 预估准确率
    const estimationAccuracy = plannedHours > 0
      ? parseFloat((totalHours / plannedHours).toFixed(2))
      : 0;

    // 目标达成率
    let goalAchievementRate = 0;
    if (goals.length > 0) {
      const totalWeight = goals.reduce((s, g) => s + g.weight, 0);
      const achievements = goals.map(g => {
        const rate = g.target_value > 0 ? g.actual_value / g.target_value : 0;
        return Math.min(rate, 1) * g.weight;
      });
      goalAchievementRate = totalWeight > 0
        ? parseFloat((achievements.reduce((s, a) => s + a, 0) / totalWeight).toFixed(2))
        : 0;
    }

    return {
      ...stats,
      planned_hours: plannedHours,
      estimation_accuracy: estimationAccuracy,
      goal_achievement_rate: goalAchievementRate
    };
  }

  _findHighlights(dailyRecords) {
    const highlights = [];
    const days = Object.entries(dailyRecords)
      .sort((a, b) => b[1].length - a[1].length);

    // 产出最多的几天
    for (let i = 0; i < Math.min(3, days.length); i++) {
      const [date, records] = days[i];
      const completed = records.filter(r => r.status === 'completed');
      if (completed.length >= 2 && i < 2) {
        const taskList = completed.map(r => r.task).join('、');
        highlights.push(`${date}: 高效完成${completed.length}项任务 — ${taskList}`);
      }
    }

    // 如果连续多日高产出
    if (days.length >= 3 && highlights.length === 0) {
      highlights.push(`本周期持续稳定产出，${days.length}个工作日共完成${dailyRecords.size || 0}项任务`);
    }

    return highlights.length > 0 ? highlights : ['本周期工作节奏平稳，建议增加挑战性任务'];
  }

  _findLowlights(records, dailyRecords) {
    const lowlights = [];
    const zeroHourRecords = records.filter(r => r.status === 'completed' && (parseFloat(r.duration_hours) || 0) === 0);
    if (zeroHourRecords.length > records.length * 0.3) {
      lowlights.push(`${zeroHourRecords.length}项任务未记录耗时，建议完善时间追踪`);
    }

    const days = Object.entries(dailyRecords);
    if (days.length > 1) {
      const avgTasks = records.length / days.length;
      const lightDays = days.filter(([, rs]) => rs.length < avgTasks * 0.5);
      if (lightDays.length >= 2) {
        lowlights.push(`${lightDays.length}天产出低于平均水平，可能存在会议过多或阻塞情况`);
      }
    }

    return lowlights;
  }

  _emptyStats() {
    return {
      total_tasks: 0,
      completed_tasks: 0,
      total_hours: 0,
      completion_rate: 0,
      output_density: 0,
      tag_distribution: {},
      project_distribution: {},
      project_hours: {},
      work_days: 0,
      highlights: ['暂无数据，请先录入工作记录'],
      lowlights: [],
      daily_breakdown: {}
    };
  }
}

module.exports = new AnalystAgent();
