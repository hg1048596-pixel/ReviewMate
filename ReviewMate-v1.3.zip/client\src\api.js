const API = '/api'

// 带超时的 fetch（生成报告等长耗时操作不需要超时）
async function fetchWithTimeout(url, options = {}, timeout = 30000) {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), timeout)
  try {
    const res = await fetch(url, { ...options, signal: controller.signal })
    return res
  } catch (e) {
    if (e.name === 'AbortError') {
      throw new Error('请求超时，请检查网络连接或后端服务状态')
    }
    throw e
  } finally {
    clearTimeout(timer)
  }
}

async function request(url, options = {}) {
  const { timeout, ...fetchOptions } = options
  const headers = { ...fetchOptions.headers }
  // 仅在有 body 时设置 Content-Type，避免 DELETE 等空请求触发 JSON 解析错误
  if (fetchOptions.body) {
    headers['Content-Type'] = 'application/json'
  }
  let res
  try {
    res = await fetchWithTimeout(API + url, {
      ...fetchOptions,
      headers,
    }, timeout)
  } catch (e) {
    // 网络错误（fetch本身失败，不是HTTP错误状态码）
    if (e.message === 'Failed to fetch' || e.message.includes('NetworkError')) {
      throw new Error('无法连接后端服务，请确认后端已启动 (端口 3001)')
    }
    throw e
  }
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }))
    throw new Error(err.error || `${res.status} ${res.statusText}`)
  }
  return res.json()
}

export const api = {
  // 工作记录
  getRecords: (params) => request('/work-records?' + new URLSearchParams(params)),
  createRecord: (data) => request('/work-records', { method: 'POST', body: JSON.stringify(data) }),
  updateRecord: (id, data) => request(`/work-records/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteRecord: (id) => request(`/work-records/${id}`, { method: 'DELETE' }),
  importRecords: (data) => request('/work-records/import', { method: 'POST', body: JSON.stringify(data) }),

  // 分析
  getStats: (params) => request('/analysis/stats?' + new URLSearchParams(params)),
  getTrends: (params) => request('/analysis/trends?' + new URLSearchParams(params)),
  compareStats: (data) => request('/analysis/compare', { method: 'POST', body: JSON.stringify(data) }),

  // 报告（生成报告为长耗时操作，超时设为 5 分钟）
  generateReport: (data) => request('/reports/generate', { method: 'POST', body: JSON.stringify(data), timeout: 300000 }),
  getReports: (params) => request('/reports?' + new URLSearchParams(params)),
  getReportDetail: (id) => request(`/reports/${id}`),
  deleteReport: (id) => request(`/reports/${id}`, { method: 'DELETE' }),

  // 指标
  getMetrics: (params) => request('/metrics?' + new URLSearchParams(params)),
  getDashboard: () => request('/metrics/dashboard'),

  // 目标
  getGoals: (params) => request('/goals?' + new URLSearchParams(params)),
  createGoal: (data) => request('/goals', { method: 'POST', body: JSON.stringify(data) }),
  updateGoal: (id, data) => request(`/goals/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteGoal: (id) => request(`/goals/${id}`, { method: 'DELETE' }),

  // 设置
  getSettings: () => request('/settings'),
  updateSetting: (key, value) => request(`/settings/${key}`, { method: 'PUT', body: JSON.stringify({ value }) }),
  getDbInfo: () => request('/settings/db-info'),
  moveDb: (newPath) => request('/settings/move-db', { method: 'POST', body: JSON.stringify({ newPath }) }),
  newDb: (path) => request('/settings/new-db', { method: 'POST', body: JSON.stringify({ path }) }),
  switchDb: (path) => request('/settings/switch-db', { method: 'POST', body: JSON.stringify({ path }) }),
  openDbFolder: () => request('/settings/open-db-folder', { method: 'POST' }),
  getDownloadPath: () => request('/settings/download-path'),
  openDownloadFolder: () => request('/settings/open-download-folder', { method: 'POST' }),
  restartServer: () => request('/settings/restart', { method: 'POST' }),

  // AI
  getAiData: (params) => request('/ai/data?' + new URLSearchParams(params)),
  getAiContext: () => request('/ai/context'),
  aiChat: (messages, { signal, onChunk, injectContext = true, fileContext = null } = {}) => {
    const controller = new AbortController()
    const s = signal || controller.signal
    let fullContent = ''
    let reasoningContent = ''

    const sendRequest = async () => {
      const res = await fetch(API + '/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages, stream: true, injectContext, fileContext }),
        signal: s,
      })

      const reader = res.body.getReader()
      const decoder = new TextDecoder()
      let buffer = ''

      while (true) {
        const { done, value } = await reader.read()
        if (done) break

        buffer += decoder.decode(value, { stream: true })
        const lines = buffer.split('\n')
        buffer = lines.pop() || ''

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6).trim()
            if (data === '[DONE]') {
              if (onChunk) onChunk({ done: true, content: fullContent, reasoningContent })
              return fullContent
            }
            try {
              const parsed = JSON.parse(data)
              if (parsed.error) {
                if (onChunk) onChunk({ error: parsed.error })
                return fullContent
              }
              const delta = parsed.choices?.[0]?.delta || {}
              const contentDelta = delta.content || ''
              const reasoningDelta = delta.reasoning_content || ''
              fullContent += contentDelta
              reasoningContent += reasoningDelta
              // 有任何内容（包括思考过程）都通知前端，避免长时间无响应
              if (onChunk && (contentDelta || reasoningDelta)) {
                onChunk({ content: contentDelta, fullContent, reasoningContent, done: false })
              }
            } catch (e) {
              // 解析失败，跳过
            }
          }
        }
      }
      return fullContent
    }

    const promise = sendRequest()
    return {
      promise,
      abort: () => controller.abort(),
    }
  },
  aiImportFile: (filePath) => request('/ai/import-file', { method: 'POST', body: JSON.stringify({ filePath }) }),
  aiImportFileContent: (fileName, content) => request('/ai/import-file', { method: 'POST', body: JSON.stringify({ fileName, content }) }),
  aiGeneratePPT: (data) => request('/ai/generate-ppt', { method: 'POST', body: JSON.stringify(data), timeout: 300000 }), // data 可含 fileContext
  aiGenerateDOCX: (data) => request('/ai/generate-docx', { method: 'POST', body: JSON.stringify(data), timeout: 300000 }),
  aiDownloadFile: (fileName) => `${API}/ai/download/${encodeURIComponent(fileName)}`,

  // 飞书
  getFeishuStatus: () => request('/feishu/status'),
  getFeishuCalendarEvents: (params) => request('/feishu/calendar-events?' + new URLSearchParams(params)),
  getFeishuTasks: () => request('/feishu/tasks'),
  importFeishuItems: (items) => request('/feishu/import', { method: 'POST', body: JSON.stringify({ items }) }),
}
