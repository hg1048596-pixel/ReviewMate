const express = require('express');
const { getDb } = require('../db/init');
const { getAiConfig } = require('../utils/aiConfig');
const collector = require('../services/collector');
const docGen = require('../services/documentGenerator');
const fs = require('fs');
const path = require('path');

const router = express.Router();

/**
 * 流式调用 AI 完成接口，累积返回完整文本内容
 * 使用 stream:true 避免 CDN 504 超时（非流式请求等待时间过长）
 * @param {Object} aiConfig - { baseURL, apiKey, model }
 * @param {Array} messages - 消息数组
 * @param {Object} opts - { maxTokens, temperature, timeoutMs }
 * @returns {Promise<string>} 完整的文本内容
 */
async function streamAICompletion(aiConfig, messages, opts = {}) {
  const { maxTokens = 8192, temperature = 0.7, timeoutMs = 240000 } = opts;
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const aiRes = await fetch(`${aiConfig.baseURL}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${aiConfig.apiKey}`,
      },
      body: JSON.stringify({
        model: aiConfig.model,
        messages,
        stream: true,
        temperature,
        max_tokens: maxTokens,
      }),
      signal: controller.signal,
    });

    if (!aiRes.ok) {
      const errText = await aiRes.text().catch(() => '');
      throw new Error(`AI API 错误: ${aiRes.status} ${errText.substring(0, 200)}`);
    }

    const reader = aiRes.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    let fullContent = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() || '';

      for (const line of lines) {
        if (line.startsWith('data: ')) {
          const data = line.slice(6).trim();
          if (data === '[DONE]') continue;
          try {
            const parsed = JSON.parse(data);
            const delta = parsed.choices?.[0]?.delta?.content || '';
            fullContent += delta;
          } catch (e) { /* skip invalid chunks */ }
        }
      }
    }

    return fullContent;
  } finally {
    clearTimeout(timeoutId);
  }
}

/**
 * GET /api/ai/data — 聚合所有数据供 AI 读取分析
 * 返回完整的系统数据快照：工作记录、绩效指标、目标、报告、设置
 */
router.get('/data', (req, res) => {
  let db;
  try {
    db = getDb();
    const { start, end } = req.query;

    // 工作记录
    let recordsSql = 'SELECT * FROM work_records';
    const recordsParams = [];
    if (start && end) {
      recordsSql += ' WHERE date >= ? AND date <= ?';
      recordsParams.push(start, end);
    }
    recordsSql += ' ORDER BY date DESC';
    const records = db.prepare(recordsSql).all(...recordsParams);

    // 绩效指标
    const metrics = db.prepare(
      'SELECT * FROM performance_metrics ORDER BY period_start DESC LIMIT 50'
    ).all();

    // 目标
    const goals = db.prepare('SELECT * FROM goals ORDER BY weight DESC').all();

    // 历史报告
    const reports = db.prepare(
      'SELECT id, report_type, title, period_start, period_end, created_at FROM review_reports ORDER BY created_at DESC LIMIT 20'
    ).all();

    // 设置
    const settings = db.prepare('SELECT * FROM settings').all();
    const settingsMap = {};
    settings.forEach(s => {
      try { settingsMap[s.key] = JSON.parse(s.value); } catch (e) { settingsMap[s.key] = s.value; }
    });

    // 汇总统计
    const totalRecords = db.prepare('SELECT COUNT(*) as c FROM work_records').get().c;
    const completedRecords = db.prepare(
      "SELECT COUNT(*) as c FROM work_records WHERE status = 'completed'"
    ).get().c;
    const totalHours = db.prepare(
      'SELECT SUM(duration_hours) as s FROM work_records'
    ).get().s || 0;

    // 项目列表
    const projects = db.prepare(
      'SELECT DISTINCT project FROM work_records WHERE project != \'\''
    ).all().map(p => p.project);

    // 标签汇总
    const allTags = {};
    records.forEach(r => {
      try {
        const tags = JSON.parse(r.tags || '[]');
        tags.forEach(t => { allTags[t] = (allTags[t] || 0) + 1; });
      } catch (e) {}
    });

    res.json({
      summary: {
        total_records: totalRecords,
        completed_records: completedRecords,
        total_hours: Number(totalHours.toFixed(2)),
        completion_rate: totalRecords > 0 ? Math.round(completedRecords / totalRecords * 100) : 0,
        active_goals: goals.filter(g => g.status === 'active').length,
        total_reports: reports.length,
        projects: projects,
        top_tags: Object.entries(allTags).sort((a, b) => b[1] - a[1]).slice(0, 10),
      },
      work_records: records.map(r => ({
        ...r,
        tags: JSON.parse(r.tags || '[]')
      })),
      performance_metrics: metrics.map(m => ({
        ...m,
        tag_distribution: JSON.parse(m.tag_distribution || '{}'),
        highlights: JSON.parse(m.highlights || '[]'),
        lowlights: JSON.parse(m.lowlights || '[]'),
      })),
      goals: goals.map(g => ({
        ...g,
        progress: g.target_value > 0 ? Math.round(g.actual_value / g.target_value * 100) : 0
      })),
      reports,
      settings: settingsMap,
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  } finally {
    if (db) db.close();
  }
});

/**
 * GET /api/ai/context — 生成 AI 对话所需的精简系统上下文
 */
router.get('/context', (req, res) => {
  let db;
  try {
    db = getDb();
    const records = db.prepare(
      'SELECT date, project, task, duration_hours, tags, status FROM work_records ORDER BY date DESC LIMIT 500'
    ).all();

    const metrics = db.prepare(
      'SELECT period_type, period_start, period_end, total_tasks, completed_tasks, total_hours, completion_rate, output_density FROM performance_metrics ORDER BY period_start DESC LIMIT 20'
    ).all();

    const goals = db.prepare(
      'SELECT title, description, metric, weight, target_value, actual_value, status FROM goals'
    ).all();

    const settings = db.prepare('SELECT * FROM settings').all();
    const settingsMap = {};
    settings.forEach(s => {
      try { settingsMap[s.key] = JSON.parse(s.value); } catch (e) { settingsMap[s.key] = s.value; }
    });

    // 构建精简上下文文本
    const ctx = {
      system_info: {
        name: 'ReviewMate 复盘助手',
        version: '1.0.0',
        description: '专注职场员工考评与工作复盘',
        data_range: `${records.length} 条工作记录, ${metrics.length} 个绩效周期, ${goals.length} 个目标`,
      },
      recent_records: records.slice(0, 100).map(r => ({
        date: r.date,
        project: r.project,
        task: r.task,
        hours: r.duration_hours,
        tags: JSON.parse(r.tags || '[]'),
        status: r.status,
      })),
      performance_trend: metrics.map(m => ({
        type: m.period_type,
        period: `${m.period_start} ~ ${m.period_end}`,
        tasks: `${m.completed_tasks}/${m.total_tasks}`,
        completion_rate: Math.round(m.completion_rate * 100) + '%',
        hours: m.total_hours,
        density: m.output_density,
      })),
      goals_status: goals.map(g => ({
        title: g.title,
        desc: g.description,
        progress: g.target_value > 0 ? Math.round(g.actual_value / g.target_value * 100) + '%' : 'N/A',
        weight: g.weight,
        status: g.status,
      })),
      settings: {
        work_dir: settingsMap.work_dir || '未配置',
      },
    };

    res.json(ctx);
  } catch (e) {
    res.status(500).json({ error: e.message });
  } finally {
    if (db) db.close();
  }
});

/**
 * POST /api/ai/chat — AI 对话代理（流式 SSE）
 * Body: { messages: [{role, content}], stream: true, injectContext: true }
 */
router.post('/chat', async (req, res) => {
  try {
    const { messages = [], stream = true, injectContext = true, fileContext = null } = req.body;

    const aiConfig = getAiConfig();

    if (!aiConfig.apiKey) {
      // 没有配置 API Key 时，返回本地 Agent 响应
      return handleLocalChat(req, res, messages, injectContext, fileContext);
    }

    let finalMessages = [...messages];

    // 注入系统上下文
    if (injectContext) {
      let ctxDb;
      try {
        ctxDb = getDb();
        const contextData = buildSystemPrompt(ctxDb, fileContext);
        finalMessages = [
          { role: 'system', content: contextData },
          ...messages,
        ];
      } finally {
        if (ctxDb) ctxDb.close();
      }
    }

    if (stream) {
      // SSE 流式响应
      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache');
      res.setHeader('Connection', 'keep-alive');
      res.setHeader('X-Accel-Buffering', 'no');

      try {
        const aiRes = await fetch(`${aiConfig.baseURL}/chat/completions`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${aiConfig.apiKey}`,
          },
          body: JSON.stringify({
            model: aiConfig.model,
            messages: finalMessages,
            stream: true,
            temperature: 0.7,
            max_tokens: 4096,
          }),
        });

        if (!aiRes.ok) {
          const errText = await aiRes.text();
          res.write(`data: ${JSON.stringify({ error: `AI API 错误: ${aiRes.status} ${errText}` })}\n\n`);
          res.end();
          return;
        }

        const reader = aiRes.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split('\n');
          buffer = lines.pop() || '';

          for (const line of lines) {
            if (line.startsWith('data: ')) {
              const data = line.slice(6).trim();
              if (data === '[DONE]') {
                res.write('data: [DONE]\n\n');
              } else {
                res.write(`data: ${data}\n\n`);
              }
            }
          }
        }
      } catch (fetchErr) {
        res.write(`data: ${JSON.stringify({ error: `AI API 连接失败: ${fetchErr.message}` })}\n\n`);
      }

      res.end();
    } else {
      // 非流式响应
      const aiRes2 = await fetch(`${aiConfig.baseURL}/chat/completions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${aiConfig.apiKey}`,
        },
        body: JSON.stringify({
          model: aiConfig.model,
          messages: finalMessages,
          temperature: 0.7,
          max_tokens: 4096,
        }),
      });

      const data = await aiRes2.json();
      res.json(data);
    }
  } catch (e) {
    if (!res.headersSent) {
      res.status(500).json({ error: e.message });
    } else {
      res.write(`data: ${JSON.stringify({ error: e.message })}\n\n`);
      res.end();
    }
  }
});

/**
 * POST /api/ai/import-file — 读取文件并提取文本，返回给前端作为 AI 上下文
 * 不写入数据库，纯文本供 AI 学习
 * Body: { filePath: string } 或 { fileName: string, content: string (base64) }
 */
router.post('/import-file', async (req, res) => {
  let tempFile = null;
  try {
    const { filePath, fileName, content } = req.body;

    let absPath;
    let displayName;

    if (content && fileName) {
      // 拖拽上传：从 base64 内容写入临时文件
      const os = require('os');
      const tmpDir = os.tmpdir();
      tempFile = path.join(tmpDir, `reviewmate_import_${Date.now()}_${fileName}`);
      fs.writeFileSync(tempFile, Buffer.from(content, 'base64'));
      absPath = tempFile;
      displayName = fileName;
    } else if (filePath) {
      // 路径方式：如果是相对路径，尝试在常见目录下查找
      absPath = path.resolve(filePath);
      displayName = path.basename(absPath);
      // 如果文件不存在，尝试在用户常见目录下查找
      if (!fs.existsSync(absPath)) {
        const home = require('os').homedir();
        const candidates = [
          path.join(home, 'Downloads', displayName),
          path.join(home, 'Desktop', displayName),
          path.join(home, 'Documents', displayName),
          path.join(process.cwd(), displayName),
        ];
        for (const c of candidates) {
          if (fs.existsSync(c)) { absPath = c; break; }
        }
      }
    } else {
      return res.status(400).json({ error: '请提供 filePath 或 fileName+content' });
    }

    if (!fs.existsSync(absPath)) {
      return res.status(404).json({ error: `文件不存在: ${absPath}` });
    }

    const stat = fs.statSync(absPath);
    const ext = path.extname(absPath).toLowerCase();
    const isBinary = ['.docx', '.pptx', '.xlsx', '.pdf'].includes(ext);

    const file = {
      filePath: absPath,
      fileName: displayName,
      modifiedAt: stat.mtime.toISOString(),
      ext,
      content: isBinary ? fs.readFileSync(absPath) : fs.readFileSync(absPath, 'utf-8'),
    };

    // 提取纯文本（不解析为工作记录，不写数据库）
    const textContent = await collector.extractText(file);

    // 截断到合理长度（约 12000 字符，避免 token 超限）
    const maxLen = 12000;
    const truncated = textContent.length > maxLen;
    const preview = truncated
      ? textContent.substring(0, maxLen) + '\n\n...(内容已截断，仅展示前12000字符)'
      : textContent;

    res.json({
      success: true,
      fileName: displayName,
      fileSize: stat.size,
      textLength: textContent.length,
      truncated,
      textContent: preview,
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  } finally {
    if (tempFile && fs.existsSync(tempFile)) {
      try { fs.unlinkSync(tempFile) } catch (_) { /* ignore */ }
    }
  }
});

/**
 * POST /api/ai/generate-ppt — 生成 PPT 文件
 * Body: { prompt, dataContext? }
 * 返回: { success, fileName, filePath }
 */
router.post('/generate-ppt', async (req, res) => {
  try {
    const { prompt, dataContext, fileContext = null } = req.body;
    if (!prompt) return res.status(400).json({ error: 'prompt 为必填项' });

    const aiConfig = getAiConfig();
    const timestamp = Date.now();
    const fileName = `ppt_${timestamp}`;

    if (!aiConfig.apiKey) {
      // 无 AI 配置时使用模板降级方案
      const filePath = await docGen.createFallbackPPT(prompt, dataContext, fileName);
      return res.json({ success: true, fileName: `${fileName}.pptx`, filePath });
    }

    // 判断是否为模板模式：用户导入了 PPT 文件
    const isTemplateMode = fileContext && fileContext.fileName &&
      fileContext.fileName.toLowerCase().endsWith('.pptx');

    // 调用 AI 全权设计 PPT（流式调用避免 CDN 504 超时）
    const aiPrompt = docGen.buildPPTPrompt(prompt, dataContext, isTemplateMode ? fileContext : null);

    let pptData;
    try {
      const content = await streamAICompletion(aiConfig, [
        { role: 'system', content: '你是一个专业的演示文稿设计师，拥有完全的设计自由。只输出JSON，不要其他内容。' },
        { role: 'user', content: aiPrompt },
      ], { maxTokens: 8192, timeoutMs: 240000 });
      pptData = docGen.extractJSON(content);
    } catch (e) {
      console.error('AI PPT 生成异常:', e.message);
      const filePath = await docGen.createFallbackPPT(prompt, dataContext, fileName);
      return res.json({ success: true, fileName: `${fileName}.pptx`, filePath, fallback: true });
    }

    if (!pptData || !pptData.slides) {
      const filePath = await docGen.createFallbackPPT(prompt, dataContext, fileName);
      return res.json({ success: true, fileName: `${fileName}.pptx`, filePath, fallback: true });
    }

    const filePath = await docGen.createPPT(pptData, fileName);
    res.json({ success: true, fileName: `${fileName}.pptx`, filePath, templateMode: isTemplateMode });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

/**
 * POST /api/ai/generate-docx — 生成 Word 文档
 * Body: { prompt, dataContext? }
 * 返回: { success, fileName, filePath }
 */
router.post('/generate-docx', async (req, res) => {
  try {
    const { prompt, dataContext } = req.body;
    if (!prompt) return res.status(400).json({ error: 'prompt 为必填项' });

    const aiConfig = getAiConfig();
    const timestamp = Date.now();
    const fileName = `doc_${timestamp}`;

    if (!aiConfig.apiKey) {
      const filePath = await docGen.createFallbackDOCX(prompt, dataContext, fileName);
      return res.json({ success: true, fileName: `${fileName}.docx`, filePath });
    }

    const aiPrompt = docGen.buildDOCXPrompt(prompt, dataContext);

    let docData;
    try {
      const content = await streamAICompletion(aiConfig, [
        { role: 'system', content: '你是一个专业的文档撰写助手。只输出JSON，不要其他内容。' },
        { role: 'user', content: aiPrompt },
      ], { maxTokens: 4096, timeoutMs: 240000 });
      docData = docGen.extractJSON(content);
    } catch (e) {
      console.error('AI DOCX 生成异常:', e.message);
      const filePath = await docGen.createFallbackDOCX(prompt, dataContext, fileName);
      return res.json({ success: true, fileName: `${fileName}.docx`, filePath, fallback: true });
    }

    if (!docData || !docData.sections) {
      const filePath = await docGen.createFallbackDOCX(prompt, dataContext, fileName);
      return res.json({ success: true, fileName: `${fileName}.docx`, filePath, fallback: true });
    }

    const filePath = await docGen.createDOCX(docData, fileName);
    res.json({ success: true, fileName: `${fileName}.docx`, filePath });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

/**
 * GET /api/ai/download/:fileName — 下载生成的文件
 */
router.get('/download/:fileName', (req, res) => {
  const fileName = req.params.fileName;
  // 优先查主输出目录，再查临时降级目录
  const candidates = [
    path.join(docGen.getOutputDir(), fileName),
    path.join(require('os').tmpdir(), 'ReviewMate', fileName),
  ];
  let filePath = null;
  for (const p of candidates) {
    if (fs.existsSync(p)) { filePath = p; break; }
  }
  if (!filePath) {
    return res.status(404).json({ error: '文件不存在' });
  }
  res.download(filePath);
});

// ---- 内部函数 ----

/** 构建 AI 系统提示词 */
function buildSystemPrompt(db, fileContext = null) {
  const records = db.prepare(
    'SELECT date, project, task, duration_hours, tags, status FROM work_records ORDER BY date DESC LIMIT 200'
  ).all();

  const metrics = db.prepare(
    'SELECT period_type, period_start, period_end, total_tasks, completed_tasks, total_hours, completion_rate, output_density FROM performance_metrics ORDER BY period_start DESC LIMIT 12'
  ).all();

  const goals = db.prepare(
    'SELECT title, description, metric, weight, target_value, actual_value, status FROM goals'
  ).all();

  // 本周数据
  const now = new Date();
  const weekStart = new Date(now);
  weekStart.setDate(weekStart.getDate() - now.getDay() + 1);
  const weekEnd = now.toISOString().split('T')[0];
  const ws = weekStart.toISOString().split('T')[0];

  const thisWeekRecords = records.filter(r => r.date >= ws && r.date <= weekEnd);
  const thisWeekCompleted = thisWeekRecords.filter(r => r.status === 'completed').length;
  const thisWeekHours = thisWeekRecords.reduce((s, r) => s + r.duration_hours, 0);

  const recordSummary = records.slice(0, 50).map(r =>
    `[${r.date}] ${r.project ? r.project + ' - ' : ''}${r.task} (${r.duration_hours}h) [${r.status}]`
  ).join('\n');

  const metricSummary = metrics.map(m =>
    `${m.period_type}: ${m.period_start}~${m.period_end} | 完成${m.completed_tasks}/${m.total_tasks} | 完成率${Math.round(m.completion_rate*100)}% | ${Number(m.total_hours).toFixed(2)}h`
  ).join('\n');

  const goalSummary = goals.map(g => {
    const p = g.target_value > 0 ? Math.round(g.actual_value / g.target_value * 100) : 0;
    return `- ${g.title}: ${p}% (${g.actual_value}/${g.target_value}) | 权重${g.weight} | ${g.status}`;
  }).join('\n');

  return `你是 ReviewMate，一个专注于职场员工绩效考评与工作复盘的智能助手。

## 你的身份
- 专业但不冰冷，用数据说话但懂得讲故事
- 建设性而非批判性，指出不足时附带改进建议
- 帮助用户从工作记录中发现规律、关注成长

## 当前系统数据概况
- 本周: ${thisWeekRecords.length}条记录，完成${thisWeekCompleted}项，投入${thisWeekHours.toFixed(1)}小时
- 总记录: ${records.length}条

## 最近工作记录
${recordSummary || '暂无记录'}

## 绩效趋势
${metricSummary || '暂无数据'}

## 目标状态
${goalSummary || '暂无目标'}

## 你的能力
1. 分析用户的工作模式和效率趋势
2. 回答关于绩效数据、工作记录的任何问题
3. 帮助用户理解复盘报告中的指标含义
4. 给出具体、可操作的改进建议
5. 协助生成周报、月报、工作总结
6. 根据导入的文件内容进行分析
7. 可以生成 PPT 演示文稿和 Word 文档（用户点击导出按钮即可生成）

当用户需要生成 PPT 或 Word 文档时，先整理好内容要点，然后告知用户可以点击上方的「导出PPT」或「导出Word」按钮来生成文件。

${fileContext ? `
## 用户导入的文件内容
以下内容来自用户导入的文件 **${fileContext.fileName}**，请基于此内容回答用户问题：

${fileContext.textContent}
` : ''}
请用中文回复，保持专业、简洁、有洞察力。`;
}

/**
 * 本地对话处理（无 AI API 时的降级方案）
 * 基于规则和数据分析做出智能回复
 */
async function handleLocalChat(req, res, messages, injectContext, fileContext = null) {
  const lastMsg = messages[messages.length - 1]?.content || '';

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');

  const db = getDb();
  let reply = '';

  try {
    // 获取数据做智能分析
    const totalRecords = db.prepare('SELECT COUNT(*) as c FROM work_records').get().c;
    const completedRecords = db.prepare("SELECT COUNT(*) as c FROM work_records WHERE status='completed'").get().c;
    const now = new Date();
    const weekStart = new Date(now);
    weekStart.setDate(weekStart.getDate() - now.getDay() + 1);
    const ws = weekStart.toISOString().split('T')[0];
    const we = now.toISOString().split('T')[0];
    const thisWeek = db.prepare('SELECT COUNT(*) as c FROM work_records WHERE date>=? AND date<=?').get(ws, we).c;
    const thisWeekDone = db.prepare("SELECT COUNT(*) as c FROM work_records WHERE date>=? AND date<=? AND status='completed'").get(ws, we).c;
    const goals = db.prepare("SELECT * FROM goals WHERE status='active'").all();

    if (lastMsg.includes('周报') || lastMsg.includes('本周')) {
      reply = `根据系统数据，本周(${ws}~${we})共有 **${thisWeek}** 条工作记录，已完成 **${thisWeekDone}** 项。\n\n当前系统中共有 **${totalRecords}** 条历史工作记录，**${completedRecords}** 项已完成（完成率 ${totalRecords > 0 ? Math.round(completedRecords/totalRecords*100) : 0}%）。\n\n${goals.length > 0 ? `另有 **${goals.length}** 个活跃目标正在追踪中。` : ''}\n\n> 如需生成完整周报，请前往「复盘报告」页面。需要先配置 AI API Key（在 .env 文件中设置 AI_API_KEY）以获得更智能的分析。`;
    } else if (lastMsg.includes('目标') || lastMsg.includes('OKR')) {
      if (goals.length === 0) {
        reply = '当前没有活跃目标。您可以在「目标管理」页面创建 OKR 或 KPI 目标。';
      } else {
        const gList = goals.map(g => {
          const p = g.target_value > 0 ? Math.round(g.actual_value/g.target_value*100) : 0;
          return `- **${g.title}**: ${p}% (${g.actual_value}/${g.target_value} ${g.metric})`;
        }).join('\n');
        reply = `当前 **${goals.length}** 个活跃目标：\n\n${gList}\n\n需要我帮你分析哪个目标的进展情况？`;
      }
    } else if (lastMsg.includes('绩效') || lastMsg.includes('趋势')) {
      const metrics = db.prepare('SELECT * FROM performance_metrics WHERE period_type="weekly" ORDER BY period_start DESC LIMIT 4').all();
      if (metrics.length === 0) {
        reply = '暂无绩效趋势数据。请先生成复盘报告后，系统会自动记录绩效指标。';
      } else {
        const trend = metrics.map(m => `- ${m.period_start}~${m.period_end}: 完成率 ${Math.round(m.completion_rate*100)}%, ${Number(m.total_hours).toFixed(2)}h`).join('\n');
        reply = `最近4周绩效趋势：\n\n${trend}\n\n详情请查看「绩效看板」页面。`;
      }
    } else if (lastMsg.includes('帮助') || lastMsg.includes('功能')) {
      reply = '我是 ReviewMate 复盘助手，可以帮你：\n\n1. 分析工作数据和绩效趋势\n2. 回答关于目标和进度的问题\n3. 协助解读复盘报告指标\n4. 根据导入文件进行分析\n\n你可以直接问我关于你工作记录、目标、绩效的任何问题。';
    } else if (fileContext && fileContext.textContent) {
      // 用户已导入文件，展示文件内容摘要
      const preview = fileContext.textContent.substring(0, 2000);
      reply = `已读取导入的文件 **${fileContext.fileName}**，以下是文件内容摘要：\n\n---\n${preview}${fileContext.textContent.length > 2000 ? '\n...(内容已截断)' : ''}\n---\n\n你可以问我关于此文件的任何问题。\n\n> 提示：在 .env 中配置 AI_API_KEY 可获得更强大的 AI 分析能力，能深度理解文件内容。`;
    } else {
      reply = `你好！我是 ReviewMate 复盘助手。\n\n当前系统数据概况：\n- 总工作记录：**${totalRecords}** 条\n- 本周记录：**${thisWeek}** 条（已完成 ${thisWeekDone} 项）\n- 活跃目标：**${goals.length}** 个\n\n你可以问我关于：\n- 工作数据和绩效趋势\n- 目标进展和 OKR 分析\n- 帮助生成周报/月报\n- 导入文件的分析\n\n> 提示：在 .env 中配置 AI_API_KEY 可获得更强大的 AI 分析能力。`;
    }
  } finally {
    if (db) db.close();
  }

  // 模拟流式输出
  const chars = reply.split('');
  for (let i = 0; i < chars.length; i += 3) {
    const chunk = chars.slice(i, i + 3).join('');
    const msg = {
      id: 'local-' + Date.now(),
      object: 'chat.completion.chunk',
      created: Math.floor(Date.now() / 1000),
      model: 'reviewmate-local',
      choices: [{ index: 0, delta: { content: chunk }, finish_reason: null }],
    };
    res.write(`data: ${JSON.stringify(msg)}\n\n`);
    await new Promise(r => setTimeout(r, 15));
  }

  res.write('data: [DONE]\n\n');
  res.end();
}

module.exports = router;
