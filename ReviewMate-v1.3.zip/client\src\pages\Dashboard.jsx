import { useState, useEffect, useRef } from 'react'
import { api } from '../api'
import { BarChart3, ClipboardCheck, Clock, Target, ArrowUpRight, ArrowDownRight, Minus } from 'lucide-react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'

const TAG_COLORS = ['#1a73e8', '#0d9488', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4', '#84cc16']

// 统计卡片的色彩定义 — 每种颜色一套完整的 bg/icon/text
const STAT_PALETTE = {
  blue:   { bg: '#bfdbfe', dot: '#2563eb', iconBg: '#93bbfd', text: '#1e3a8a' },
  teal:   { bg: '#99f6e4', dot: '#0d9488', iconBg: '#5eead4', text: '#134e4a' },
  amber:  { bg: '#fde68a', dot: '#d97706', iconBg: '#fcd34d', text: '#78350f' },
  purple: { bg: '#ddd6fe', dot: '#7c3aed', iconBg: '#c4b5fd', text: '#4c1d95' },
}

/** 数字滚动 hook — requestAnimationFrame + ease-out expo */
function useCountUp(target, duration = 600) {
  const [display, setDisplay] = useState(target ?? 0)
  const animRef = useRef(null)

  useEffect(() => {
    if (target == null) return
    const to = typeof target === 'string' ? parseFloat(target) : target
    if (isNaN(to)) { setDisplay(target); return }

    const start = performance.now()
    const step = (now) => {
      const elapsed = now - start
      const progress = Math.min(elapsed / duration, 1)
      const t = 1 - Math.pow(1 - progress, 3)
      setDisplay(to < 1 ? Math.round((to * t) * 100) / 100 : Math.round(to * t))
      if (progress < 1) animRef.current = requestAnimationFrame(step)
    }
    animRef.current = requestAnimationFrame(step)
    return () => { if (animRef.current) cancelAnimationFrame(animRef.current) }
  }, [target, duration])

  return display
}

export default function Dashboard() {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    api.getDashboard().then(setData).catch(console.error).finally(() => setLoading(false))
  }, [])

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="flex flex-col items-center gap-3 motion-safe:animate-enter-fade">
        <div className="w-8 h-8 border-2 border-primary-500 border-t-transparent rounded-full animate-spin" />
        <span className="text-sm text-slate-400">加载中...</span>
      </div>
    </div>
  )
  if (!data) return <div className="flex items-center justify-center h-64 text-slate-400 motion-safe:animate-enter-fade">暂无数据</div>

  const tw = data.thisWeek
  const trends = data.trends || []
  const goals = data.goals || []
  const tagData = Object.entries(data.tagDistribution || {}).map(([name, value]) => ({ name, value }))

  const trendChartData = trends.slice().reverse().map((t, i) => ({
    week: `W${i + 1}`,
    完成数: t.completed_tasks,
    任务数: t.total_tasks,
  }))

  const avgGoalProgress = Math.round(goals.reduce((s, g) => s + g.progress, 0) / (goals.length || 1))
  const prevCompletionRate = trends[1]?.completion_rate || 0
  const completionTrend = trends[0]?.completion_rate >= prevCompletionRate ? 'up' : 'down'

  return (
    <div className="space-y-8 max-w-6xl">
      {/* 页面标题 — 更紧凑 */}
      <div className="motion-safe:animate-enter-fade">
        <h2 className="text-2xl font-bold text-slate-800">仪表盘</h2>
        <p className="text-sm text-slate-400 mt-1">本周工作概览与关键指标</p>
      </div>

      {/* ===== 关键指标 — 色底卡片，无边框 ===== */}
      <div className="grid grid-cols-4 gap-3">
        <div className="motion-safe:animate-enter-up" style={{ animationDelay: '0ms' }}>
          <StatCard
            icon={<ClipboardCheck size={18} />}
            label="本周任务"
            value={`${tw.completed}/${tw.total}`}
            sub={`完成率 ${tw.total > 0 ? Math.round(tw.completed / tw.total * 100) : 0}%`}
            palette="blue"
          />
        </div>
        <div className="motion-safe:animate-enter-up" style={{ animationDelay: '80ms' }}>
          <StatCard
            icon={<Clock size={18} />}
            label="投入工时"
            value={`${tw.hours.toFixed(2)}h`}
            sub={renderTrend('完成率', completionTrend)}
            palette="teal"
          />
        </div>
        <div className="motion-safe:animate-enter-up" style={{ animationDelay: '160ms' }}>
          <StatCard
            icon={<Target size={18} />}
            label="目标达成"
            value={`${avgGoalProgress}%`}
            sub={`${goals.length} 个活跃目标`}
            palette="amber"
          />
        </div>
        <div className="motion-safe:animate-enter-up" style={{ animationDelay: '240ms' }}>
          <StatCard
            icon={<BarChart3 size={18} />}
            label="产出密度"
            value={`${(tw.completed / 5).toFixed(1)}`}
            sub="项 / 天"
            palette="purple"
          />
        </div>
      </div>

      {/* ===== 图表区 — 微弱阴影替代边框 ===== */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white rounded-2xl shadow-sm ring-1 ring-slate-900/5 p-6 motion-safe:animate-enter-left" style={{ animationDelay: '350ms' }}>
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-sm font-semibold text-slate-800">任务完成趋势</h3>
              <p className="text-xs text-slate-400 mt-0.5">近 4 周</p>
            </div>
            <div className="flex items-center gap-3 text-xs">
              <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-primary-500" />完成</span>
              <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-slate-200" />总计</span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={trendChartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
              <XAxis dataKey="week" tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} width={28} />
              <Tooltip contentStyle={{ borderRadius: '10px', border: 'none', boxShadow: '0 4px 20px rgba(0,0,0,0.08)', fontSize: '12px' }} />
              <Line type="monotone" dataKey="任务数" stroke="#e2e8f0" strokeWidth={2.5} dot={false} activeDot={{ r: 4, fill: '#cbd5e1' }} animationDuration={1000} />
              <Line type="monotone" dataKey="完成数" stroke="#1a73e8" strokeWidth={2.5} dot={false} activeDot={{ r: 5, fill: '#1a73e8' }} animationDuration={1400} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-2xl shadow-sm ring-1 ring-slate-900/5 p-6 motion-safe:animate-enter-right" style={{ animationDelay: '430ms' }}>
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-sm font-semibold text-slate-800">工作类型分布</h3>
              <p className="text-xs text-slate-400 mt-0.5">按标签统计</p>
            </div>
          </div>
          {tagData.length > 0 ? (
            <div className="flex items-center gap-6">
              <ResponsiveContainer width="55%" height={200}>
                <PieChart>
                  <Pie data={tagData} cx="50%" cy="50%" innerRadius={50} outerRadius={85}
                    paddingAngle={4} dataKey="value" animationBegin={200} animationDuration={900}
                    stroke="none">
                    {tagData.map((_, i) => <Cell key={i} fill={TAG_COLORS[i % TAG_COLORS.length]} />)}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
              <div className="space-y-2.5 text-sm flex-1">
                {tagData.map((t, i) => (
                  <div key={t.name} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: TAG_COLORS[i % TAG_COLORS.length] }} />
                      <span className="text-slate-600 text-xs">{t.name}</span>
                    </div>
                    <span className="text-slate-400 text-xs font-medium">{t.value} 项</span>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-center h-48 text-slate-300 text-sm">
              暂无工作记录数据
            </div>
          )}
        </div>
      </div>

      {/* ===== 目标进展 — 加高进度条 ===== */}
      <div className="bg-white rounded-2xl shadow-sm ring-1 ring-slate-900/5 p-6 motion-safe:animate-enter-up" style={{ animationDelay: '510ms' }}>
        <div className="flex items-center justify-between mb-5">
          <div>
            <h3 className="text-sm font-semibold text-slate-800">目标进展</h3>
            <p className="text-xs text-slate-400 mt-0.5">{goals.length} 个活跃目标</p>
          </div>
          {goals.length > 0 && (
            <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-slate-100 text-slate-500">
              平均 {avgGoalProgress}%
            </span>
          )}
        </div>

        <div className="space-y-4">
          {goals.length === 0 ? (
            <div className="py-8 text-center">
              <span className="text-3xl block mb-2 opacity-30">🎯</span>
              <p className="text-sm text-slate-400">暂无活跃目标</p>
              <p className="text-xs text-slate-300 mt-1">前往「目标管理」页面创建你的第一个目标</p>
            </div>
          ) : (
            goals.map((g, i) => (
              <div key={g.id} className="group">
                <div className="flex justify-between items-baseline mb-1.5">
                  <span className="text-sm text-slate-700 font-medium">{g.title}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-400 font-mono">{g.actual_value}/{g.target_value} {g.metric}</span>
                    <span className={`text-xs font-semibold ${g.progress >= 80 ? 'text-teal-600' : g.progress >= 50 ? 'text-primary-600' : 'text-amber-600'}`}>
                      {g.progress}%
                    </span>
                  </div>
                </div>
                <div className="w-full bg-slate-100 rounded-full h-3 overflow-hidden">
                  <div
                    className="h-3 rounded-full relative overflow-hidden"
                    style={{
                      width: `${g.progress}%`,
                      transition: `width 900ms cubic-bezier(0.25, 1, 0.5, 1)`,
                      transitionDelay: `${510 + i * 100}ms`,
                      backgroundColor: g.progress >= 80 ? '#0d9488' : g.progress >= 50 ? '#1a73e8' : '#f59e0b',
                    }}
                  >
                    <div className="absolute inset-0 motion-safe:animate-shimmer"
                      style={{ background: 'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.3) 50%, transparent 100%)', backgroundSize: '200% 100%' }} />
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  )
}

/** 统计卡片 — 色底无边框 */
function StatCard({ icon, label, value, sub, palette }) {
  const p = STAT_PALETTE[palette]
  const numMatch = String(value).match(/^([\d.]+)/)
  const counted = useCountUp(numMatch ? parseFloat(numMatch[1]) : null)
  const displayValue = numMatch ? String(value).replace(numMatch[1], String(counted)) : value

  return (
    <div
      className="rounded-2xl p-5 h-full motion-safe:transition-shadow"
      style={{
        backgroundColor: p.bg,
        transitionDuration: '300ms',
        transitionTimingFunction: 'cubic-bezier(0.25, 1, 0.5, 1)',
      }}
      onMouseEnter={e => e.currentTarget.style.boxShadow = `0 8px 30px -6px ${p.dot}20`}
      onMouseLeave={e => e.currentTarget.style.boxShadow = 'none'}
    >
      <div className="flex items-center gap-3 mb-3">
        <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ backgroundColor: p.iconBg, color: p.dot }}>
          {icon}
        </div>
        <span className="text-xs font-medium text-slate-500">{label}</span>
      </div>
      <div className="text-2xl font-bold tabular-nums" style={{ color: p.text }}>{displayValue}</div>
      <div className="text-xs text-slate-400 mt-1.5">{sub}</div>
    </div>
  )
}

/** 趋势指示器 */
function renderTrend(label, trend) {
  if (trend === 'up') return <span className="inline-flex items-center gap-0.5 text-teal-600"><ArrowUpRight size={12} />{label}上升</span>
  if (trend === 'down') return <span className="inline-flex items-center gap-0.5 text-red-400"><ArrowDownRight size={12} />{label}下降</span>
  return <span className="inline-flex items-center gap-0.5 text-slate-400"><Minus size={12} />{label}持平</span>
}
