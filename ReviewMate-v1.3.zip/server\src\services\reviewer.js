/**
 * 复盘生成代理 - 基于分析结果生成结构化复盘报告
 */
class ReviewerAgent {
  /**
   * 生成周报
   */
  generateWeeklyReport(stats, periodStart, periodEnd) {
    const sections = [];
    sections.push(this._section('本周完成事项', this._completedTasksReport(stats)));
    sections.push(this._section('未完成事项及原因', this._pendingTasksReport(stats)));
    sections.push(this._section('时间投入分布', this._timeDistributionReport(stats)));
    sections.push(this._section('关键数据', this._keyMetricsReport(stats)));
    sections.push(this._section('亮点与成长', this._highlightsReport(stats)));
    sections.push(this._section('下周计划与需要的支持', this._nextWeekPlan(stats)));
    sections.push(this._section('复盘建议', this._suggestions(stats)));

    return {
      title: `周报 (${periodStart} ~ ${periodEnd})`,
      content: this._buildMarkdown(periodStart, periodEnd, '周报', sections),
      stats
    };
  }

  /**
   * 生成月报
   */
  generateMonthlyReport(stats, periodStart, periodEnd, goals = []) {
    const sections = [];
    sections.push(this._section('月度目标达成', this._goalAchievementReport(goals)));
    sections.push(this._section('重点项目进展', this._projectProgressReport(stats)));
    sections.push(this._section('时间投入分布', this._timeDistributionReport(stats)));
    sections.push(this._section('产出量化统计', this._outputQuantifyReport(stats)));
    sections.push(this._section('能力成长亮点', this._growthReport(stats)));
    sections.push(this._section('经验教训沉淀', this._lessonsReport(stats)));
    sections.push(this._section('下月规划', this._nextMonthPlan(stats, goals)));

    return {
      title: `月报 (${periodStart} ~ ${periodEnd})`,
      content: this._buildMarkdown(periodStart, periodEnd, '月报', sections),
      stats
    };
  }

  /**
   * 生成工作总结
   */
  generateSummaryReport(stats, periodStart, periodEnd, goals = []) {
    const sections = [];
    sections.push(this._section('周期关键成果', this._keyAchievementsReport(stats)));
    sections.push(this._section('能力成长曲线', this._capabilityGrowthReport(stats)));
    sections.push(this._section('价值贡献量化', this._valueContributionReport(stats)));
    sections.push(this._section('经验教训与知识沉淀', this._lessonsReport(stats)));
    sections.push(this._section('下一阶段规划', this._nextPhasePlan(stats, goals)));

    return {
      title: `工作总结 (${periodStart} ~ ${periodEnd})`,
      content: this._buildMarkdown(periodStart, periodEnd, '工作总结', sections),
      stats
    };
  }

  // ---- 各版块生成器 ----

  _completedTasksReport(stats) {
    const lines = [];
    lines.push(`本周期共完成 **${stats.completed_tasks}** 项任务，总投入 **${Number(stats.total_hours).toFixed(2)}** 小时。\n`);
    lines.push('**主要产出：**');
    // 按项目分组展示
    const projects = Object.entries(stats.project_distribution || {});
    for (const [project, count] of projects) {
      const hours = (stats.project_hours || {})[project] || 0;
      lines.push(`- ${project}: ${count}项任务，${Number(hours).toFixed(2)}小时`);
    }
    return lines.join('\n');
  }

  _pendingTasksReport(stats) {
    if (stats.completion_rate >= 0.9) {
      return '本周期任务基本全部完成，无遗留事项。';
    }
    const pending = stats.total_tasks - stats.completed_tasks;
    return `本周期有 **${pending}** 项任务未完成，建议重新评估优先级，必要时拆分或延期到下周期。`;
  }

  _timeDistributionReport(stats) {
    const lines = ['| 类别 | 占比 | 说明 |', '|------|------|------|'];
    const tags = stats.tag_distribution || {};
    const total = Object.values(tags).reduce((s, v) => s + v, 0) || 1;
    const sorted = Object.entries(tags).sort((a, b) => b[1] - a[1]);
    for (const [tag, count] of sorted) {
      const pct = ((count / total) * 100).toFixed(1);
      const bar = '█'.repeat(Math.round(count / total * 20));
      lines.push(`| ${tag} | ${pct}% ${bar} | ${count}项任务 |`);
    }
    return lines.join('\n');
  }

  _keyMetricsReport(stats) {
    const lines = [];
    lines.push(`| 指标 | 数值 | 评价 |`);
    lines.push(`|------|------|------|`);
    lines.push(`| 任务完成率 | ${(stats.completion_rate * 100).toFixed(0)}% | ${this._rateLabel(stats.completion_rate)} |`);
    lines.push(`| 总投入时间 | ${Number(stats.total_hours).toFixed(2)}h | — |`);
    lines.push(`| 产出密度 | ${stats.output_density}项/天 | ${stats.output_density >= 4 ? '高效' : '正常'} |`);
    lines.push(`| 工作天数 | ${stats.work_days}天 | — |`);
    if (stats.estimation_accuracy > 0) {
      const label = stats.estimation_accuracy <= 1.2 ? '预估准确' : '低估工作量';
      lines.push(`| 预估准确率 | ${(stats.estimation_accuracy * 100).toFixed(0)}% | ${label} |`);
    }
    if (stats.goal_achievement_rate > 0) {
      lines.push(`| 目标达成率 | ${(stats.goal_achievement_rate * 100).toFixed(0)}% | ${this._rateLabel(stats.goal_achievement_rate)} |`);
    }
    return lines.join('\n');
  }

  _highlightsReport(stats) {
    const items = stats.highlights || [];
    if (items.length === 0) return '暂无突出亮点记录。';
    return items.map(h => `- ${h}`).join('\n');
  }

  _nextWeekPlan(stats) {
    const lines = [];
    lines.push('**计划重点：**');
    lines.push('- 持续推动本周未完成事项的收尾');
    lines.push('- 关注标签中薄弱环节的能力提升');
    lines.push('\n**需要的支持：**');
    lines.push('- 如遇阻塞及时沟通，需要协助的事项请明确提出');
    return lines.join('\n');
  }

  _suggestions(stats) {
    const lines = [];
    if (stats.completion_rate < 0.7) {
      lines.push('- 任务完成率偏低，建议审视任务拆分粒度，单任务控制在4小时内');
    }
    if (stats.work_days > 0 && stats.total_hours / stats.work_days > 10) {
      lines.push('- 日均工时超过10小时，建议关注工作节奏，避免过度疲劳');
    }
    if (stats.output_density < 2) {
      lines.push('- 产出密度较低，建议检查是否存在过多上下文切换或会议占用');
    }
    if (Object.keys(stats.tag_distribution || {}).length <= 1) {
      lines.push('- 工作类型单一，建议适当丰富技能应用场景');
    }
    if (lines.length === 0) {
      lines.push('- 本周期表现均衡稳定，保持现有节奏即可');
    }
    return lines.join('\n');
  }

  _goalAchievementReport(goals) {
    if (!goals || goals.length === 0) return '本周期暂未设定具体目标。';
    const lines = [];
    goals.forEach(g => {
      const rate = g.target_value > 0 ? (g.actual_value / g.target_value * 100).toFixed(0) : 0;
      const bar = '█'.repeat(Math.round(rate / 10));
      const empty = '░'.repeat(10 - Math.round(rate / 10));
      lines.push(`- **${g.title}**: ${bar}${empty} ${rate}% (${g.actual_value}/${g.target_value} ${g.metric})`);
    });
    return lines.join('\n');
  }

  _projectProgressReport(stats) {
    const lines = ['| 项目 | 任务数 | 投入时间 | 占比 |', '|------|--------|----------|------|'];
    const projects = Object.entries(stats.project_distribution || {});
    const total = projects.reduce((s, [, c]) => s + c, 0) || 1;
    for (const [proj, count] of projects) {
      const hours = (stats.project_hours || {})[proj] || 0;
      const pct = ((count / total) * 100).toFixed(1);
      lines.push(`| ${proj} | ${count} | ${Number(hours).toFixed(2)}h | ${pct}% |`);
    }
    return lines.join('\n');
  }

  _outputQuantifyReport(stats) {
    const lines = [];
    lines.push(`- 总完成任务数：**${stats.completed_tasks}** 项`);
    lines.push(`- 总投入工时：**${Number(stats.total_hours).toFixed(2)}** 小时`);
    lines.push(`- 日均产出：**${stats.output_density}** 项/天`);
    lines.push(`- 任务完成率：**${(stats.completion_rate * 100).toFixed(0)}%**`);
    return lines.join('\n');
  }

  _growthReport(stats) {
    const lines = [];
    const tags = stats.tag_distribution || {};
    const sorted = Object.entries(tags).sort((a, b) => b[1] - a[1]);
    if (sorted.length > 0) {
      lines.push(`本月在 **${sorted[0][0]}** 领域投入最多（${sorted[0][1]}项），持续深耕中。`);
    }
    if (sorted.length > 1) {
      lines.push(`**${sorted[1][0]}** 方面也有显著积累，技能组合更加多元。`);
    }
    if (stats.completion_rate >= 0.85) {
      lines.push('任务交付效率稳定提升，时间管理能力表现优秀。');
    }
    return lines.join('\n');
  }

  _lessonsReport(stats) {
    const lowlights = stats.lowlights || [];
    if (lowlights.length === 0) return '本周期运行平稳，无重大经验教训记录。';
    return lowlights.map(l => `- ${l}`).join('\n');
  }

  _nextMonthPlan(stats, goals) {
    const lines = [];
    lines.push('**重点方向：**');
    if (goals && goals.length > 0) {
      const pendingGoals = goals.filter(g => g.actual_value < g.target_value);
      for (const g of pendingGoals) {
        lines.push(`- 继续推进「${g.title}」目标（当前进度 ${(g.actual_value/g.target_value*100).toFixed(0)}%）`);
      }
    }
    lines.push('- 关注时间利用效率，减少上下文切换');
    return lines.join('\n');
  }

  _keyAchievementsReport(stats) {
    const lines = [];
    lines.push(`本周期跨越 ${stats.work_days} 个工作日，累计完成 **${stats.completed_tasks}** 项工作，投入 **${Number(stats.total_hours).toFixed(2)}** 小时。`);
    lines.push('');
    lines.push('**核心成果：**');
    const highlights = stats.highlights || [];
    for (const h of highlights) {
      lines.push(`- ${h}`);
    }
    return lines.join('\n');
  }

  _capabilityGrowthReport(stats) {
    const lines = [];
    const tags = stats.tag_distribution || {};
    const tagCount = Object.keys(tags).length;
    lines.push(`- 技能覆盖面：涉及 **${tagCount}** 个领域`);
    if (tagCount >= 5) {
      lines.push('- 技能组合丰富，具备较好的T型人才特征');
    }
    lines.push(`- 任务完成率：${(stats.completion_rate * 100).toFixed(0)}%，交付能力${stats.completion_rate >= 0.85 ? '强' : '有待提升'}`);
    return lines.join('\n');
  }

  _valueContributionReport(stats) {
    const lines = [];
    lines.push(`- 总工时投入：${Number(stats.total_hours).toFixed(2)}h`);
    lines.push(`- 覆盖项目数：${Object.keys(stats.project_distribution || {}).length} 个`);
    if (stats.goal_achievement_rate > 0) {
      lines.push(`- 目标达成率：${(stats.goal_achievement_rate * 100).toFixed(0)}%`);
    }
    return lines.join('\n');
  }

  _nextPhasePlan(stats, goals) {
    const lines = ['**建议下一阶段聚焦：**'];
    const tags = stats.tag_distribution || {};
    const sorted = Object.entries(tags).sort((a, b) => b[1] - a[1]);
    if (sorted.length > 0) {
      lines.push(`1. 深耕 **${sorted[0][0]}** 领域，建立专业深度`);
    }
    lines.push('2. 设定明确的季度目标，将长期规划拆解为月度里程碑');
    lines.push('3. 定期进行小型复盘，形成持续改进的正反馈循环');
    return lines.join('\n');
  }

  // ---- 工具方法 ----

  _section(title, content) {
    return `## ${title}\n\n${content}`;
  }

  _buildMarkdown(start, end, type, sections) {
    const header = [
      `# 📊 ${type}报告`,
      ``,
      `> 周期：${start} 至 ${end}`,
      `> 生成时间：${new Date().toLocaleString('zh-CN')}`,
      ``,
      `---`,
      ``
    ];
    return header.join('\n') + sections.join('\n\n---\n\n');
  }

  _rateLabel(rate) {
    if (rate >= 0.9) return '优秀';
    if (rate >= 0.7) return '良好';
    if (rate >= 0.5) return '一般';
    return '待改进';
  }
}

module.exports = new ReviewerAgent();
