import { useState } from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import SplashScreen from './components/SplashScreen'
import Dashboard from './pages/Dashboard'
import WorkRecords from './pages/WorkRecords'
import Performance from './pages/Performance'
import Reports from './pages/Reports'
import Goals from './pages/Goals'
import Settings from './pages/Settings'

export default function App() {
  const [splashDone, setSplashDone] = useState(false)

  return (
    <>
      {!splashDone && <SplashScreen onEnter={() => setSplashDone(true)} />}
      <BrowserRouter>
        {splashDone && (
          <Routes>
            <Route path="/" element={<Layout />}>
              <Route index element={<Dashboard />} />
              <Route path="records" element={<WorkRecords />} />
              <Route path="performance" element={<Performance />} />
              <Route path="reports" element={<Reports />} />
              <Route path="goals" element={<Goals />} />
              <Route path="settings" element={<Settings />} />
            </Route>
          </Routes>
        )}
      </BrowserRouter>
    </>
  )
}
