const { getDb } = require('../db/init');

/**
 * 获取 AI 配置（优先从数据库读取，支持运行时更新；其次从环境变量）
 * 供 ai.js 和 reports.js 共用
 */
function getAiConfig() {
  let config = {
    baseURL: process.env.AI_API_URL || 'https://api.openai.com/v1',
    apiKey: process.env.AI_API_KEY || '',
    model: process.env.AI_MODEL || 'gpt-4o-mini',
  };
  try {
    const db = getDb();
    const settings = db.prepare('SELECT key, value FROM settings WHERE key IN (?, ?, ?)')
      .all('ai_api_url', 'ai_api_key', 'ai_model');
    db.close();
    const map = {};
    settings.forEach(s => { map[s.key] = s.value; });
    if (map.ai_api_url) config.baseURL = map.ai_api_url;
    if (map.ai_api_key) config.apiKey = map.ai_api_key;
    if (map.ai_model) config.model = map.ai_model;
  } catch (e) {
    // DB 读取失败时使用 env 配置
  }
  return config;
}

module.exports = { getAiConfig };
