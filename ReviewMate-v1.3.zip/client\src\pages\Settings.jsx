import { useState, useEffect } from 'react'
import { api } from '../api'
import { Save, Key, Globe, Shield, Database, FolderOpen, ArrowRightLeft, AlertCircle, CheckCircle, Power, X, PlusCircle, ArrowRight } from 'lucide-react'

const EMPTY_SAVE_MSG = {}

export default function Settings() {
  const [settings, setSettings] = useState({})
  const [workDir, setWorkDir] = useState('')
  const [aiApiUrl, setAiApiUrl] = useState('')
  const [aiApiKey, setAiApiKey] = useState('')
  const [aiKeyConfigured, setAiKeyConfigured] = useState(false)
  const [aiModel, setAiModel] = useState('')
  const [loading, setLoading] = useState(true)
  const [loadError, setLoadError] = useState('')
  const [saving, setSaving] = useState({})
  const [saveMsg, setSaveMsg] = useState(EMPTY_SAVE_MSG) // { [key]: { type: 'success'|'error', text: string } }

  // 数据库管理
  const [dbInfo, setDbInfo] = useState(null)
  const [newDbPath, setNewDbPath] = useState('')
  const [switchDbPath, setSwitchDbPath] = useState('')
  const [moveDbPath, setMoveDbPath] = useState('')
  const [dbActionLoading, setDbActionLoading] = useState(false)
  const [dbMsg, setDbMsg] = useState(null)   // { type, text, key: 'new'|'switch'|'move' }
  const [restarting, setRestarting] = useState(false)

  // 飞书配置
  const [feishuAppId, setFeishuAppId] = useState('')
  const [feishuAppSecret, setFeishuAppSecret] = useState('')
  const [feishuSecretConfigured, setFeishuSecretConfigured] = useState(false)

  // 下载路径
  const [downloadPath, setDownloadPath] = useState('')
  const [downloadPathLoading, setDownloadPathLoading] = useState(false)

  useEffect(() => {
    api.getSettings().then(s => {
      setSettings(s)
      setWorkDir(s.work_dir || '')
      setAiApiUrl(s.ai_api_url || '')
      // 脱敏后的 key 只用于显示"已配置"状态，不填入输入框
      if (s.ai_api_key && s.ai_api_key.includes('*')) {
        setAiApiKey('')  // 已配置，输入框留空
        setAiKeyConfigured(true)
      } else {
        setAiApiKey(s.ai_api_key || '')
        setAiKeyConfigured(false)
      }
      setAiModel(s.ai_model || '')
      setFeishuAppId(s.feishu_app_id || '')
      // 飞书 Secret 同理脱敏
      if (s.feishu_app_secret && s.feishu_app_secret.includes('*')) {
        setFeishuAppSecret('')
        setFeishuSecretConfigured(true)
      } else {
        setFeishuAppSecret(s.feishu_app_secret || '')
        setFeishuSecretConfigured(false)
      }
    }).catch(e => {
      console.error(e)
      setLoadError(e.message || '无法连接后端服务，请确认后端已启动 (端口 3001)')
    }).finally(() => setLoading(false))

    loadDbInfo()
    loadDownloadPath()
  }, [])

  const loadDownloadPath = async () => {
    try {
      const result = await api.getDownloadPath()
      setDownloadPath(result.path)
    } catch (e) { console.error('获取下载路径失败:', e) }
  }

  const loadDbInfo = async () => {
    try {
      const info = await api.getDbInfo()
      setDbInfo(info)
    } catch (e) { console.error('获取数据库信息失败:', e) }
  }

  const handleSave = async (key, value, label) => {
    setSaving(prev => ({ ...prev, [key]: true }))
    setSaveMsg(prev => ({ ...prev, [key]: null }))
    try {
      await api.updateSetting(key, value)
      setSaveMsg(prev => ({ ...prev, [key]: { type: 'success', text: `${label}已保存` } }))
      // 3秒后自动清除消息
      setTimeout(() => setSaveMsg(prev => ({ ...prev, [key]: null })), 3000)
    } catch (e) {
      console.error(`保存 ${label} 失败:`, e)
      setSaveMsg(prev => ({ ...prev, [key]: { type: 'error', text: e.message || '保存失败' } }))
    } finally { setSaving(prev => ({ ...prev, [key]: false })) }
  }

  const handleMoveDb = async () => {
    if (!moveDbPath) { setDbMsg({ type: 'error', text: '请输入目标路径', key: 'move' }); return }
    setDbActionLoading(true)
    setDbMsg(null)
    try {
      const result = await api.moveDb(moveDbPath)
      setDbMsg({ type: 'success', text: result.message, key: 'move' })
      setMoveDbPath('')
      loadDbInfo()
    } catch (e) {
      setDbMsg({ type: 'error', text: e.message, key: 'move' })
    } finally {
      setDbActionLoading(false)
    }
  }

  const handleNewDb = async () => {
    if (!newDbPath) { setDbMsg({ type: 'error', text: '请输入新数据库路径', key: 'new' }); return }
    setDbActionLoading(true)
    setDbMsg(null)
    try {
      const result = await api.newDb(newDbPath)
      setDbMsg({ type: 'success', text: result.message, key: 'new' })
      setNewDbPath('')
      loadDbInfo()
    } catch (e) {
      setDbMsg({ type: 'error', text: e.message, key: 'new' })
    } finally {
      setDbActionLoading(false)
    }
  }

  const handleSwitchDb = async () => {
    if (!switchDbPath) { setDbMsg({ type: 'error', text: '请输入数据库文件路径', key: 'switch' }); return }
    setDbActionLoading(true)
    setDbMsg(null)
    try {
      const result = await api.switchDb(switchDbPath)
      setDbMsg({ type: 'success', text: result.message, key: 'switch' })
      setSwitchDbPath('')
      loadDbInfo()
    } catch (e) {
      setDbMsg({ type: 'error', text: e.message, key: 'switch' })
    } finally {
      setDbActionLoading(false)
    }
  }

  const handleOpenDbFolder = async () => {
    setDbActionLoading(true)
    try {
      await api.openDbFolder()
    } catch (e) {
      alert('无法打开文件夹: ' + e.message)
    } finally {
      setDbActionLoading(false)
    }
  }

  const handleOpenDownloadFolder = async () => {
    setDownloadPathLoading(true)
    try {
      await api.openDownloadFolder()
    } catch (e) {
      alert('无法打开文件夹: ' + e.message)
    } finally {
      setDownloadPathLoading(false)
    }
  }

  const handleRestartServer = async () => {
    if (!confirm('确定要重启后端服务吗？')) return
    setRestarting(true)
    try {
      await api.restartServer()
    } catch (e) {
      // 重启后请求会中断，这是正常的
    }
    setRestarting(false)
  }

  if (loading) return <div className="flex items-center justify-center h-64 text-slate-400">加载中...</div>

  if (loadError) return (
    <div className="flex flex-col items-center justify-center h-64 text-slate-500 gap-3">
      <span className="text-4xl">⚠️</span>
      <p className="text-sm">{loadError}</p>
      <button
        onClick={() => { setLoadError(''); setLoading(true); window.location.reload() }}
        className="px-4 py-2 text-sm bg-primary-500 text-white rounded-lg hover:bg-primary-600"
      >
        重试
      </button>
    </div>
  )

  return (
    <div className="space-y-4 max-w-2xl">
      <div>
        <h2 className="text-2xl font-bold text-slate-800">设置</h2>
        <p className="text-sm text-slate-500 mt-1">配置系统参数</p>
      </div>

      {/* 工作目录配置 */}
      <div className="bg-white rounded-xl border border-slate-200 p-5">
        <h3 className="text-sm font-semibold text-slate-700 mb-4">工作目录配置</h3>
        <div className="space-y-3">
          <div>
            <label className="block text-xs text-slate-500 mb-1">工作日志目录路径</label>
            <input
              type="text" value={workDir}
              onChange={e => setWorkDir(e.target.value)}
              className="w-full border border-slate-300 rounded-md px-3 py-2 text-sm"
              placeholder="C:\Users\xxx\work-logs"
            />
            <p className="text-xs text-slate-400 mt-1">系统将在该目录下扫描 .md / .txt / .json / .csv 文件作为工作记录来源</p>
          </div>
          <button onClick={() => handleSave('work_dir', workDir, '工作目录')} disabled={saving.work_dir}
            className="flex items-center gap-2 px-4 py-2 text-sm bg-primary-500 text-white rounded-lg hover:bg-primary-600 disabled:opacity-50">
            <Save size={14} /> {saving.work_dir ? '保存中...' : '保存设置'}
          </button>
          {saveMsg.work_dir && <SaveStatusMsg msg={saveMsg.work_dir} onDismiss={() => setSaveMsg(prev => ({ ...prev, work_dir: null }))} />}
        </div>
      </div>

      {/* 文件下载路径配置 */}
      <div className="bg-white rounded-xl border border-slate-200 p-5">
        <h3 className="text-sm font-semibold text-slate-700 mb-4">文件下载路径</h3>
        <div className="space-y-3">
          <div>
            <label className="block text-xs text-slate-500 mb-1">AI 生成文件的保存目录</label>
            <input
              type="text" value={downloadPath}
              onChange={e => setDownloadPath(e.target.value)}
              className="w-full border border-slate-300 rounded-md px-3 py-2 text-sm"
              placeholder="C:\Users\xxx\Downloads\ReviewMate"
            />
            <p className="text-xs text-slate-400 mt-1">AI 生成的 PPT、Word 等文件将保存到此目录</p>
          </div>
          <div className="flex gap-2">
            <button onClick={() => handleSave('download_path', downloadPath, '下载路径')} disabled={saving.download_path}
              className="flex items-center gap-2 px-4 py-2 text-sm bg-primary-500 text-white rounded-lg hover:bg-primary-600 disabled:opacity-50">
              <Save size={14} /> {saving.download_path ? '保存中...' : '保存设置'}
            </button>
            <button onClick={handleOpenDownloadFolder} disabled={downloadPathLoading}
              className="flex items-center gap-2 px-4 py-2 text-sm bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 disabled:opacity-50 border border-slate-200">
              <FolderOpen size={14} /> 打开文件夹
            </button>
          </div>
          {saveMsg.download_path && <SaveStatusMsg msg={saveMsg.download_path} onDismiss={() => setSaveMsg(prev => ({ ...prev, download_path: null }))} />}
        </div>
      </div>

      {/* AI API 配置 */}
      <div className="bg-white rounded-xl border border-slate-200 p-5">
        <div className="flex items-center gap-2 mb-4">
          <span className="text-base">🤖</span>
          <h3 className="text-sm font-semibold text-slate-700">AI API 配置</h3>
        </div>
        <p className="text-xs text-slate-400 mb-4">配置后 AI 助手将使用大模型提供智能分析；留空则使用本地规则引擎</p>

        <div className="space-y-3">
          <div>
            <label className="block text-xs text-slate-500 mb-1 flex items-center gap-1">
              <Globe size={12} /> API 地址
            </label>
            <div className="flex gap-2">
              <input
                type="text" value={aiApiUrl}
                onChange={e => setAiApiUrl(e.target.value)}
                className="flex-1 border border-slate-300 rounded-md px-3 py-2 text-sm"
                placeholder="https://api.openai.com/v1"
              />
              <button
                onClick={() => handleSave('ai_api_url', aiApiUrl, 'API 地址')}
                disabled={saving.ai_api_url}
                className="px-3 py-2 text-xs bg-primary-500 text-white rounded-md hover:bg-primary-600 disabled:opacity-50 shrink-0"
              >
                {saving.ai_api_url ? '...' : '保存'}
              </button>
            </div>
            {saveMsg.ai_api_url && <SaveStatusMsg msg={saveMsg.ai_api_url} onDismiss={() => setSaveMsg(prev => ({ ...prev, ai_api_url: null }))} />}
            <p className="text-xs text-slate-400 mt-1">支持 OpenAI 兼容接口（如 OpenAI、Azure、本地模型等）</p>
          </div>

          <div>
            <label className="block text-xs text-slate-500 mb-1 flex items-center gap-1">
              <Key size={12} /> API Key
              {aiKeyConfigured && <span className="text-green-500 text-xs">(已配置)</span>}
            </label>
            <div className="flex gap-2">
              <input
                type="password" value={aiApiKey}
                onChange={e => { setAiApiKey(e.target.value); setAiKeyConfigured(false) }}
                className="flex-1 border border-slate-300 rounded-md px-3 py-2 text-sm font-mono"
                placeholder={aiKeyConfigured ? '已配置，如需更换请重新输入' : 'sk-xxxxxxxxxxxxxxxx'}
              />
              <button
                onClick={() => {
                  if (!aiApiKey && aiKeyConfigured) return  // 没输入新key且已配置，不保存
                  handleSave('ai_api_key', aiApiKey, 'API Key')
                  if (aiApiKey) setAiKeyConfigured(true)
                }}
                disabled={saving.ai_api_key}
                className="px-3 py-2 text-xs bg-primary-500 text-white rounded-md hover:bg-primary-600 disabled:opacity-50 shrink-0"
              >
                {saving.ai_api_key ? '...' : '保存'}
              </button>
            </div>
            {saveMsg.ai_api_key && <SaveStatusMsg msg={saveMsg.ai_api_key} onDismiss={() => setSaveMsg(prev => ({ ...prev, ai_api_key: null }))} />}
            <div className="flex items-center gap-1 mt-1 text-xs text-slate-400">
              <Shield size={10} />
              <span>Key 存储于本地数据库，不会上传第三方</span>
            </div>
          </div>

          <div>
            <label className="block text-xs text-slate-500 mb-1 flex items-center gap-1">
              <span>📋</span> 模型名称
            </label>
            <div className="flex gap-2">
              <input
                type="text" value={aiModel}
                onChange={e => setAiModel(e.target.value)}
                className="flex-1 border border-slate-300 rounded-md px-3 py-2 text-sm"
                placeholder="gpt-4o-mini"
              />
              <button
                onClick={() => handleSave('ai_model', aiModel, '模型名称')}
                disabled={saving.ai_model}
                className="px-3 py-2 text-xs bg-primary-500 text-white rounded-md hover:bg-primary-600 disabled:opacity-50 shrink-0"
              >
                {saving.ai_model ? '...' : '保存'}
              </button>
            </div>
            {saveMsg.ai_model && <SaveStatusMsg msg={saveMsg.ai_model} onDismiss={() => setSaveMsg(prev => ({ ...prev, ai_model: null }))} />}
            <p className="text-xs text-slate-400 mt-1">如 gpt-4o-mini / gpt-4o / deepseek-chat 等</p>
          </div>
        </div>
      </div>

      {/* 飞书配置 */}
      <div className="bg-white rounded-xl border border-slate-200 p-5">
        <div className="flex items-center gap-2 mb-4">
          <span className="text-base">📅</span>
          <h3 className="text-sm font-semibold text-slate-700">飞书集成</h3>
        </div>
        <p className="text-xs text-slate-400 mb-4">配置飞书应用的 App ID 和 App Secret，用于从飞书日历和任务中导入工作记录</p>

        <div className="space-y-3">
          <div>
            <label className="block text-xs text-slate-500 mb-1">App ID</label>
            <div className="flex gap-2">
              <input
                type="text" value={feishuAppId}
                onChange={e => setFeishuAppId(e.target.value)}
                className="flex-1 border border-slate-300 rounded-md px-3 py-2 text-sm font-mono"
                placeholder="cli_xxxxxxxxxxxxxxxx"
              />
              <button
                onClick={() => handleSave('feishu_app_id', feishuAppId, '飞书 App ID')}
                disabled={saving.feishu_app_id}
                className="px-3 py-2 text-xs bg-primary-500 text-white rounded-md hover:bg-primary-600 disabled:opacity-50 shrink-0"
              >
                {saving.feishu_app_id ? '...' : '保存'}
              </button>
            </div>
            {saveMsg.feishu_app_id && <SaveStatusMsg msg={saveMsg.feishu_app_id} onDismiss={() => setSaveMsg(prev => ({ ...prev, feishu_app_id: null }))} />}
          </div>

          <div>
            <label className="block text-xs text-slate-500 mb-1">App Secret
              {feishuSecretConfigured && <span className="text-green-500 text-xs ml-1">(已配置)</span>}
            </label>
            <div className="flex gap-2">
              <input
                type="password" value={feishuAppSecret}
                onChange={e => { setFeishuAppSecret(e.target.value); setFeishuSecretConfigured(false) }}
                className="flex-1 border border-slate-300 rounded-md px-3 py-2 text-sm font-mono"
                placeholder={feishuSecretConfigured ? '已配置，如需更换请重新输入' : '飞书应用 Secret'}
              />
              <button
                onClick={() => {
                  if (!feishuAppSecret && feishuSecretConfigured) return
                  handleSave('feishu_app_secret', feishuAppSecret, '飞书 App Secret')
                  if (feishuAppSecret) setFeishuSecretConfigured(true)
                }}
                disabled={saving.feishu_app_secret}
                className="px-3 py-2 text-xs bg-primary-500 text-white rounded-md hover:bg-primary-600 disabled:opacity-50 shrink-0"
              >
                {saving.feishu_app_secret ? '...' : '保存'}
              </button>
            </div>
            {saveMsg.feishu_app_secret && <SaveStatusMsg msg={saveMsg.feishu_app_secret} onDismiss={() => setSaveMsg(prev => ({ ...prev, feishu_app_secret: null }))} />}
          </div>
        </div>

        <div className="mt-3 p-2 bg-slate-50 rounded-md text-xs text-slate-400">
          配置后可在「工作记录」页面点击「从飞书导入」获取飞书日历事件和任务
        </div>
      </div>

      {/* 数据管理 */}
      <div className="bg-white rounded-xl border border-slate-200 p-5">
        <h3 className="text-sm font-semibold text-slate-700 mb-4">数据管理</h3>

        {/* 数据库信息 */}
        {dbInfo && (
          <div className="mb-4 p-3 bg-slate-50 rounded-lg border border-slate-100">
            <div className="flex items-center gap-2 mb-2">
              <Database size={14} className="text-slate-500" />
              <span className="text-xs font-semibold text-slate-600">当前数据库</span>
            </div>
            <div className="space-y-1 text-xs text-slate-500">
              <div className="flex justify-between">
                <span>文件路径：</span>
                <span className="text-slate-400 font-mono truncate ml-2 max-w-[260px]">{dbInfo.path}</span>
              </div>
              <div className="flex justify-between">
                <span>文件大小：</span>
                <span>{dbInfo.sizeMB} MB</span>
              </div>
              <div className="flex justify-between">
                <span>最后修改：</span>
                <span>{new Date(dbInfo.modifiedAt).toLocaleString()}</span>
              </div>
              {dbInfo.tables && (
                <div className="mt-2 pt-2 border-t border-slate-200">
                  <span className="text-slate-400">数据统计：</span>
                  <div className="grid grid-cols-3 gap-x-4 gap-y-0.5 mt-1">
                    <span className="text-slate-500">工作记录 <b className="text-slate-700">{dbInfo.tables.work_records}</b></span>
                    <span className="text-slate-500">绩效指标 <b className="text-slate-700">{dbInfo.tables.performance_metrics}</b></span>
                    <span className="text-slate-500">目标 <b className="text-slate-700">{dbInfo.tables.goals}</b></span>
                    <span className="text-slate-500">复盘报告 <b className="text-slate-700">{dbInfo.tables.review_reports}</b></span>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* 新建数据库 */}
        <div className="mb-3 p-3 bg-green-50 rounded-lg border border-green-100">
          <div className="flex items-center gap-2 mb-2">
            <PlusCircle size={14} className="text-green-600" />
            <span className="text-xs font-semibold text-green-700">新建数据库</span>
          </div>
          <p className="text-xs text-green-600 mb-2">创建一个全新的空数据库文件</p>
          <div className="flex gap-2">
            <input
              type="text" value={newDbPath}
              onChange={e => setNewDbPath(e.target.value)}
              className="flex-1 border border-green-300 rounded-md px-3 py-2 text-sm bg-white"
              placeholder="如 D:\data\new-reviewmate.db"
            />
            <button onClick={handleNewDb} disabled={dbActionLoading}
              className="px-3 py-2 text-xs bg-green-500 text-white rounded-md hover:bg-green-600 disabled:opacity-50 shrink-0">
              {dbActionLoading ? '...' : '新建'}
            </button>
          </div>
          {dbMsg?.key === 'new' && <ActionMsg msg={dbMsg} onDismiss={() => setDbMsg(null)} />}
        </div>

        {/* 切换数据库 */}
        <div className="mb-3 p-3 bg-blue-50 rounded-lg border border-blue-100">
          <div className="flex items-center gap-2 mb-2">
            <ArrowRight size={14} className="text-blue-600" />
            <span className="text-xs font-semibold text-blue-700">切换数据库</span>
          </div>
          <p className="text-xs text-blue-600 mb-2">切换到已存在的数据库文件（如从备份恢复）</p>
          <div className="flex gap-2">
            <input
              type="text" value={switchDbPath}
              onChange={e => setSwitchDbPath(e.target.value)}
              className="flex-1 border border-blue-300 rounded-md px-3 py-2 text-sm bg-white"
              placeholder="如 D:\backup\reviewmate.db"
            />
            <button onClick={handleSwitchDb} disabled={dbActionLoading}
              className="px-3 py-2 text-xs bg-blue-500 text-white rounded-md hover:bg-blue-600 disabled:opacity-50 shrink-0">
              {dbActionLoading ? '...' : '切换'}
            </button>
          </div>
          {dbMsg?.key === 'switch' && <ActionMsg msg={dbMsg} onDismiss={() => setDbMsg(null)} />}
        </div>

        {/* 迁移数据库 */}
        <div className="mb-4 p-3 bg-amber-50 rounded-lg border border-amber-100">
          <div className="flex items-center gap-2 mb-2">
            <ArrowRightLeft size={14} className="text-amber-600" />
            <span className="text-xs font-semibold text-amber-700">迁移数据库</span>
          </div>
          <p className="text-xs text-amber-600 mb-2">将当前数据库及所有数据复制到新位置（原文件保留）</p>
          <div className="flex gap-2">
            <input
              type="text" value={moveDbPath}
              onChange={e => setMoveDbPath(e.target.value)}
              className="flex-1 border border-amber-300 rounded-md px-3 py-2 text-sm bg-white"
              placeholder="如 D:\data\reviewmate.db"
            />
            <button onClick={handleMoveDb} disabled={dbActionLoading}
              className="px-3 py-2 text-xs bg-amber-500 text-white rounded-md hover:bg-amber-600 disabled:opacity-50 shrink-0">
              {dbActionLoading ? '迁移中...' : '迁移'}
            </button>
          </div>
          {dbMsg?.key === 'move' && <ActionMsg msg={dbMsg} onDismiss={() => setDbMsg(null)} />}
        </div>

        {/* 操作按钮行 */}
        <div className="flex gap-2 mb-2">
          <button onClick={handleOpenDbFolder} disabled={dbActionLoading}
            className="flex items-center gap-2 px-4 py-2 text-sm bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 disabled:opacity-50 border border-slate-200">
            <FolderOpen size={14} /> 打开文件夹
          </button>
          <button onClick={handleRestartServer} disabled={restarting}
            className="flex items-center gap-2 px-4 py-2 text-sm bg-red-50 text-red-600 rounded-lg hover:bg-red-100 disabled:opacity-50 border border-red-200">
            <Power size={14} /> {restarting ? '重启中...' : '重启服务'}
          </button>
        </div>

        <p className="text-xs text-slate-400 mt-2">操作即时生效，无需重启。数据仅存储在本地，不上传云端。</p>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 p-5">
        <h3 className="text-sm font-semibold text-slate-700 mb-4">关于 ReviewMate</h3>
        <div className="space-y-2 text-sm text-slate-500">
          <p>ReviewMate 是一款专注于职场员工考评与工作复盘的智能代理系统。</p>
          <p>版本：1.0.0</p>
          <p>核心能力：自动读取工作记录、统计分析、生成复盘报告、历史绩效追踪</p>
        </div>
      </div>
    </div>
  )
}

/** 操作结果提示组件 */
function ActionMsg({ msg, onDismiss }) {
  if (!msg) return null
  const isSuccess = msg.type === 'success'
  return (
    <div className={`mt-2 flex items-start gap-1.5 text-xs p-2 rounded ${isSuccess ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-600'}`}>
      {isSuccess ? <CheckCircle size={12} className="mt-0.5 shrink-0" /> : <AlertCircle size={12} className="mt-0.5 shrink-0" />}
      <span className="flex-1">{msg.text}</span>
      <button onClick={onDismiss} className="ml-1 hover:opacity-70 shrink-0"><X size={12} /></button>
    </div>
  )
}

/** 保存操作的状态提示组件 */
function SaveStatusMsg({ msg, onDismiss }) {
  if (!msg) return null
  const isSuccess = msg.type === 'success'
  return (
    <div className={`mt-1.5 flex items-center gap-1.5 text-xs px-2 py-1 rounded ${isSuccess ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-600'}`}>
      {isSuccess ? <CheckCircle size={12} /> : <AlertCircle size={12} />}
      <span className="flex-1">{msg.text}</span>
      <button onClick={onDismiss} className="ml-1 hover:opacity-70">
        <X size={12} />
      </button>
    </div>
  )
}
