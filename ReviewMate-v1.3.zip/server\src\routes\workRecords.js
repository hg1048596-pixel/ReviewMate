const express = require('express');
const { getDb } = require('../db/init');

const router = express.Router();

// GET /api/work-records - 查询工作记录
router.get('/', (req, res) => {
  let db;
  try {
    db = getDb();
    const { start, end, project, status, search, limit, offset } = req.query;
    let sql = 'SELECT * FROM work_records WHERE 1=1';
    const params = [];

    if (start) { sql += ' AND date >= ?'; params.push(start); }
    if (end) { sql += ' AND date <= ?'; params.push(end); }
    if (project) { sql += ' AND project = ?'; params.push(project); }
    if (status) { sql += ' AND status = ?'; params.push(status); }
    if (search) { sql += ' AND (task LIKE ? OR notes LIKE ?)'; params.push(`%${search}%`, `%${search}%`); }

    sql += ' ORDER BY date DESC, id DESC';

    if (limit) {
      sql += ' LIMIT ?';
      params.push(parseInt(limit));
      if (offset) { sql += ' OFFSET ?'; params.push(parseInt(offset)); }
    }

    const records = db.prepare(sql).all(...params);
    const total = db.prepare('SELECT COUNT(*) as count FROM work_records WHERE 1=1' +
      (start ? ' AND date >= ?' : '') + (end ? ' AND date <= ?' : '')).get(
      ...[start, end].filter(Boolean)
    );

    // 解析 tags JSON
    const parsed = records.map(r => ({
      ...r,
      tags: JSON.parse(r.tags || '[]')
    }));

    res.json({ data: parsed, total: total?.count || parsed.length });
  } catch (e) {
    res.status(500).json({ error: e.message });
  } finally {
    if (db) db.close();
  }
});

// POST /api/work-records - 新增工作记录
router.post('/', (req, res) => {
  let db;
  try {
    db = getDb();
    const { date, project, task, duration_hours, tags, status, notes, source_file } = req.body;
    if (!date || !task) {
      return res.status(400).json({ error: 'date 和 task 为必填项' });
    }
    const result = db.prepare(
      'INSERT INTO work_records (date, project, task, duration_hours, tags, status, notes, source_file) VALUES (?,?,?,?,?,?,?,?)'
    ).run(
      date, project || '', task, duration_hours || 0,
      JSON.stringify(tags || []), status || 'completed', notes || '', source_file || ''
    );
    const record = db.prepare('SELECT * FROM work_records WHERE id = ?').get(result.lastInsertRowid);
    record.tags = JSON.parse(record.tags || '[]');
    res.status(201).json(record);
  } catch (e) {
    res.status(500).json({ error: e.message });
  } finally {
    if (db) db.close();
  }
});

// POST /api/work-records/import - 批量导入
router.post('/import', async (req, res) => {
  const collector = require('../services/collector');
  let db;
  try {
    db = getDb();
    const { dirPath, startDate, endDate } = req.body;
    if (!dirPath) return res.status(400).json({ error: 'dirPath 为必填项' });

    const files = collector.scanDirectory(dirPath, startDate, endDate);
    const entries = await collector.parseFiles(files);

    const insert = db.prepare(
      'INSERT INTO work_records (date, project, task, duration_hours, tags, status, source_file) VALUES (?,?,?,?,?,?,?)'
    );
    const insertMany = db.transaction((items) => {
      for (const e of items) {
        insert.run(e.date, e.project, e.task, e.duration_hours, e.tags, e.status, e.source_file);
      }
    });
    insertMany(entries);

    res.json({ imported: entries.length, files: files.length });
  } catch (e) {
    res.status(500).json({ error: e.message });
  } finally {
    if (db) db.close();
  }
});

// PUT /api/work-records/:id - 更新
router.put('/:id', (req, res) => {
  let db;
  try {
    db = getDb();
    const { date, project, task, duration_hours, tags, status, notes } = req.body;
    const existing = db.prepare('SELECT * FROM work_records WHERE id = ?').get(req.params.id);
    if (!existing) return res.status(404).json({ error: '记录不存在' });

    db.prepare(
      `UPDATE work_records SET date=?, project=?, task=?, duration_hours=?, tags=?, status=?, notes=?,
       updated_at=datetime('now','localtime') WHERE id=?`
    ).run(
      date || existing.date, project ?? existing.project, task || existing.task,
      duration_hours ?? existing.duration_hours, tags ? JSON.stringify(tags) : existing.tags,
      status || existing.status, notes ?? existing.notes, req.params.id
    );

    const record = db.prepare('SELECT * FROM work_records WHERE id = ?').get(req.params.id);
    record.tags = JSON.parse(record.tags || '[]');
    res.json(record);
  } catch (e) {
    res.status(500).json({ error: e.message });
  } finally {
    if (db) db.close();
  }
});

// DELETE /api/work-records/:id
router.delete('/:id', (req, res) => {
  let db;
  try {
    db = getDb();
    const result = db.prepare('DELETE FROM work_records WHERE id = ?').run(req.params.id);
    if (result.changes === 0) return res.status(404).json({ error: '记录不存在' });
    res.json({ deleted: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  } finally {
    if (db) db.close();
  }
});

module.exports = router;
