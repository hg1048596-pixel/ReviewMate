const express = require('express');
const { getDb } = require('../db/init');

const router = express.Router();

const FEISHU_BASE = 'https://open.feishu.cn/open-apis';

// 从数据库获取飞书配置
function getFeishuConfig() {
  let db;
  try {
    db = getDb();
    const rows = db.prepare("SELECT key, value FROM settings WHERE key IN ('feishu_app_id','feishu_app_secret')").all();
    const config = {};
    for (const r of rows) {
      try { config[r.key] = JSON.parse(r.value); } catch (e) { config[r.key] = r.value; }
    }
    return config;
  } finally {
    if (db) db.close();
  }
}

// 获取 tenant_access_token
async function getAccessToken(appId, appSecret) {
  const res = await fetch(`${FEISHU_BASE}/auth/v3/tenant_access_token/internal`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ app_id: appId, app_secret: appSecret }),
  });
  const data = await res.json();
  if (data.code !== 0) throw new Error(`飞书认证失败: ${data.msg}`);
  return data.tenant_access_token;
}

// GET /api/feishu/status - 检查飞书配置状态
router.get('/status', (req, res) => {
  try {
    const config = getFeishuConfig();
    const configured = !!(config.feishu_app_id && config.feishu_app_secret);
    res.json({ configured });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// GET /api/feishu/calendar-events - 获取日历事件
router.get('/calendar-events', async (req, res) => {
  try {
    const config = getFeishuConfig();
    if (!config.feishu_app_id || !config.feishu_app_secret) {
      return res.status(400).json({ error: '请先在设置中配置飞书 App ID 和 App Secret' });
    }

    const { start, end } = req.query;
    const startDate = start || new Date().toISOString().split('T')[0];
    const endDate = end || startDate;

    const token = await getAccessToken(config.feishu_app_id, config.feishu_app_secret);

    // 先获取用户的主日历列表
    const calListRes = await fetch(`${FEISHU_BASE}/calendar/v4/calendars?page_size=50`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    const calList = await calListRes.json();
    if (calList.code !== 0) {
      return res.status(500).json({ error: `获取日历列表失败: ${calList.msg}` });
    }

    const calendars = calList.data?.calendar_list || [];
    if (calendars.length === 0) {
      return res.json({ events: [], calendars: [] });
    }

    // 获取每个日历的事件
    const allEvents = [];
    for (const cal of calendars.slice(0, 3)) {
      try {
        const evtRes = await fetch(
          `${FEISHU_BASE}/calendar/v4/calendars/${cal.calendar_id}/events?` +
          `start_time=${startDate}T00:00:00+08:00&end_time=${endDate}T23:59:59+08:00&page_size=50`,
          { headers: { Authorization: `Bearer ${token}` } }
        );
        const evtData = await evtRes.json();
        if (evtData.code === 0 && evtData.data?.items) {
          for (const item of evtData.data.items) {
            const startTime = item.start_time?.date_time || item.start_time?.date || '';
            const endTime = item.end_time?.date_time || item.end_time?.date || '';
            let durationHours = 0;
            if (item.start_time?.date_time && item.end_time?.date_time) {
              durationHours = (new Date(endTime) - new Date(startTime)) / (1000 * 3600);
            }
            allEvents.push({
              id: item.event_id,
              summary: item.summary || '无标题',
              description: item.description || '',
              startTime,
              endTime,
              durationHours: Math.round(durationHours * 100) / 100,
              calendar: cal.summary || cal.calendar_id,
              source: 'calendar',
            });
          }
        }
      } catch (e) {
        // 跳过获取失败的日历
      }
    }

    allEvents.sort((a, b) => a.startTime.localeCompare(b.startTime));

    res.json({ events: allEvents, calendars: calendars.map(c => ({ id: c.calendar_id, name: c.summary })) });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// GET /api/feishu/tasks - 获取任务列表
router.get('/tasks', async (req, res) => {
  try {
    const config = getFeishuConfig();
    if (!config.feishu_app_id || !config.feishu_app_secret) {
      return res.status(400).json({ error: '请先在设置中配置飞书 App ID 和 App Secret' });
    }

    const token = await getAccessToken(config.feishu_app_id, config.feishu_app_secret);

    const taskRes = await fetch(
      `${FEISHU_BASE}/task/v1/tasks?page_size=50`,
      { headers: { Authorization: `Bearer ${token}` } }
    );
    const taskData = await taskRes.json();
    if (taskData.code !== 0) {
      return res.status(500).json({ error: `获取任务列表失败: ${taskData.msg}` });
    }

    const tasks = (taskData.data?.items || []).map(t => {
      const dueDate = t.due?.date || '';
      const completed = t.is_completed || t.status === 'completed';
      return {
        id: t.id,
        summary: t.summary || '无标题',
        description: t.description || '',
        dueDate,
        completed,
        createdAt: t.created_at || '',
        source: 'task',
      };
    });

    res.json({ tasks });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// POST /api/feishu/import - 将选中的飞书数据导入为工作记录
router.post('/import', (req, res) => {
  let db;
  try {
    db = getDb();
    const { items } = req.body; // [{ summary, date, durationHours, tags, status, source, sourceId }]
    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ error: 'items 为必填数组' });
    }

    const insert = db.prepare(
      `INSERT INTO work_records (date, project, task, duration_hours, tags, status, source_file, notes)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    );

    const insertMany = db.transaction((items) => {
      let count = 0;
      for (const item of items) {
        const date = item.date || new Date().toISOString().split('T')[0];
        const project = item.project || '飞书导入';
        const task = item.summary || '未命名任务';
        const hours = parseFloat(item.durationHours) || 0;
        const tags = JSON.stringify(item.tags || ['飞书']);
        const status = item.status || 'completed';
        const sourceFile = `feishu:${item.source || 'unknown'}:${item.sourceId || ''}`;
        const notes = item.notes || '';
        insert.run(date, project, task, hours, tags, status, sourceFile, notes);
        count++;
      }
      return count;
    });

    const count = insertMany(items);
    res.json({ success: true, imported: count });
  } catch (e) {
    res.status(500).json({ error: e.message });
  } finally {
    if (db) db.close();
  }
});

module.exports = router;
