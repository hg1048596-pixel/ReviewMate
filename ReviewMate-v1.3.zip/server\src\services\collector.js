const fs = require('fs');
const path = require('path');
const mammoth = require('mammoth');
const XLSX = require('xlsx');
const AdmZip = require('adm-zip');
const pdfParse = require('pdf-parse');

const BINARY_EXTS = ['.docx', '.pptx', '.xlsx', '.pdf'];
const ALL_EXTS = ['.md', '.txt', '.json', '.csv', ...BINARY_EXTS];

/**
 * 从纯文本尝试提取结构化工作记录
 */
function extractEntriesFromText(text, sourceFileName) {
  const entries = [];
  const lines = text.split('\n');
  let currentDate = new Date().toISOString().split('T')[0];
  let currentProject = '';

  for (const line of lines) {
    const dMatch = line.match(/#\s*(\d{4}-\d{2}-\d{2})/);
    if (dMatch) { currentDate = dMatch[1]; continue; }

    const pMatch = line.match(/^##\s+(.+)/);
    if (pMatch && !['今日完成', '今日任务', '本周完成', '遇到的问题', '明日计划', '下周计划', '已完成', '本周任务', '项目', '总结', '摘要'].includes(pMatch[1])) {
      currentProject = pMatch[1]; continue;
    }

    const taskMatch = line.match(/[-*]\s+\[([xX\s])\]\s+(.+)/);
    if (taskMatch) {
      const status = taskMatch[1].toLowerCase() === 'x' ? 'completed' : 'planned';
      const taskText = taskMatch[2];
      const timeMatch = taskText.match(/\[(\d+\.?\d*)\s*(h|小时)\]/);
      const duration = timeMatch ? parseFloat(timeMatch[1]) : 0;
      const tags = [];
      const tagRegex = /#(\S+)/g;
      let m;
      while ((m = tagRegex.exec(taskText)) !== null) tags.push(m[1]);
      let taskName = taskText.replace(/\[(\d+\.?\d*)\s*(h|小时)\]/, '').replace(/#\S+/g, '').trim();
      entries.push({ date: currentDate, project: currentProject, task: taskName, duration_hours: duration, tags: JSON.stringify(tags), status, source_file: sourceFileName });
    }
  }
  return entries;
}

class CollectorAgent {
  scanDirectory(dirPath, startDate, endDate) {
    const results = [];
    if (!fs.existsSync(dirPath)) return results;

    const start = new Date(startDate);
    const end = new Date(endDate);
    end.setHours(23, 59, 59, 999);

    const files = this._walkDir(dirPath);
    for (const file of files) {
      try {
        const stat = fs.statSync(file);
        const mtime = new Date(stat.mtime);
        if (mtime >= start && mtime <= end) {
          const ext = path.extname(file).toLowerCase();
          if (ALL_EXTS.includes(ext)) {
            const isBinary = BINARY_EXTS.includes(ext);
            const content = isBinary ? null : fs.readFileSync(file, 'utf-8');
            results.push({ filePath: file, fileName: path.basename(file), modifiedAt: mtime.toISOString(), ext, content });
          }
        }
      } catch (e) { /* skip */ }
    }
    return results;
  }

  /**
   * 提取文件的原始文本内容（不解析为工作记录）
   * 用于 AI 上下文学习
   */
  async extractText(file) {
    const ext = file.ext || path.extname(file.fileName || '').toLowerCase();
    const buf = this._readBinaryContent(file);

    switch (ext) {
      case '.md':
      case '.txt':
      case '.json':
      case '.csv':
        return file.content || (buf ? buf.toString('utf-8') : '');

      case '.docx': {
        if (!buf) return '';
        try { return (await mammoth.extractRawText({ buffer: buf })).value; } catch { return ''; }
      }

      case '.pptx': {
        if (!buf) return '';
        try {
          const zip = new AdmZip(buf);
          let allText = '';
          for (const entry of zip.getEntries()) {
            if (entry.entryName.match(/ppt\/slides\/slide\d+\.xml/)) {
              const xml = entry.getData().toString('utf-8');
              const textMatches = xml.match(/<a:t[^>]*>([^<]*)<\/a:t>/g);
              if (textMatches) {
                for (const tm of textMatches) {
                  const txt = tm.replace(/<[^>]+>/g, '').trim();
                  if (txt) allText += txt + '\n';
                }
              }
            }
          }
          return allText;
        } catch { return ''; }
      }

      case '.xlsx': {
        if (!buf) return '';
        try {
          const workbook = XLSX.read(buf, { type: 'buffer' });
          let allText = '';
          for (const sheetName of workbook.SheetNames) {
            const sheet = workbook.Sheets[sheetName];
            allText += `## ${sheetName}\n${XLSX.utils.sheet_to_csv(sheet)}\n\n`;
          }
          return allText;
        } catch { return ''; }
      }

      case '.pdf': {
        if (!buf) return '';
        try { return (await pdfParse(buf)).text; } catch { return ''; }
      }

      default:
        return '';
    }
  }

  async parseFiles(files) {
    const entries = [];
    for (const file of files) {
      switch (file.ext) {
        case '.md':
        case '.txt': entries.push(...this._parseMarkdown(file)); break;
        case '.json': entries.push(...this._parseJson(file)); break;
        case '.csv': entries.push(...this._parseCsv(file)); break;
        case '.docx': entries.push(...(await this._parseDocx(file))); break;
        case '.pptx': entries.push(...this._parsePptx(file)); break;
        case '.xlsx': entries.push(...this._parseXlsx(file)); break;
        case '.pdf': entries.push(...(await this._parsePdfAsync(file))); break;
      }
    }
    return entries;
  }

  _walkDir(dir) {
    const results = [];
    try {
      for (const item of fs.readdirSync(dir)) {
        const fullPath = path.join(dir, item);
        const stat = fs.statSync(fullPath);
        if (stat.isDirectory()) results.push(...this._walkDir(fullPath));
        else results.push(fullPath);
      }
    } catch (e) { /* skip */ }
    return results;
  }

  _parseMarkdown(file) {
    return extractEntriesFromText(file.content, file.fileName);
  }

  _parseJson(file) {
    const entries = [];
    try {
      const data = JSON.parse(file.content);
      const records = Array.isArray(data) ? data : (data.entries || [data]);
      for (const r of records) {
        entries.push({
          date: r.date || file.modifiedAt.split('T')[0], project: r.project || '',
          task: r.task || r.title || '', duration_hours: r.duration_hours || r.hours || 0,
          tags: JSON.stringify(r.tags || []), status: r.status || 'completed', source_file: file.fileName,
        });
      }
    } catch (e) { /* parse error */ }
    return entries;
  }

  _parseCsv(file) {
    const entries = [];
    const lines = file.content.split('\n').filter(l => l.trim());
    if (lines.length < 2) return entries;
    const headers = lines[0].split(',').map(h => h.trim().toLowerCase());
    for (let i = 1; i < lines.length; i++) {
      const cols = lines[i].split(',').map(c => c.trim());
      const obj = {};
      headers.forEach((h, idx) => { obj[h] = cols[idx] || ''; });
      entries.push({
        date: obj.date || file.modifiedAt.split('T')[0], project: obj.project || '',
        task: obj.task || '', duration_hours: parseFloat(obj.hours || obj.duration || 0),
        tags: obj.tags ? JSON.stringify(obj.tags.split(';')) : '[]',
        status: obj.status || 'completed', source_file: file.fileName,
      });
    }
    return entries;
  }

  // ===== 二进制格式解析 =====

  _readBinaryContent(file) {
    // 支持 Buffer 或文件路径
    if (Buffer.isBuffer(file.content)) return file.content;
    if (file.filePath && fs.existsSync(file.filePath)) return fs.readFileSync(file.filePath);
    return null;
  }

  async _parseDocx(file) {
    const buf = this._readBinaryContent(file);
    if (!buf) return [];
    try {
      const result = await mammoth.extractRawText({ buffer: buf });
      const text = result.value;
      const entries = extractEntriesFromText(text, file.fileName);
      // 如果没有提取到结构化条目，创建一个概览条目
      if (entries.length === 0 && text.trim()) {
        const preview = text.substring(0, 2000);
        entries.push({
          date: file.modifiedAt.split('T')[0], project: 'Word文档',
          task: `[文件导入] ${file.fileName}`,
          duration_hours: 0, tags: JSON.stringify(['Word', 'docx']),
          status: 'completed', source_file: file.fileName,
          notes: `文档内容摘要:\n${preview}${text.length > 2000 ? '\n...(内容已截断)' : ''}`,
        });
      }
      return entries;
    } catch (e) { return []; }
  }

  _parsePptx(file) {
    const buf = this._readBinaryContent(file);
    if (!buf) return [];
    try {
      const zip = new AdmZip(buf);
      const entries = [];
      let allText = '';
      // 遍历 slide XML 提取文本
      for (const entry of zip.getEntries()) {
        if (entry.entryName.match(/ppt\/slides\/slide\d+\.xml/)) {
          const xml = entry.getData().toString('utf-8');
          const textMatches = xml.match(/<a:t[^>]*>([^<]*)<\/a:t>/g);
          if (textMatches) {
            for (const tm of textMatches) {
              const txt = tm.replace(/<[^>]+>/g, '').trim();
              if (txt) allText += txt + '\n';
            }
          }
        }
      }
      const structured = extractEntriesFromText(allText, file.fileName);
      if (structured.length > 0) {
        entries.push(...structured);
      } else if (allText.trim()) {
        const preview = allText.substring(0, 2000);
        entries.push({
          date: file.modifiedAt.split('T')[0], project: 'PPT演示文稿',
          task: `[文件导入] ${file.fileName}`,
          duration_hours: 0, tags: JSON.stringify(['PPT', 'pptx']),
          status: 'completed', source_file: file.fileName,
          notes: `PPT内容摘要:\n${preview}${allText.length > 2000 ? '\n...(内容已截断)' : ''}`,
        });
      }
      return entries;
    } catch (e) { return []; }
  }

  _parseXlsx(file) {
    const buf = this._readBinaryContent(file);
    if (!buf) return [];
    try {
      const workbook = XLSX.read(buf, { type: 'buffer' });
      const entries = [];
      let allText = '';

      for (const sheetName of workbook.SheetNames) {
        const sheet = workbook.Sheets[sheetName];
        const csvText = XLSX.utils.sheet_to_csv(sheet);
        allText += `## ${sheetName}\n${csvText}\n\n`;
      }

      // 先尝试用 Markdown 解析器（CSV 格式可能匹配）
      const structured = extractEntriesFromText(allText, file.fileName);
      if (structured.length > 0) {
        entries.push(...structured);
      } else if (allText.trim()) {
        const preview = allText.substring(0, 2000);
        entries.push({
          date: file.modifiedAt.split('T')[0], project: 'Excel表格',
          task: `[文件导入] ${file.fileName}`,
          duration_hours: 0, tags: JSON.stringify(['Excel', 'xlsx']),
          status: 'completed', source_file: file.fileName,
          notes: `Excel内容摘要:\n${preview}${allText.length > 2000 ? '\n...(内容已截断)' : ''}`,
        });
      }
      return entries;
    } catch (e) { return []; }
  }

  async _parsePdfAsync(file) {
    const buf = this._readBinaryContent(file);
    if (!buf) return [];
    try {
      const data = await pdfParse(buf);
      const text = data.text;
      const entries = extractEntriesFromText(text, file.fileName);
      if (entries.length === 0 && text.trim()) {
        const preview = text.substring(0, 2000);
        entries.push({
          date: file.modifiedAt ? file.modifiedAt.split('T')[0] : new Date().toISOString().split('T')[0],
          project: 'PDF文档',
          task: `[文件导入] ${file.fileName}`,
          duration_hours: 0, tags: JSON.stringify(['PDF', 'pdf']),
          status: 'completed', source_file: file.fileName,
          notes: `PDF内容摘要:\n${preview}${text.length > 2000 ? '\n...(内容已截断)' : ''}`,
        });
      }
      return entries;
    } catch (e) { return []; }
  }

}

module.exports = new CollectorAgent();
