const express = require('express');
const { getDb } = require('../db/init');

const router = express.Router();

// GET /api/metrics - 查询绩效指标历史
router.get('/', (req, res) => {
  let db;
  try {
    db = getDb();
    const { type, limit } = req.query;
    let sql = 'SELECT * FROM performance_metrics WHERE 1=1';
    const params = [];
    if (type) { sql += ' AND period_type = ?'; params.push(type); }
    sql += ' ORDER BY period_start DESC';
    if (limit) { sql += ' LIMIT ?'; params.push(parseInt(limit)); }

    const metrics = db.prepare(sql).all(...params);
    res.json(metrics.map(m => ({
      ...m,
      tag_distribution: JSON.parse(m.tag_distribution || '{}'),
      highlights: JSON.parse(m.highlights || '[]'),
      lowlights: JSON.parse(m.lowlights || '[]')
    })));
  } catch (e) {
    res.status(500).json({ error: e.message });
  } finally {
    if (db) db.close();
  }
});

// POST /api/metrics - 手动录入绩效指标
router.post('/', (req, res) => {
  let db;
  try {
    db = getDb();
    const { period_type, period_start, period_end, total_tasks, completed_tasks,
      total_hours, planned_hours, completion_rate, estimation_accuracy, output_density,
      goal_achievement_rate, tag_distribution, highlights, lowlights } = req.body;

    const result = db.prepare(`
      INSERT INTO performance_metrics (period_type, period_start, period_end, total_tasks, completed_tasks,
        total_hours, planned_hours, completion_rate, estimation_accuracy, output_density,
        goal_achievement_rate, tag_distribution, highlights, lowlights)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    `).run(
      period_type, period_start, period_end, total_tasks || 0, completed_tasks || 0,
      total_hours || 0, planned_hours || 0, completion_rate || 0, estimation_accuracy || 0,
      output_density || 0, goal_achievement_rate || 0,
      JSON.stringify(tag_distribution || {}),
      JSON.stringify(highlights || []),
      JSON.stringify(lowlights || [])
    );

    const metric = db.prepare('SELECT * FROM performance_metrics WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json(metric);
  } catch (e) {
    res.status(500).json({ error: e.message });
  } finally {
    if (db) db.close();
  }
});

// GET /api/metrics/dashboard - 看板数据汇总
router.get('/dashboard', (req, res) => {
  let db;
  try {
    db = getDb();
    // 本周指标
    const now = new Date();
    const weekEnd = new Date(now);
    const weekStart = new Date(now);
    weekStart.setDate(weekStart.getDate() - weekStart.getDay() + 1); // 周一

    const thisWeekRecords = db.prepare(
      'SELECT * FROM work_records WHERE date >= ? AND date <= ?'
    ).all(weekStart.toISOString().split('T')[0], weekEnd.toISOString().split('T')[0]);

    // 最近4周绩效指标趋势
    const trends = db.prepare(
      'SELECT * FROM performance_metrics WHERE period_type = ? ORDER BY period_start DESC LIMIT 4'
    ).all('weekly');

    // 目标进展
    const goals = db.prepare('SELECT * FROM goals WHERE status = ?').all('active');

    // 标签分布
    const tagStats = db.prepare(`
      SELECT tags FROM work_records WHERE date >= ? AND date <= ?
    `).all(weekStart.toISOString().split('T')[0], weekEnd.toISOString().split('T')[0]);

    const tagDist = {};
    for (const r of tagStats) {
      try {
        const tags = JSON.parse(r.tags || '[]');
        for (const t of tags) { tagDist[t] = (tagDist[t] || 0) + 1; }
      } catch (e) {}
    }

    // 项目分布
    const projects = db.prepare(
      'SELECT project, COUNT(*) as count, SUM(duration_hours) as hours FROM work_records WHERE date >= ? AND date <= ? GROUP BY project'
    ).all(weekStart.toISOString().split('T')[0], weekEnd.toISOString().split('T')[0]);

    res.json({
      thisWeek: {
        total: thisWeekRecords.length,
        completed: thisWeekRecords.filter(r => r.status === 'completed').length,
        hours: thisWeekRecords.reduce((s, r) => s + r.duration_hours, 0)
      },
      trends: trends.map(m => ({
        ...m,
        tag_distribution: JSON.parse(m.tag_distribution || '{}')
      })),
      goals: goals.map(g => ({
        ...g,
        progress: g.target_value > 0 ? Math.round(g.actual_value / g.target_value * 100) : 0
      })),
      tagDistribution: tagDist,
      projects
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  } finally {
    if (db) db.close();
  }
});

module.exports = router;
