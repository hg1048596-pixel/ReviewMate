import { useState, useRef, useEffect, useCallback } from 'react'
import React from 'react'
import { api } from '../api'
import { X, Send, Loader2, Bot, User, Trash2, RefreshCw, FileDown, FileText, Upload } from 'lucide-react'

const DEFAULT_GREETING = { role: 'assistant', content: '你好！我是 ReviewMate AI 助手。\n\n我可以访问你的工作记录、绩效数据和目标信息，帮你分析工作规律、解答疑问。\n\n你还可以点击右上方的 📎 按钮导入工作文件，我会自动解析并加入分析上下文。\n\n请问有什么可以帮你的？' }
const STORAGE_KEY = 'reviewmate_chat_messages'

export default function ChatPanel({ onClose }) {
  const [messages, setMessages] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY)
      if (saved) {
        const parsed = JSON.parse(saved)
        if (Array.isArray(parsed) && parsed.length > 0) return parsed
      }
    } catch (e) { /* ignore corrupt data */ }
    return [DEFAULT_GREETING]
  })
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [streamingContent, setStreamingContent] = useState('')
  const [streamingReasoning, setStreamingReasoning] = useState('')
  const [showImport, setShowImport] = useState(false)
  const [importPath, setImportPath] = useState('')
  const [importing, setImporting] = useState(false)
  const [importResult, setImportResult] = useState(null)
  const [generatingDoc, setGeneratingDoc] = useState(null) // 'ppt' | 'docx' | null
  const [dragOver, setDragOver] = useState(false)
  const [fileContext, setFileContext] = useState(null) // 导入文件的文本上下文，发给 AI
  const dragCounterRef = useRef(0)
  const messagesEndRef = useRef(null)
  const inputRef = useRef(null)
  const abortRef = useRef(null)

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, streamingContent, streamingReasoning])

  // 持久化对话记录到 localStorage（服务关闭前始终保留）
  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(messages)) } catch (e) { /* ignore */ }
  }, [messages])

  useEffect(() => {
    inputRef.current?.focus()
  }, [])

  const handleSend = useCallback(async () => {
    const text = input.trim()
    if (!text || loading) return

    const userMsg = { role: 'user', content: text }
    const newMessages = [...messages, userMsg]
    setMessages(newMessages)
    setInput('')
    setLoading(true)
    setStreamingContent('')
    setStreamingReasoning('')

    try {
      const { abort } = api.aiChat(newMessages, {
        fileContext,
        onChunk: (data) => {
          if (data.error) {
            setStreamingContent(`错误: ${data.error}`)
            setStreamingReasoning('')
            setLoading(false)
            return
          }
          if (data.done) {
            setMessages(prev => [...prev, { role: 'assistant', content: data.content }])
            setStreamingContent('')
            setStreamingReasoning('')
            setLoading(false)
          } else {
            setStreamingContent(data.fullContent)
            setStreamingReasoning(data.reasoningContent || '')
          }
        },
      })
      abortRef.current = abort
    } catch (e) {
      setMessages(prev => [...prev, { role: 'assistant', content: `请求失败: ${e.message}` }])
      setStreamingContent('')
      setStreamingReasoning('')
      setLoading(false)
    }
  }, [input, loading, messages, fileContext])

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  const handleImport = async () => {
    if (!importPath.trim()) return
    setImporting(true)
    setImportResult(null)
    try {
      const result = await api.aiImportFile(importPath.trim())
      setImportResult(result)
      // 保存文件上下文，后续对话发给 AI
      setFileContext({ fileName: result.fileName, textContent: result.textContent })
      const summary = `已导入文件 **${result.fileName}**（${(result.fileSize / 1024).toFixed(1)} KB，提取 ${result.textLength} 字符${result.truncated ? '，已截断' : ''}），内容已提供给 AI 助手。你可以直接提问关于此文件的问题。`
      setMessages(prev => [...prev, { role: 'system', content: summary }])
    } catch (e) {
      setImportResult({ error: e.message })
    } finally {
      setImporting(false)
    }
  }

  const handleClear = () => {
    setMessages([DEFAULT_GREETING])
    setStreamingContent('')
    setFileContext(null)
  }

  // 拖拽文件导入
  const handleDragEnter = useCallback((e) => {
    e.preventDefault()
    e.stopPropagation()
    dragCounterRef.current++
    if (e.dataTransfer.items && e.dataTransfer.items.length > 0) {
      setDragOver(true)
    }
  }, [])

  const handleDragLeave = useCallback((e) => {
    e.preventDefault()
    e.stopPropagation()
    dragCounterRef.current--
    if (dragCounterRef.current === 0) {
      setDragOver(false)
    }
  }, [])

  const handleDragOver = useCallback((e) => {
    e.preventDefault()
    e.stopPropagation()
  }, [])

  const handleDrop = useCallback((e) => {
    e.preventDefault()
    e.stopPropagation()
    setDragOver(false)
    dragCounterRef.current = 0

    const files = e.dataTransfer.files
    if (!files || files.length === 0) return

    const file = files[0]
    const fileName = file.name
    // Electron/桌面环境下可拿到完整路径
    const filePath = file.path || ''

    if (filePath) {
      // 有完整路径，直接导入
      setImportPath(filePath)
      setShowImport(true)
      setImportResult(null)
      doImport(filePath)
    } else {
      // 浏览器环境：用 FileReader 读取内容后上传
      setShowImport(true)
      setImportPath(fileName)
      setImportResult(null)
      setImporting(true)

      const reader = new FileReader()
      reader.onload = () => {
        const base64Content = reader.result.split(',')[1]
        api.aiImportFileContent(fileName, base64Content)
          .then(result => {
            setImportResult(result)
            setFileContext({ fileName: result.fileName, textContent: result.textContent })
            const summary = `已导入文件 **${result.fileName}**（${(result.fileSize / 1024).toFixed(1)} KB，提取 ${result.textLength} 字符${result.truncated ? '，已截断' : ''}），内容已提供给 AI 助手。你可以直接提问关于此文件的问题。`
            setMessages(prev => [...prev, { role: 'system', content: summary }])
          })
          .catch(e => setImportResult({ error: e.message }))
          .finally(() => setImporting(false))
      }
      reader.onerror = () => {
        setImporting(false)
        setImportResult({ error: '文件读取失败，请尝试手动输入路径' })
      }
      reader.readAsDataURL(file)
    }
  }, [])

  // 提取导入逻辑复用
  const doImport = (filePath) => {
    setImporting(true)
    api.aiImportFile(filePath)
      .then(result => {
        setImportResult(result)
        setFileContext({ fileName: result.fileName, textContent: result.textContent })
        const summary = `已导入文件 **${result.fileName}**（${(result.fileSize / 1024).toFixed(1)} KB，提取 ${result.textLength} 字符${result.truncated ? '，已截断' : ''}），内容已提供给 AI 助手。你可以直接提问关于此文件的问题。`
        setMessages(prev => [...prev, { role: 'system', content: summary }])
      })
      .catch(e => setImportResult({ error: e.message }))
      .finally(() => setImporting(false))
  }

  // 收集对话上下文作为文档生成的数据
  const collectContext = () => {
    return messages
      .filter(m => m.role !== 'system')
      .map(m => `${m.role === 'user' ? '用户' : 'AI'}: ${m.content}`)
      .join('\n\n')
  }

  // 通用文件下载函数（fetch → blob → blob URL → 触发下载）
  const triggerDownload = async (fileName) => {
    try {
      const url = api.aiDownloadFile(fileName)
      const response = await fetch(url)
      if (!response.ok) throw new Error(`HTTP ${response.status}`)
      const blob = await response.blob()
      const blobUrl = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = blobUrl
      a.download = fileName
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(blobUrl)
    } catch (e) {
      console.error('下载文件失败:', e)
      // 降级：直接打开 URL
      window.open(api.aiDownloadFile(fileName), '_blank')
    }
  }

  // 判断消息是否包含可导出的内容
  const EXPORT_KEYWORDS = ['PPT', 'ppt', '演示文稿', '幻灯片', 'Word', 'word', '文档', '报告', '导出', '生成']
  const isExportable = (msg) => {
    if (!msg || msg.role === 'user' || msg.role === 'system') return false
    return EXPORT_KEYWORDS.some(kw => msg.content.includes(kw))
  }

  const handleGeneratePPT = async () => {
    setGeneratingDoc('ppt')
    try {
      const dataContext = collectContext()
      const lastUserMsg = [...messages].reverse().find(m => m.role === 'user')
      const prompt = lastUserMsg?.content || '生成工作汇报PPT'

      const result = await api.aiGeneratePPT({ prompt, dataContext, fileContext })
      if (result.success) {
        triggerDownload(result.fileName)
        const mode = result.templateMode
          ? `参照模板 ${fileContext?.fileName || ''} 生成`
          : result.fallback
            ? '使用内置模板生成'
            : 'AI 全权设计生成'
        setMessages(prev => [...prev, {
          role: 'system',
          content: `PPT 已生成并开始下载: ${result.fileName} (${mode})`
        }])
      }
    } catch (e) {
      setMessages(prev => [...prev, {
        role: 'system',
        content: `PPT 生成失败: ${e.message}`
      }])
    } finally {
      setGeneratingDoc(null)
    }
  }

  const handleGenerateDOCX = async () => {
    setGeneratingDoc('docx')
    try {
      const dataContext = collectContext()
      const lastUserMsg = [...messages].reverse().find(m => m.role === 'user')
      const prompt = lastUserMsg?.content || '生成工作文档'

      const result = await api.aiGenerateDOCX({ prompt, dataContext })
      if (result.success) {
        triggerDownload(result.fileName)
        setMessages(prev => [...prev, {
          role: 'system',
          content: `Word 文档已生成并开始下载: ${result.fileName}${result.fallback ? ' (使用模板生成)' : ' (AI 生成)'}`
        }])
      }
    } catch (e) {
      setMessages(prev => [...prev, {
        role: 'system',
        content: `Word 文档生成失败: ${e.message}`
      }])
    } finally {
      setGeneratingDoc(null)
    }
  }

  return (
    <div
      className="w-96 bg-white border-l border-slate-200 flex flex-col h-screen shadow-lg z-10 relative"
      onDragEnter={handleDragEnter}
      onDragLeave={handleDragLeave}
      onDragOver={handleDragOver}
      onDrop={handleDrop}
    >
      {/* 拖拽提示覆盖层 */}
      {dragOver && (
        <div className="absolute inset-0 z-20 flex flex-col items-center justify-center gap-3 bg-teal-500/90 backdrop-blur-sm rounded-none">
          <div className="w-16 h-16 rounded-2xl bg-white/20 flex items-center justify-center animate-bounce">
            <Upload size={30} className="text-white" />
          </div>
          <span className="text-white font-semibold text-base">释放文件以导入</span>
          <span className="text-white/70 text-sm">支持 .md / .txt / .json / .csv / .docx / .pptx / .xlsx / .pdf</span>
          <div className="absolute inset-0 border-2 border-dashed border-white/30 m-3 rounded-xl pointer-events-none" />
        </div>
      )}
      {/* 顶部栏 */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-slate-100">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-teal-500 flex items-center justify-center">
            <Bot size={14} className="text-white" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-slate-700">AI 助手</h3>
            <p className="text-xs text-slate-400">ReviewMate</p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={() => { setImportPath(''); setImportResult(null); setShowImport(!showImport) }}
            className={`p-1.5 rounded-md transition-colors ${showImport ? 'bg-teal-50 text-teal-500' : 'text-slate-400 hover:bg-slate-50 hover:text-teal-500'}`}
            title="导入文件"
          >
            <span className="text-base">📎</span>
          </button>
          <button
            onClick={handleClear}
            className="p-1.5 rounded-md text-slate-400 hover:bg-slate-50 hover:text-slate-600"
            title="清空对话"
          >
            <Trash2 size={14} />
          </button>
          <button
            onClick={onClose}
            className="p-1.5 rounded-md text-slate-400 hover:bg-slate-50 hover:text-slate-600"
            title="关闭"
          >
            <X size={16} />
          </button>
        </div>
      </div>

      {/* 文件导入区 */}
      {showImport && (
        <div className="px-4 py-3 border-b border-slate-100 bg-slate-50">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-xs">📎</span>
            <span className="text-xs font-medium text-slate-600">导入工作文件到 AI 分析上下文</span>
            <span className="text-xs text-slate-400 ml-auto">可拖拽文件至此</span>
          </div>
          <div className="flex gap-2">
            <input
              type="text"
              value={importPath}
              onChange={e => setImportPath(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleImport()}
              placeholder="粘贴文件路径，如 C:\work\log.md"
              className="flex-1 border border-slate-300 rounded-md px-3 py-1.5 text-xs"
            />
            <button
              onClick={handleImport}
              disabled={importing || !importPath.trim()}
              className="px-3 py-1.5 text-xs bg-teal-500 text-white rounded-md hover:bg-teal-600 disabled:opacity-50 flex items-center gap-1 shrink-0"
            >
              {importing ? <Loader2 size={12} className="animate-spin" /> : <span>📎</span>}
              {importing ? '导入中' : '导入'}
            </button>
          </div>
          {importResult && (
            <div className={`mt-2 p-2 rounded text-xs ${importResult.error ? 'bg-red-50 text-red-600' : 'bg-green-50 text-green-700'}`}>
              {importResult.error
                ? `导入失败: ${importResult.error}`
                : `已导入 ${importResult.fileName}（${(importResult.fileSize / 1024).toFixed(1)} KB，${importResult.textLength} 字符${importResult.truncated ? '，已截断' : ''}）→ 内容已发送给 AI`
              }
            </div>
          )}
        </div>
      )}

      {/* 消息区 */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages.map((msg, i) => (
          <React.Fragment key={i}>
          <div className={`flex gap-2.5 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            {msg.role !== 'user' && (
              <div className="w-7 h-7 rounded-lg bg-teal-500 flex items-center justify-center shrink-0 mt-0.5">
                {msg.role === 'system' ? <RefreshCw size={12} className="text-white" /> : <Bot size={12} className="text-white" />}
              </div>
            )}
            <div className={`max-w-[85%] px-3 py-2 rounded-xl text-sm leading-relaxed whitespace-pre-wrap ${
              msg.role === 'user'
                ? 'bg-primary-500 text-white rounded-br-md'
                : msg.role === 'system'
                  ? 'bg-amber-50 text-amber-800 border border-amber-200 rounded-bl-md'
                  : 'bg-slate-100 text-slate-700 rounded-bl-md'
            }`}>
              {msg.content}
            </div>
            {msg.role === 'user' && (
              <div className="w-7 h-7 rounded-full bg-primary-100 flex items-center justify-center shrink-0 mt-0.5">
                <User size={12} className="text-primary-500" />
              </div>
            )}
          </div>
          {/* 内联导出按钮：仅对包含可导出内容的助手消息显示 */}
          {isExportable(msg) && (
            <div className="flex justify-center gap-1.5 mt-0.5 animate-in fade-in slide-in-from-top-1 duration-200">
              <button
                onClick={handleGeneratePPT}
                disabled={generatingDoc !== null}
                className="flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-medium
                  bg-orange-50 text-orange-600 border border-orange-200
                  hover:bg-orange-100 hover:border-orange-300
                  disabled:opacity-40 disabled:cursor-not-allowed
                  transition-colors"
              >
                {generatingDoc === 'ppt' ? <Loader2 size={11} className="animate-spin" /> : <FileDown size={11} />}
                {generatingDoc === 'ppt' ? '…' : '导出PPT'}
              </button>
              <button
                onClick={handleGenerateDOCX}
                disabled={generatingDoc !== null}
                className="flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-medium
                  bg-blue-50 text-blue-600 border border-blue-200
                  hover:bg-blue-100 hover:border-blue-300
                  disabled:opacity-40 disabled:cursor-not-allowed
                  transition-colors"
              >
                {generatingDoc === 'docx' ? <Loader2 size={11} className="animate-spin" /> : <FileText size={11} />}
                {generatingDoc === 'docx' ? '…' : '导出Word'}
              </button>
            </div>
          )}
          </React.Fragment>
        ))}

        {/* 思考过程（推理模型输出） */}
        {streamingReasoning && (
          <div className="flex gap-2.5 justify-start">
            <div className="w-7 h-7 rounded-lg bg-slate-400 flex items-center justify-center shrink-0 mt-0.5">
              <Loader2 size={12} className="text-white animate-spin" />
            </div>
            <div className="max-w-[85%] px-3 py-2 rounded-xl rounded-bl-md bg-slate-50 border border-slate-200 text-slate-500 text-xs leading-relaxed whitespace-pre-wrap">
              <span className="text-slate-400 font-medium text-[11px] mb-1 block">思考过程</span>
              {streamingReasoning.slice(-800)}
            </div>
          </div>
        )}

        {/* 流式输出 */}
        {streamingContent && (
          <div className="flex gap-2.5 justify-start">
            <div className="w-7 h-7 rounded-lg bg-teal-500 flex items-center justify-center shrink-0 mt-0.5">
              <Bot size={12} className="text-white" />
            </div>
            <div className="max-w-[85%] px-3 py-2 rounded-xl rounded-bl-md bg-slate-100 text-slate-700 text-sm leading-relaxed whitespace-pre-wrap">
              {streamingContent}
              <span className="ml-0.5 inline-block w-1.5 h-4 bg-teal-500 animate-pulse align-middle" />
            </div>
          </div>
        )}

        {/* 加载占位 */}
        {loading && !streamingContent && !streamingReasoning && (
          <div className="flex gap-2.5 justify-start">
            <div className="w-7 h-7 rounded-lg bg-teal-500 flex items-center justify-center shrink-0 mt-0.5">
              <Loader2 size={12} className="text-white animate-spin" />
            </div>
            <div className="px-3 py-2 rounded-xl rounded-bl-md bg-slate-100 text-slate-400 text-sm">
              思考中...
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* 输入区 */}
      <div className="p-3 border-t border-slate-100">
        <div className="flex gap-2">
          <textarea
            ref={inputRef}
            value={input}
            onChange={e => {
              setInput(e.target.value)
              // 自动调整高度
              const el = e.target
              el.style.height = 'auto'
              el.style.height = Math.min(el.scrollHeight, 150) + 'px'
            }}
            onKeyDown={handleKeyDown}
            placeholder="输入消息... (Enter发送)"
            rows={1}
            className="flex-1 resize-none border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-teal-300 focus:ring-1 focus:ring-teal-200 overflow-y-auto"
          />
          <button
            onClick={handleSend}
            disabled={!input.trim() || loading}
            className="p-2 rounded-lg bg-teal-500 text-white hover:bg-teal-600 disabled:opacity-50 shrink-0"
          >
            <Send size={16} />
          </button>
        </div>
        <p className="text-xs text-slate-400 mt-1.5 text-center">
          数据基于本地数据库，AI 可读取所有工作记录和绩效数据
        </p>
      </div>
    </div>
  )
}
