import { useState, useEffect } from 'react'
import { api } from '../api'
import { Plus, Target, Edit3, Trash2 } from 'lucide-react'

export default function Goals() {
  const [goals, setGoals] = useState([])
  const [loading, setLoading] = useState(true)
  const [loadError, setLoadError] = useState('')
  const [showForm, setShowForm] = useState(false)
  const [editingGoal, setEditingGoal] = useState(null)
  const [form, setForm] = useState(defaultForm())

  function defaultForm() {
    return { title: '', description: '', metric: '', weight: '1', target_value: '', actual_value: '', deadline: '' }
  }

  useEffect(() => { loadGoals() }, [])

  const loadGoals = () => {
    setLoading(true)
    setLoadError('')
    api.getGoals({}).then(setGoals).catch(e => setLoadError(e.message || '加载失败')).finally(() => setLoading(false))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    const data = {
      ...form,
      weight: parseFloat(form.weight) || 1,
      target_value: parseFloat(form.target_value) || 0,
      actual_value: parseFloat(form.actual_value) || 0,
    }
    try {
      if (editingGoal) {
        await api.updateGoal(editingGoal.id, data)
      } else {
        await api.createGoal(data)
      }
      setShowForm(false)
      setEditingGoal(null)
      setForm(defaultForm())
      loadGoals()
    } catch (e) { alert(e.message) }
  }

  const handleEdit = (g) => {
    setEditingGoal(g)
    setForm({ title: g.title, description: g.description, metric: g.metric, weight: String(g.weight), target_value: String(g.target_value), actual_value: String(g.actual_value), deadline: g.deadline || '' })
    setShowForm(true)
  }

  const handleDelete = async (id) => {
    if (!confirm('确认删除此目标？')) return
    try { await api.deleteGoal(id); loadGoals() } catch (e) { alert(e.message) }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">目标管理</h2>
          <p className="text-sm text-slate-500 mt-1">设定和追踪 OKR / KPI 目标</p>
        </div>
        <button onClick={() => { setEditingGoal(null); setForm(defaultForm()); setShowForm(true) }} className="flex items-center gap-2 px-4 py-2 text-sm bg-primary-500 text-white rounded-lg hover:bg-primary-600">
          <Plus size={16} /> 新建目标
        </button>
      </div>

      <div className="grid gap-4">
        {loading ? (
          <div className="text-center py-12 text-slate-400">加载中...</div>
        ) : loadError ? (
          <div className="text-center py-12 bg-white rounded-xl border border-slate-200 text-red-500">
            <p>加载失败: {loadError}</p>
            <button onClick={loadGoals} className="mt-3 px-4 py-2 text-sm bg-primary-500 text-white rounded-lg hover:bg-primary-600">重试</button>
          </div>
        ) : goals.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-xl border border-slate-200 text-slate-400">
            <Target size={32} className="mx-auto mb-2 text-slate-300" />
            <p>暂无目标，点击右上角创建第一个目标</p>
          </div>
        ) : (
          goals.map(g => (
            <div key={g.id} className="bg-white rounded-xl border border-slate-200 p-5">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-semibold text-slate-800">{g.title}</h3>
                    <span className="px-2 py-0.5 text-xs rounded-full bg-primary-50 text-primary-600">权重 {g.weight}</span>
                  </div>
                  {g.description && <p className="text-sm text-slate-500 mb-3">{g.description}</p>}
                  <div className="flex items-center gap-4 text-sm mb-3">
                    <span className="text-slate-500">指标: {g.metric}</span>
                    <span className="text-slate-500">目标: {g.target_value}</span>
                    <span className={`font-medium ${g.progress >= 80 ? 'text-green-600' : g.progress >= 50 ? 'text-amber-600' : 'text-slate-500'}`}>
                      当前: {g.actual_value} ({g.progress}%)
                    </span>
                  </div>
                  {/* 进度条 */}
                  <div className="w-full bg-slate-100 rounded-full h-2.5">
                    <div
                      className="h-2.5 rounded-full transition-all duration-500"
                      style={{ width: `${g.progress}%`, backgroundColor: g.progress >= 80 ? '#0d9488' : g.progress >= 50 ? '#1a73e8' : '#f59e0b' }}
                    />
                  </div>
                </div>
                <div className="flex gap-2 ml-4">
                  <button onClick={() => handleEdit(g)} className="text-slate-400 hover:text-primary-500"><Edit3 size={14} /></button>
                  <button onClick={() => handleDelete(g.id)} className="text-slate-400 hover:text-red-500"><Trash2 size={14} /></button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* 弹窗表单 */}
      {showForm && (
        <div className="fixed inset-0 bg-black/30 flex items-center justify-center z-50" onClick={() => { setShowForm(false); setEditingGoal(null) }}>
          <div className="bg-white rounded-xl p-6 w-full max-w-md shadow-xl" onClick={e => e.stopPropagation()}>
            <h3 className="text-lg font-semibold mb-4">{editingGoal ? '编辑目标' : '新建目标'}</h3>
            <form onSubmit={handleSubmit} className="space-y-3">
              <div>
                <label className="block text-xs text-slate-500 mb-1">目标名称 *</label>
                <input type="text" value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} className="w-full border border-slate-300 rounded-md px-3 py-2 text-sm" required />
              </div>
              <div>
                <label className="block text-xs text-slate-500 mb-1">描述</label>
                <textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} className="w-full border border-slate-300 rounded-md px-3 py-2 text-sm" rows={2} />
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs text-slate-500 mb-1">衡量标准</label>
                  <input type="text" value={form.metric} onChange={e => setForm({ ...form, metric: e.target.value })} className="w-full border border-slate-300 rounded-md px-3 py-2 text-sm" placeholder="如: %" />
                </div>
                <div>
                  <label className="block text-xs text-slate-500 mb-1">权重</label>
                  <input type="number" step="0.1" value={form.weight} onChange={e => setForm({ ...form, weight: e.target.value })} className="w-full border border-slate-300 rounded-md px-3 py-2 text-sm" />
                </div>
                <div>
                  <label className="block text-xs text-slate-500 mb-1">截止日期</label>
                  <input type="date" value={form.deadline} onChange={e => setForm({ ...form, deadline: e.target.value })} className="w-full border border-slate-300 rounded-md px-3 py-2 text-sm" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-slate-500 mb-1">目标值</label>
                  <input type="number" value={form.target_value} onChange={e => setForm({ ...form, target_value: e.target.value })} className="w-full border border-slate-300 rounded-md px-3 py-2 text-sm" />
                </div>
                <div>
                  <label className="block text-xs text-slate-500 mb-1">实际值</label>
                  <input type="number" value={form.actual_value} onChange={e => setForm({ ...form, actual_value: e.target.value })} className="w-full border border-slate-300 rounded-md px-3 py-2 text-sm" />
                </div>
              </div>
              <div className="flex gap-2 pt-2">
                <button type="button" onClick={() => { setShowForm(false); setEditingGoal(null) }} className="flex-1 px-4 py-2 text-sm border border-slate-300 rounded-lg hover:bg-slate-50">取消</button>
                <button type="submit" className="flex-1 px-4 py-2 text-sm bg-primary-500 text-white rounded-lg hover:bg-primary-600">{editingGoal ? '保存' : '创建'}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
