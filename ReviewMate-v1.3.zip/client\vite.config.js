import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: 'http://localhost:3001',
        changeOrigin: true,
        timeout: 600000,       // 代理请求超时 10 分钟（适配 AI 报告生成等长耗时操作）
        proxyTimeout: 600000,  // 代理等待后端响应超时 10 分钟
      }
    }
  }
})
