import { useState, useEffect } from 'react'
import { api } from '../api'
import { Plus, Upload, Search, Edit3, Trash2, CloudLightning, Calendar, CheckSquare, Loader2 } from 'lucide-react'

export default function WorkRecords() {
  const [records, setRecords] = useState([])
  const [loading, setLoading] = useState(true)
  const [filters, setFilters] = useState({ start: '', end: '', search: '' })
  const [showForm, setShowForm] = useState(false)
  const [showImport, setShowImport] = useState(false)
  const [editRecord, setEditRecord] = useState(null)
  const [form, setForm] = useState({ date: today(), project: '', task: '', duration_hours: '', tags: '', status: 'completed' })
  const [importForm, setImportForm] = useState({ dirPath: '', startDate: today(-7), endDate: today() })

  // 飞书导入状态
  const [showFeishuImport, setShowFeishuImport] = useState(false)
  const [feishuStart, setFeishuStart] = useState(today(-7))
  const [feishuEnd, setFeishuEnd] = useState(today())
  const [feishuEvents, setFeishuEvents] = useState([])
  const [feishuTasks, setFeishuTasks] = useState([])
  const [feishuLoading, setFeishuLoading] = useState(false)
  const [feishuMsg, setFeishuMsg] = useState('')
  const [feishuSelected, setFeishuSelected] = useState({})
  const [feishuImporting, setFeishuImporting] = useState(false)

  function today(offset = 0) {
    const d = new Date()
    d.setDate(d.getDate() + offset)
    return d.toISOString().split('T')[0]
  }

  const [loadError, setLoadError] = useState('')

  const loadRecords = () => {
    setLoading(true)
    setLoadError('')
    const params = {}
    if (filters.start) params.start = filters.start
    if (filters.end) params.end = filters.end
    if (filters.search) params.search = filters.search
    api.getRecords(params).then(res => setRecords(res.data)).catch(e => setLoadError(e.message || '加载失败')).finally(() => setLoading(false))
  }

  useEffect(() => { loadRecords() }, [])

  const handleSubmit = async (e) => {
    e.preventDefault()
    const data = {
      ...form,
      duration_hours: parseFloat(form.duration_hours) || 0,
      tags: form.tags ? form.tags.split(/[,;，、]/).map(t => t.trim()).filter(Boolean) : []
    }
    try {
      if (editRecord) {
        await api.updateRecord(editRecord.id, data)
      } else {
        await api.createRecord(data)
      }
      setShowForm(false)
      setEditRecord(null)
      setForm({ date: today(), project: '', task: '', duration_hours: '', tags: '', status: 'completed' })
      loadRecords()
    } catch (e) {
      console.error('保存工作记录失败:', e)
      alert('保存失败: ' + (e.message || '未知错误'))
    }
  }

  const handleEdit = (r) => {
    setEditRecord(r)
    setForm({ date: r.date, project: r.project, task: r.task, duration_hours: r.duration_hours, tags: Array.isArray(r.tags) ? r.tags.join(', ') : '', status: r.status })
    setShowForm(true)
  }

  const handleDelete = async (id) => {
    if (!confirm('确认删除此记录？')) return
    try { await api.deleteRecord(id); loadRecords() } catch (e) { alert(e.message) }
  }

  const handleImport = async (e) => {
    e.preventDefault()
    try {
      const res = await api.importRecords(importForm)
      alert(`导入成功：${res.imported} 条记录（扫描 ${res.files} 个文件）`)
      setShowImport(false)
      loadRecords()
    } catch (e) { alert(e.message) }
  }

  // 飞书：获取日历事件
  const fetchFeishuCalendar = async () => {
    setFeishuLoading(true)
    setFeishuMsg('')
    try {
      const res = await api.getFeishuCalendarEvents({ start: feishuStart, end: feishuEnd })
      setFeishuEvents(res.events || [])
      res.events.forEach(e => {
        setFeishuSelected(prev => ({ ...prev, [`cal_${e.id}`]: false }))
      })
      setFeishuMsg(res.events?.length ? `获取到 ${res.events.length} 个日历事件` : '该时间段内无日历事件')
    } catch (e) {
      setFeishuMsg('获取失败: ' + e.message)
    } finally {
      setFeishuLoading(false)
    }
  }

  // 飞书：获取任务
  const fetchFeishuTasks = async () => {
    setFeishuLoading(true)
    setFeishuMsg('')
    try {
      const res = await api.getFeishuTasks()
      setFeishuTasks(res.tasks || [])
      res.tasks.forEach(t => {
        setFeishuSelected(prev => ({ ...prev, [`task_${t.id}`]: false }))
      })
      setFeishuMsg(res.tasks?.length ? `获取到 ${res.tasks.length} 个任务` : '暂无飞书任务')
    } catch (e) {
      setFeishuMsg('获取失败: ' + e.message)
    } finally {
      setFeishuLoading(false)
    }
  }

  const toggleFeishuSelect = (key) => {
    setFeishuSelected(prev => ({ ...prev, [key]: !prev[key] }))
  }

  const selectAllFeishu = (prefix, items) => {
    setFeishuSelected(prev => {
      const next = { ...prev }
      items.forEach(item => { next[`${prefix}_${item.id}`] = true })
      return next
    })
  }

  const handleFeishuImport = async () => {
    const items = []
    feishuEvents.forEach(e => {
      if (feishuSelected[`cal_${e.id}`]) {
        items.push({
          summary: e.summary,
          date: e.startTime?.slice(0, 10) || feishuStart,
          durationHours: e.durationHours || 1,
          tags: ['飞书', '会议'],
          status: 'completed',
          source: 'calendar',
          sourceId: e.id,
          notes: e.description || '',
          project: '飞书日历',
        })
      }
    })
    feishuTasks.forEach(t => {
      if (feishuSelected[`task_${t.id}`]) {
        items.push({
          summary: t.summary,
          date: t.dueDate || today(),
          durationHours: 0,
          tags: ['飞书', '任务'],
          status: t.completed ? 'completed' : 'planned',
          source: 'task',
          sourceId: t.id,
          notes: t.description || '',
          project: '飞书任务',
        })
      }
    })

    if (items.length === 0) { alert('请至少选择一条记录'); return }

    setFeishuImporting(true)
    try {
      const res = await api.importFeishuItems(items)
      alert(`从飞书导入成功：${res.imported} 条记录`)
      setShowFeishuImport(false)
      setFeishuEvents([])
      setFeishuTasks([])
      setFeishuSelected({})
      loadRecords()
    } catch (e) {
      alert('导入失败: ' + e.message)
    } finally {
      setFeishuImporting(false)
    }
  }

  const selectedCount = Object.values(feishuSelected).filter(Boolean).length

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">工作记录</h2>
          <p className="text-sm text-slate-500 mt-1">管理和导入日常工作记录</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => { setShowFeishuImport(true); setFeishuMsg(''); setFeishuEvents([]); setFeishuTasks([]); setFeishuSelected({}) }} className="flex items-center gap-2 px-4 py-2 text-sm border border-blue-300 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100">
            <CloudLightning size={16} /> 从飞书导入
          </button>
          <button onClick={() => setShowImport(true)} className="flex items-center gap-2 px-4 py-2 text-sm border border-slate-300 rounded-lg hover:bg-slate-50">
            <Upload size={16} /> 批量导入
          </button>
          <button onClick={() => { setEditRecord(null); setForm({ date: today(), project: '', task: '', duration_hours: '', tags: '', status: 'completed' }); setShowForm(true) }} className="flex items-center gap-2 px-4 py-2 text-sm bg-primary-500 text-white rounded-lg hover:bg-primary-600">
            <Plus size={16} /> 新增记录
          </button>
        </div>
      </div>

      {/* 过滤器 */}
      <div className="flex items-center gap-3 bg-white p-3 rounded-lg border border-slate-200">
        <div className="flex items-center gap-2">
          <input type="date" value={filters.start} onChange={e => setFilters({ ...filters, start: e.target.value })} className="border border-slate-300 rounded-md px-3 py-1.5 text-sm" />
          <span className="text-slate-400">—</span>
          <input type="date" value={filters.end} onChange={e => setFilters({ ...filters, end: e.target.value })} className="border border-slate-300 rounded-md px-3 py-1.5 text-sm" />
        </div>
        <div className="relative flex-1 max-w-xs">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input type="text" placeholder="搜索任务..." value={filters.search} onChange={e => setFilters({ ...filters, search: e.target.value })} className="w-full pl-9 pr-3 py-1.5 border border-slate-300 rounded-md text-sm" />
        </div>
        <button onClick={loadRecords} className="px-4 py-1.5 text-sm bg-slate-100 rounded-md hover:bg-slate-200">查询</button>
      </div>

      {/* 记录列表 */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 border-b border-slate-200">
            <tr>
              <th className="text-left px-4 py-3 font-medium text-slate-500">日期</th>
              <th className="text-left px-4 py-3 font-medium text-slate-500">项目</th>
              <th className="text-left px-4 py-3 font-medium text-slate-500">任务</th>
              <th className="text-left px-4 py-3 font-medium text-slate-500">耗时(h)</th>
              <th className="text-left px-4 py-3 font-medium text-slate-500">标签</th>
              <th className="text-left px-4 py-3 font-medium text-slate-500">状态</th>
              <th className="text-left px-4 py-3 font-medium text-slate-500">操作</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={7} className="text-center py-12 text-slate-400">加载中...</td></tr>
            ) : loadError ? (
              <tr><td colSpan={7} className="text-center py-12 text-red-500">
                <p>加载失败: {loadError}</p>
                <button onClick={loadRecords} className="mt-2 px-4 py-2 text-sm bg-primary-500 text-white rounded-lg hover:bg-primary-600">重试</button>
              </td></tr>
            ) : records.length === 0 ? (
              <tr><td colSpan={7} className="text-center py-12 text-slate-400">暂无工作记录，点击右上角新增或导入</td></tr>
            ) : (
              records.map(r => (
                <tr key={r.id} className="border-b border-slate-50 hover:bg-slate-50/50">
                  <td className="px-4 py-3 text-slate-600">{r.date}</td>
                  <td className="px-4 py-3 text-slate-600">{r.project || '-'}</td>
                  <td className="px-4 py-3 text-slate-800">{r.task}</td>
                  <td className="px-4 py-3 text-slate-600">{Number(r.duration_hours).toFixed(2)}</td>
                  <td className="px-4 py-3">
                    <div className="flex gap-1 flex-wrap">
                      {(Array.isArray(r.tags) ? r.tags : []).map(t => (
                        <span key={t} className="px-2 py-0.5 text-xs rounded-full bg-primary-50 text-primary-600">{t}</span>
                      ))}
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-0.5 text-xs rounded-full ${r.status === 'completed' ? 'bg-green-50 text-green-600' : 'bg-amber-50 text-amber-600'}`}>
                      {r.status === 'completed' ? '已完成' : '计划中'}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex gap-2">
                      <button onClick={() => handleEdit(r)} className="text-slate-400 hover:text-primary-500"><Edit3 size={14} /></button>
                      <button onClick={() => handleDelete(r.id)} className="text-slate-400 hover:text-red-500"><Trash2 size={14} /></button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* 飞书导入弹窗 */}
      {showFeishuImport && (
        <div className="fixed inset-0 bg-black/30 flex items-center justify-center z-50" onClick={() => setShowFeishuImport(false)}>
          <div className="bg-white rounded-xl p-6 w-full max-w-2xl max-h-[85vh] overflow-auto shadow-xl" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <CloudLightning size={20} className="text-blue-500" />
                <h3 className="text-lg font-semibold">从飞书导入工作记录</h3>
              </div>
              <button onClick={() => setShowFeishuImport(false)} className="text-slate-400 hover:text-slate-600 text-lg leading-none">&times;</button>
            </div>
            <p className="text-sm text-slate-500 mb-4">从飞书日历和任务中拉取数据，选择需要导入的条目</p>

            {/* 日期选择 + 获取按钮 */}
            <div className="flex items-end gap-2 mb-4">
              <div>
                <label className="block text-xs text-slate-500 mb-1">开始日期</label>
                <input type="date" value={feishuStart} onChange={e => setFeishuStart(e.target.value)} className="border border-slate-300 rounded-md px-3 py-2 text-sm" />
              </div>
              <div>
                <label className="block text-xs text-slate-500 mb-1">结束日期</label>
                <input type="date" value={feishuEnd} onChange={e => setFeishuEnd(e.target.value)} className="border border-slate-300 rounded-md px-3 py-2 text-sm" />
              </div>
              <button onClick={fetchFeishuCalendar} disabled={feishuLoading}
                className="flex items-center gap-1.5 px-4 py-2 text-sm bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:opacity-50">
                <Calendar size={14} /> 获取日历
              </button>
              <button onClick={fetchFeishuTasks} disabled={feishuLoading}
                className="flex items-center gap-1.5 px-4 py-2 text-sm bg-teal-500 text-white rounded-lg hover:bg-teal-600 disabled:opacity-50">
                <CheckSquare size={14} /> 获取任务
              </button>
            </div>

            {feishuLoading && (
              <div className="flex items-center gap-2 text-sm text-slate-500 py-4">
                <Loader2 size={16} className="animate-spin" /> 正在从飞书获取数据...
              </div>
            )}

            {feishuMsg && !feishuLoading && (
              <div className={`text-sm mb-3 px-3 py-2 rounded-md ${feishuMsg.includes('失败') ? 'bg-red-50 text-red-600' : 'bg-blue-50 text-blue-600'}`}>
                {feishuMsg}
              </div>
            )}

            {/* 日历事件列表 */}
            {feishuEvents.length > 0 && (
              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-sm font-semibold text-slate-700 flex items-center gap-1.5">
                    <Calendar size={14} className="text-blue-500" /> 日历事件
                  </h4>
                  <button onClick={() => selectAllFeishu('cal', feishuEvents)} className="text-xs text-blue-500 hover:text-blue-600">全选</button>
                </div>
                <div className="space-y-1 max-h-48 overflow-auto border border-slate-100 rounded-lg">
                  {feishuEvents.map(e => (
                    <label key={`cal_${e.id}`} className="flex items-start gap-2 px-3 py-2 hover:bg-slate-50 cursor-pointer border-b border-slate-50">
                      <input type="checkbox" checked={!!feishuSelected[`cal_${e.id}`]} onChange={() => toggleFeishuSelect(`cal_${e.id}`)} className="mt-0.5 rounded" />
                      <div className="flex-1 min-w-0">
                        <div className="text-sm text-slate-800 truncate">{e.summary}</div>
                        <div className="text-xs text-slate-400">
                          {e.startTime?.slice(0, 16)?.replace('T', ' ')} | {e.durationHours > 0 ? `${e.durationHours}h` : '全天'} | {e.calendar}
                        </div>
                      </div>
                    </label>
                  ))}
                </div>
              </div>
            )}

            {/* 任务列表 */}
            {feishuTasks.length > 0 && (
              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-sm font-semibold text-slate-700 flex items-center gap-1.5">
                    <CheckSquare size={14} className="text-teal-500" /> 飞书任务
                  </h4>
                  <button onClick={() => selectAllFeishu('task', feishuTasks)} className="text-xs text-blue-500 hover:text-blue-600">全选</button>
                </div>
                <div className="space-y-1 max-h-48 overflow-auto border border-slate-100 rounded-lg">
                  {feishuTasks.map(t => (
                    <label key={`task_${t.id}`} className="flex items-start gap-2 px-3 py-2 hover:bg-slate-50 cursor-pointer border-b border-slate-50">
                      <input type="checkbox" checked={!!feishuSelected[`task_${t.id}`]} onChange={() => toggleFeishuSelect(`task_${t.id}`)} className="mt-0.5 rounded" />
                      <div className="flex-1 min-w-0">
                        <div className={`text-sm truncate ${t.completed ? 'text-slate-400 line-through' : 'text-slate-800'}`}>{t.summary}</div>
                        <div className="text-xs text-slate-400">
                          {t.dueDate ? `截止: ${t.dueDate}` : '无截止日期'} | {t.completed ? '已完成' : '未完成'}
                        </div>
                      </div>
                    </label>
                  ))}
                </div>
              </div>
            )}

            {/* 导入按钮 */}
            <div className="flex items-center justify-between pt-3 border-t border-slate-100">
              <span className="text-sm text-slate-500">已选 <span className="font-semibold text-primary-500">{selectedCount}</span> 条</span>
              <div className="flex gap-2">
                <button onClick={() => setShowFeishuImport(false)} className="px-4 py-2 text-sm border border-slate-300 rounded-lg hover:bg-slate-50">取消</button>
                <button onClick={handleFeishuImport} disabled={selectedCount === 0 || feishuImporting}
                  className="px-4 py-2 text-sm bg-primary-500 text-white rounded-lg hover:bg-primary-600 disabled:opacity-50">
                  {feishuImporting ? '导入中...' : `导入选中 (${selectedCount})`}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 新增/编辑弹窗 */}
      {showForm && (
        <div className="fixed inset-0 bg-black/30 flex items-center justify-center z-50" onClick={() => { setShowForm(false); setEditRecord(null) }}>
          <div className="bg-white rounded-xl p-6 w-full max-w-md shadow-xl" onClick={e => e.stopPropagation()}>
            <h3 className="text-lg font-semibold mb-4">{editRecord ? '编辑记录' : '新增工作记录'}</h3>
            <form onSubmit={handleSubmit} className="space-y-3">
              <div>
                <label className="block text-xs text-slate-500 mb-1">日期</label>
                <input type="date" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} className="w-full border border-slate-300 rounded-md px-3 py-2 text-sm" required />
              </div>
              <div>
                <label className="block text-xs text-slate-500 mb-1">项目</label>
                <input type="text" value={form.project} onChange={e => setForm({ ...form, project: e.target.value })} className="w-full border border-slate-300 rounded-md px-3 py-2 text-sm" placeholder="如：用户系统" />
              </div>
              <div>
                <label className="block text-xs text-slate-500 mb-1">任务描述 *</label>
                <input type="text" value={form.task} onChange={e => setForm({ ...form, task: e.target.value })} className="w-full border border-slate-300 rounded-md px-3 py-2 text-sm" placeholder="任务内容" required />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-slate-500 mb-1">耗时(小时)</label>
                  <input type="number" step="0.5" value={form.duration_hours} onChange={e => setForm({ ...form, duration_hours: e.target.value })} className="w-full border border-slate-300 rounded-md px-3 py-2 text-sm" />
                </div>
                <div>
                  <label className="block text-xs text-slate-500 mb-1">状态</label>
                  <select value={form.status} onChange={e => setForm({ ...form, status: e.target.value })} className="w-full border border-slate-300 rounded-md px-3 py-2 text-sm">
                    <option value="completed">已完成</option>
                    <option value="planned">计划中</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-xs text-slate-500 mb-1">标签（逗号分隔）</label>
                <input type="text" value={form.tags} onChange={e => setForm({ ...form, tags: e.target.value })} className="w-full border border-slate-300 rounded-md px-3 py-2 text-sm" placeholder="如：开发, 核心功能, 前端" />
              </div>
              <div className="flex gap-2 pt-2">
                <button type="button" onClick={() => { setShowForm(false); setEditRecord(null) }} className="flex-1 px-4 py-2 text-sm border border-slate-300 rounded-lg hover:bg-slate-50">取消</button>
                <button type="submit" className="flex-1 px-4 py-2 text-sm bg-primary-500 text-white rounded-lg hover:bg-primary-600">{editRecord ? '保存' : '创建'}</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 导入弹窗 */}
      {showImport && (
        <div className="fixed inset-0 bg-black/30 flex items-center justify-center z-50" onClick={() => setShowImport(false)}>
          <div className="bg-white rounded-xl p-6 w-full max-w-md shadow-xl" onClick={e => e.stopPropagation()}>
            <h3 className="text-lg font-semibold mb-4">批量导入工作记录</h3>
            <p className="text-sm text-slate-500 mb-4">扫描指定目录下的 .md / .txt / .json / .csv 文件，自动解析工作记录</p>
            <form onSubmit={handleImport} className="space-y-3">
              <div>
                <label className="block text-xs text-slate-500 mb-1">工作目录路径</label>
                <input type="text" value={importForm.dirPath} onChange={e => setImportForm({ ...importForm, dirPath: e.target.value })} className="w-full border border-slate-300 rounded-md px-3 py-2 text-sm" placeholder="C:\Users\xxx\work-logs" required />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-slate-500 mb-1">开始日期</label>
                  <input type="date" value={importForm.startDate} onChange={e => setImportForm({ ...importForm, startDate: e.target.value })} className="w-full border border-slate-300 rounded-md px-3 py-2 text-sm" />
                </div>
                <div>
                  <label className="block text-xs text-slate-500 mb-1">结束日期</label>
                  <input type="date" value={importForm.endDate} onChange={e => setImportForm({ ...importForm, endDate: e.target.value })} className="w-full border border-slate-300 rounded-md px-3 py-2 text-sm" />
                </div>
              </div>
              <div className="flex gap-2 pt-2">
                <button type="button" onClick={() => setShowImport(false)} className="flex-1 px-4 py-2 text-sm border border-slate-300 rounded-lg hover:bg-slate-50">取消</button>
                <button type="submit" className="flex-1 px-4 py-2 text-sm bg-primary-500 text-white rounded-lg hover:bg-primary-600">开始导入</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
