import { Outlet, NavLink } from 'react-router-dom'
import { useState } from 'react'
import { LayoutDashboard, ClipboardList, BarChart3, FileText, Target, Settings, RefreshCw, Star, MessageSquare } from 'lucide-react'
import ChatPanel from './ChatPanel'

const navItems = [
  { to: '/', icon: LayoutDashboard, label: '仪表盘' },
  { to: '/records', icon: ClipboardList, label: '工作记录' },
  { to: '/performance', icon: BarChart3, label: '绩效看板' },
  { to: '/reports', icon: FileText, label: '复盘报告' },
  { to: '/goals', icon: Target, label: '目标管理' },
  { to: '/settings', icon: Settings, label: '设置' },
]

export default function Layout() {
  const [chatOpen, setChatOpen] = useState(false)

  return (
    <div className="flex h-screen bg-slate-50">
      {/* 侧边栏 */}
      <aside className="w-60 bg-white border-r border-slate-200 flex flex-col">
        <div className="p-5 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-primary-500 flex items-center justify-center">
              <RefreshCw size={18} className="text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-slate-800 tracking-tight">ReviewMate</h1>
              <p className="text-xs text-slate-400">复盘助手</p>
            </div>
          </div>
        </div>
        <nav className="flex-1 p-3 space-y-1">
          {navItems.map(item => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === '/'}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                  isActive
                    ? 'bg-primary-50 text-primary-600'
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-800'
                }`
              }
            >
              <item.icon size={18} />
              {item.label}
            </NavLink>
          ))}
        </nav>

        {/* AI 对话入口 */}
        <div className="p-3 border-t border-slate-100">
          <button
            onClick={() => setChatOpen(!chatOpen)}
            className={`flex items-center gap-3 w-full px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
              chatOpen
                ? 'bg-teal-50 text-teal-600'
                : 'text-slate-500 hover:bg-teal-50 hover:text-teal-600'
            }`}
          >
            <MessageSquare size={18} />
            <span>AI 助手</span>
            <span className="ml-auto w-2 h-2 rounded-full bg-teal-500 animate-pulse" />
          </button>
        </div>

        <div className="p-4 border-t border-slate-100">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <Star size={14} className="text-teal-500" />
            <span>ReviewMate v1.0</span>
          </div>
        </div>
      </aside>

      {/* 主内容区 */}
      <main className="flex-1 overflow-auto">
        <div className="p-6 max-w-7xl mx-auto">
          <Outlet />
        </div>
      </main>

      {/* AI 对话面板 */}
      {chatOpen && <ChatPanel onClose={() => setChatOpen(false)} />}
    </div>
  )
}
