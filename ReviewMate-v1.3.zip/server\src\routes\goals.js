const express = require('express');
const { getDb } = require('../db/init');

const router = express.Router();

// GET /api/goals - 查询目标
router.get('/', (req, res) => {
  let db;
  try {
    db = getDb();
    const { status } = req.query;
    let sql = 'SELECT * FROM goals WHERE 1=1';
    const params = [];
    if (status) { sql += ' AND status = ?'; params.push(status); }
    sql += ' ORDER BY weight DESC, created_at DESC';

    const goals = db.prepare(sql).all(...params);
    res.json(goals.map(g => ({
      ...g,
      progress: g.target_value > 0 ? Math.round(g.actual_value / g.target_value * 100) : 0
    })));
  } catch (e) {
    res.status(500).json({ error: e.message });
  } finally {
    if (db) db.close();
  }
});

// POST /api/goals - 新建目标
router.post('/', (req, res) => {
  let db;
  try {
    db = getDb();
    const { title, description, metric, weight, target_value, actual_value, deadline, parent_id, status } = req.body;
    if (!title) return res.status(400).json({ error: 'title 为必填项' });

    const result = db.prepare(
      'INSERT INTO goals (title, description, metric, weight, target_value, actual_value, deadline, parent_id, status) VALUES (?,?,?,?,?,?,?,?,?)'
    ).run(title, description || '', metric || '', weight || 1, target_value || 0, actual_value || 0, deadline || null, parent_id || null, status || 'active');

    const goal = db.prepare('SELECT * FROM goals WHERE id = ?').get(result.lastInsertRowid);
    goal.progress = goal.target_value > 0 ? Math.round(goal.actual_value / goal.target_value * 100) : 0;
    res.status(201).json(goal);
  } catch (e) {
    res.status(500).json({ error: e.message });
  } finally {
    if (db) db.close();
  }
});

// PUT /api/goals/:id - 更新目标
router.put('/:id', (req, res) => {
  let db;
  try {
    db = getDb();
    const existing = db.prepare('SELECT * FROM goals WHERE id = ?').get(req.params.id);
    if (!existing) return res.status(404).json({ error: '目标不存在' });

    const { title, description, metric, weight, target_value, actual_value, deadline, parent_id, status } = req.body;

    db.prepare(`
      UPDATE goals SET title=?, description=?, metric=?, weight=?, target_value=?, actual_value=?,
      deadline=?, parent_id=?, status=?, updated_at=datetime('now','localtime')
      WHERE id=?
    `).run(
      title || existing.title, description ?? existing.description, metric ?? existing.metric,
      weight ?? existing.weight, target_value ?? existing.target_value, actual_value ?? existing.actual_value,
      deadline ?? existing.deadline, parent_id ?? existing.parent_id, status || existing.status,
      req.params.id
    );

    const goal = db.prepare('SELECT * FROM goals WHERE id = ?').get(req.params.id);
    goal.progress = goal.target_value > 0 ? Math.round(goal.actual_value / goal.target_value * 100) : 0;
    res.json(goal);
  } catch (e) {
    res.status(500).json({ error: e.message });
  } finally {
    if (db) db.close();
  }
});

// DELETE /api/goals/:id
router.delete('/:id', (req, res) => {
  let db;
  try {
    db = getDb();
    const result = db.prepare('DELETE FROM goals WHERE id = ?').run(req.params.id);
    if (result.changes === 0) return res.status(404).json({ error: '目标不存在' });
    res.json({ deleted: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  } finally {
    if (db) db.close();
  }
});

module.exports = router;
