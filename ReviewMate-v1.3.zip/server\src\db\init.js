const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

// 尝试从 db-config.json 读取自定义数据库路径
function getDbPath() {
  const configPath = path.join(__dirname, '..', '..', 'db-config.json');
  try {
    if (fs.existsSync(configPath)) {
      const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
      if (config.db_path && typeof config.db_path === 'string') {
        console.log('使用自定义数据库路径:', config.db_path);
        return config.db_path;
      }
    }
  } catch (e) {
    console.warn('读取 db-config.json 失败，使用默认路径:', e.message);
  }
  return path.join(__dirname, '..', '..', 'data', 'reviewmate.db');
}

// 可热重载的数据库路径（初始从配置文件读取，运行时可通过 reloadConfig 更新）
let currentDbPath = getDbPath();

// 获取当前数据库路径（用于导出给路由使用）
function getCurrentDbPath() {
  return currentDbPath;
}

// 重新加载配置文件，更新数据库路径（支持运行时切换，无需重启）
function reloadConfig() {
  const configPath = path.join(__dirname, '..', '..', 'db-config.json');
  if (!fs.existsSync(configPath)) return null;
  try {
    const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
    if (config.db_path && typeof config.db_path === 'string') {
      const absPath = path.resolve(config.db_path);
      console.log('热重载数据库路径:', absPath);
      currentDbPath = absPath;
      return absPath;
    }
  } catch (e) {
    console.warn('热重载配置失败:', e.message);
  }
  return null;
}

function getDb() {
  const db = new Database(currentDbPath);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  return db;
}

// 使用 SQLite backup API 安全备份数据库到目标路径
function backupDb(targetPath) {
  const srcDb = new Database(currentDbPath);
  srcDb.pragma('busy_timeout = 5000');

  const dir = path.dirname(targetPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  const destDb = new Database(targetPath);
  destDb.pragma('journal_mode = WAL');
  destDb.pragma('foreign_keys = ON');

  try {
    srcDb.backup(destDb);
    console.log('数据库备份完成:', targetPath);
  } finally {
    destDb.close();
    srcDb.close();
  }
}

// 共享建表 SQL（供 initDb 和 new-db 端点复用）
function createTables(db) {
  db.exec(`
    -- 工作记录表
    CREATE TABLE IF NOT EXISTS work_records (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      date TEXT NOT NULL,
      project TEXT NOT NULL DEFAULT '',
      task TEXT NOT NULL,
      duration_hours REAL NOT NULL DEFAULT 0,
      tags TEXT NOT NULL DEFAULT '[]',
      status TEXT NOT NULL DEFAULT 'completed',
      source_file TEXT DEFAULT '',
      notes TEXT DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
    );

    -- 绩效指标表
    CREATE TABLE IF NOT EXISTS performance_metrics (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      period_type TEXT NOT NULL,
      period_start TEXT NOT NULL,
      period_end TEXT NOT NULL,
      total_tasks INTEGER NOT NULL DEFAULT 0,
      completed_tasks INTEGER NOT NULL DEFAULT 0,
      total_hours REAL NOT NULL DEFAULT 0,
      planned_hours REAL NOT NULL DEFAULT 0,
      completion_rate REAL NOT NULL DEFAULT 0,
      estimation_accuracy REAL NOT NULL DEFAULT 0,
      output_density REAL NOT NULL DEFAULT 0,
      goal_achievement_rate REAL NOT NULL DEFAULT 0,
      tag_distribution TEXT NOT NULL DEFAULT '{}',
      highlights TEXT NOT NULL DEFAULT '[]',
      lowlights TEXT NOT NULL DEFAULT '[]',
      created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
    );

    -- 目标表
    CREATE TABLE IF NOT EXISTS goals (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      parent_id INTEGER DEFAULT NULL,
      title TEXT NOT NULL,
      description TEXT DEFAULT '',
      metric TEXT DEFAULT '',
      weight REAL NOT NULL DEFAULT 1.0,
      target_value REAL NOT NULL DEFAULT 0,
      actual_value REAL NOT NULL DEFAULT 0,
      deadline TEXT DEFAULT NULL,
      status TEXT NOT NULL DEFAULT 'active',
      created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
      FOREIGN KEY (parent_id) REFERENCES goals(id)
    );

    -- 复盘报告表
    CREATE TABLE IF NOT EXISTS review_reports (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      report_type TEXT NOT NULL,
      title TEXT NOT NULL,
      period_start TEXT NOT NULL,
      period_end TEXT NOT NULL,
      content TEXT NOT NULL DEFAULT '',
      stats_json TEXT NOT NULL DEFAULT '{}',
      created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
    );

    -- 设置表
    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL DEFAULT ''
    );
  `);

  // 插入默认设置
  const insertSetting = db.prepare(
    'INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)'
  );
  insertSetting.run('work_dir', path.join(require('os').homedir(), 'work-logs'));
  insertSetting.run('weekly_report_template', JSON.stringify({
    sections: ['本周完成', '未完成事项', '下周计划', '需要的支持', '关键数据']
  }));
  insertSetting.run('monthly_report_template', JSON.stringify({
    sections: ['月度目标达成', '重点项目进展', '时间投入分布', '产出量化', '能力成长', '下月规划']
  }));
  insertSetting.run('summary_report_template', JSON.stringify({
    sections: ['关键成果', '能力成长', '价值贡献', '经验教训', '职业规划']
  }));
}

function initDb() {
  const dir = path.dirname(currentDbPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  const db = getDb();
  createTables(db);

  console.log('数据库初始化完成:', currentDbPath);
  db.close();
}

// 直接运行时初始化
if (require.main === module) {
  initDb();
}

// DB_PATH 保持向后兼容（用于已有引用）
const DB_PATH = currentDbPath;

module.exports = { getDb, initDb, createTables, backupDb, reloadConfig, getCurrentDbPath, DB_PATH };
