import { useState, useCallback } from 'react'

const SPLASH_KEY = 'reviewmate_splash_shown'

export default function SplashScreen({ onEnter }) {
  const [entered, setEntered] = useState(false)

  const handleEnter = useCallback(() => {
    if (entered) return
    setEntered(true)
    localStorage.setItem(SPLASH_KEY, '1')
    setTimeout(() => onEnter(), 800)
  }, [onEnter, entered])

  return (
    <div
      className={`splash-root ${entered ? 'splash-exit' : ''}`}
      onClick={handleEnter}
    >
      {/* 背景粒子 */}
      <ParticleField />

      {/* 背景网格 */}
      <div className="splash-grid" />

      {/* 角落装饰 */}
      <div className="absolute top-0 left-0 w-72 h-72 bg-gradient-to-br from-cyan-500/10 to-transparent rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-gradient-to-tl from-fuchsia-500/10 to-transparent rounded-full blur-3xl translate-x-1/3 translate-y-1/3" />

      {/* 主内容 */}
      <div className={`splash-content ${entered ? 'splash-content-exit' : ''}`}>
        {/* Logo 区域 */}
        <div className="splash-logo-area">
          <div className="splash-logo-icon">
            <svg viewBox="0 0 48 48" fill="none" className="w-full h-full">
              {/* 文件主体 */}
              <path d="M12 6h18l10 10v26a4 4 0 01-4 4H12a4 4 0 01-4-4V10a4 4 0 014-4z"
                stroke="currentColor" strokeWidth="1.5" fill="none"
                className="logo-file-body" />
              {/* 折角 */}
              <path d="M30 6v8a2 2 0 002 2h8"
                stroke="currentColor" strokeWidth="1.5" fill="none"
                strokeLinecap="round" strokeLinejoin="round"
                className="logo-fold" />
              {/* 中间对勾 */}
              <path d="M17 25l5 5 10-10" stroke="currentColor" strokeWidth="2.2"
                strokeLinecap="round" strokeLinejoin="round"
                className="logo-check" />
            </svg>
          </div>
          <h1 className="splash-title">
            <span className="splash-title-text" data-text="ReviewMate">ReviewMate</span>
          </h1>
          <p className="splash-subtitle">AI 驱动的职场复盘助手</p>
        </div>

        {/* 点击进入提示 */}
        <div className="splash-tap-hint">
          <div className="splash-tap-ring" />
          <span className="splash-tap-label">点击任意位置进入</span>
        </div>
      </div>

      <style>{`
        .splash-root {
          position: fixed;
          inset: 0;
          z-index: 9999;
          background: #06060d;
          display: flex;
          align-items: center;
          justify-content: center;
          overflow: hidden;
          cursor: pointer;
          transition: opacity 0.6s ease, transform 0.6s cubic-bezier(0.16, 1, 0.3, 1);
        }
        .splash-root.splash-exit {
          opacity: 0;
          transform: scale(1.05);
          pointer-events: none;
        }
        .splash-root:hover .splash-tap-ring {
          transform: scale(1.15);
          border-color: rgba(255,255,255,0.25);
        }
        .splash-root:hover .splash-tap-label {
          color: rgba(255,255,255,0.55);
        }

        .splash-grid {
          position: absolute;
          inset: 0;
          background-image:
            linear-gradient(rgba(255,255,255,0.02) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255,255,255,0.02) 1px, transparent 1px);
          background-size: 48px 48px;
          mask-image: radial-gradient(ellipse at center, black 30%, transparent 70%);
          pointer-events: none;
        }

        .splash-content {
          position: relative;
          z-index: 1;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 2.5rem;
          animation: splashFadeIn 0.8s ease-out;
          pointer-events: none;
        }
        .splash-content.splash-content-exit {
          animation: splashFadeOut 0.6s ease-in forwards;
        }

        @keyframes splashFadeIn {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes splashFadeOut {
          to { opacity: 0; transform: translateY(-20px); }
        }

        .splash-logo-area {
          text-align: center;
        }

        .splash-logo-icon {
          width: 64px;
          height: 64px;
          margin: 0 auto 1rem;
          color: #22d3ee;
          animation: logoPulse 2s ease-in-out infinite;
        }
        @keyframes logoPulse {
          0%, 100% { filter: drop-shadow(0 0 8px #22d3ee40); }
          50% { filter: drop-shadow(0 0 20px #22d3ee80); }
        }
        .logo-file-body {
          stroke-dasharray: 160;
          stroke-dashoffset: 160;
          animation: logoDraw 1.2s ease-out 0.3s forwards;
        }
        .logo-fold {
          stroke-dasharray: 40;
          stroke-dashoffset: 40;
          animation: logoDraw 0.6s ease-out 0.9s forwards;
        }
        @keyframes logoDraw {
          to { stroke-dashoffset: 0; }
        }
        .logo-check {
          stroke-dasharray: 30;
          stroke-dashoffset: 30;
          animation: logoDraw 0.5s ease-out 1.5s forwards;
        }

        .splash-title {
          margin: 0;
        }
        .splash-title-text {
          font-size: 2.5rem;
          font-weight: 800;
          letter-spacing: -0.02em;
          background: linear-gradient(135deg, #22d3ee 0%, #a78bfa 40%, #d946ef 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          position: relative;
        }
        .splash-title-text::after {
          content: attr(data-text);
          position: absolute;
          left: 2px;
          top: 0;
          background: linear-gradient(135deg, #d946ef 0%, #22d3ee 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          opacity: 0.3;
          animation: titleGlitch 3s ease-in-out infinite;
        }
        @keyframes titleGlitch {
          0%, 94%, 100% { transform: translate(0); opacity: 0.3; }
          95% { transform: translate(-3px, 1px); opacity: 0.6; }
          96% { transform: translate(2px, -2px); opacity: 0.4; }
          97% { transform: translate(-1px, -1px); opacity: 0.7; }
          98% { transform: translate(2px, 2px); opacity: 0.2; }
        }

        .splash-subtitle {
          margin: 0.5rem 0 0;
          font-size: 0.9rem;
          color: rgba(255,255,255,0.3);
          letter-spacing: 0.15em;
        }

        .splash-tap-hint {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 0.75rem;
        }
        .splash-tap-ring {
          width: 56px;
          height: 56px;
          border-radius: 50%;
          border: 1.5px solid rgba(255,255,255,0.15);
          transition: transform 0.4s cubic-bezier(0.25, 1, 0.5, 1), border-color 0.4s ease;
          animation: tapPulse 2s ease-in-out infinite;
        }
        @keyframes tapPulse {
          0%, 100% { box-shadow: 0 0 0 0 rgba(34,211,238,0); }
          50% { box-shadow: 0 0 0 8px rgba(34,211,238,0.08); }
        }
        .splash-tap-label {
          font-size: 0.85rem;
          color: rgba(255,255,255,0.35);
          letter-spacing: 0.1em;
          transition: color 0.4s ease;
        }

        .particle {
          position: absolute;
          width: 2px;
          height: 2px;
          background: #22d3ee;
          border-radius: 50%;
          animation: particleFloat linear infinite;
        }
        @keyframes particleFloat {
          0% { transform: translateY(0) translateX(0) scale(1); opacity: 0; }
          10% { opacity: 1; }
          90% { opacity: 1; }
          100% { transform: translateY(-100vh) translateX(40px) scale(0.3); opacity: 0; }
        }
      `}</style>
    </div>
  )
}

/** 粒子背景 */
function ParticleField() {
  const count = 40
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {Array.from({ length: count }).map((_, i) => (
        <div
          key={i}
          className="particle"
          style={{
            left: `${Math.random() * 100}%`,
            bottom: '-10px',
            width: `${1 + Math.random() * 2}px`,
            height: `${1 + Math.random() * 2}px`,
            animationDuration: `${4 + Math.random() * 8}s`,
            animationDelay: `${Math.random() * 8}s`,
            background: Math.random() > 0.5 ? '#22d3ee' : '#d946ef',
          }}
        />
      ))}
    </div>
  )
}
