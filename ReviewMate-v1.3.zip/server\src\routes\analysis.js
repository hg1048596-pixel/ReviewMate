const express = require('express');
const { getDb } = require('../db/init');
const analyst = require('../services/analyst');

const router = express.Router();

// GET /api/analysis/stats - 获取统计数据
router.get('/stats', (req, res) => {
  let db;
  try {
    db = getDb();
    const { start, end } = req.query;
    let records;
    if (start && end) {
      records = db.prepare('SELECT * FROM work_records WHERE date >= ? AND date <= ?').all(start, end);
    } else if (start) {
      records = db.prepare('SELECT * FROM work_records WHERE date >= ?').all(start);
    } else {
      records = db.prepare('SELECT * FROM work_records ORDER BY date DESC LIMIT 500').all();
    }

    const stats = analyst.analyze(records);
    res.json(stats);
  } catch (e) {
    res.status(500).json({ error: e.message });
  } finally {
    if (db) db.close();
  }
});

// GET /api/analysis/trends - 获取趋势数据（每周统计）
router.get('/trends', (req, res) => {
  let db;
  try {
    db = getDb();
    const { weeks } = req.query;
    const numWeeks = parseInt(weeks) || 12;

    // 从 performance_metrics 表获取历史趋势
    const metrics = db.prepare(
      'SELECT * FROM performance_metrics WHERE period_type = ? ORDER BY period_start DESC LIMIT ?'
    ).all('weekly', numWeeks);

    // 如果没有历史数据，从 work_records 按周聚合
    if (metrics.length === 0) {
      const trends = [];

      for (let i = numWeeks - 1; i >= 0; i--) {
        const now = new Date();
        const end = new Date(now);
        end.setDate(end.getDate() - i * 7);
        const start = new Date(end);
        start.setDate(start.getDate() - 6);

        const s = start.toISOString().split('T')[0];
        const e = end.toISOString().split('T')[0];

        const records = db.prepare(
          'SELECT * FROM work_records WHERE date >= ? AND date <= ?'
        ).all(s, e);

        const stats = analyst.analyze(records);
        trends.push({
          period_start: s, period_end: e,
          total_tasks: stats.total_tasks, completed_tasks: stats.completed_tasks,
          total_hours: stats.total_hours, completion_rate: stats.completion_rate,
          output_density: stats.output_density
        });
      }
      return res.json(trends);
    }

    res.json(metrics.map(m => ({
      ...m,
      tag_distribution: JSON.parse(m.tag_distribution || '{}'),
      highlights: JSON.parse(m.highlights || '[]'),
      lowlights: JSON.parse(m.lowlights || '[]')
    })));
  } catch (e) {
    res.status(500).json({ error: e.message });
  } finally {
    if (db) db.close();
  }
});

// POST /api/analysis/compare - 对比两个周期的数据
router.post('/compare', (req, res) => {
  let db;
  try {
    db = getDb();
    const { start1, end1, start2, end2 } = req.body;

    const records1 = db.prepare('SELECT * FROM work_records WHERE date >= ? AND date <= ?').all(start1, end1);
    const records2 = db.prepare('SELECT * FROM work_records WHERE date >= ? AND date <= ?').all(start2, end2);

    const current = analyst.analyze(records1);
    const previous = analyst.analyze(records2);
    const comparison = analyst.compareStats(current, previous);

    res.json({ current, previous, comparison });
  } catch (e) {
    res.status(500).json({ error: e.message });
  } finally {
    if (db) db.close();
  }
});

module.exports = router;
