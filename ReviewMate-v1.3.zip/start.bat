@echo off
title ReviewMate

echo ============================
echo   ReviewMate v1.0
echo ============================
echo.

:: Check Node.js
where node >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Node.js not found. Please install Node.js 22 LTS
    echo Download: https://nodejs.org
    pause
    exit /b 1
)

:: Switch to server directory
pushd "%~dp0server"
if %errorlevel% neq 0 (
    echo [ERROR] Cannot enter server directory
    pause
    exit /b 1
)

:: Install dependencies on first run
if not exist "node_modules" (
    echo [1/2] Installing dependencies, please wait...
    call npm install
    if %errorlevel% neq 0 (
        echo [ERROR] Dependency install failed
        pause
        exit /b 1
    )
    echo.
)

echo [2/2] Starting server...
echo.
start http://localhost:3001
node src/index.js

pause
popd