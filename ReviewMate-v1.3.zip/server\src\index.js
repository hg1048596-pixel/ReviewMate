const express = require('express');
const cors = require('cors');
const path = require('path');
const { initDb } = require('./db/init');

const app = express();
const PORT = process.env.PORT || 3001;

// 中间件
app.use(cors());
app.use(express.json({ limit: '10mb' }));

// 初始化数据库
initDb();

// 路由
app.use('/api/work-records', require('./routes/workRecords'));
app.use('/api/analysis', require('./routes/analysis'));
app.use('/api/reports', require('./routes/reports'));
app.use('/api/metrics', require('./routes/metrics'));
app.use('/api/goals', require('./routes/goals'));
app.use('/api/settings', require('./routes/settings'));
app.use('/api/ai', require('./routes/ai'));
app.use('/api/feishu', require('./routes/feishu'));

// 静态文件（生产环境提供前端构建产物）
const clientDist = path.join(__dirname, '..', '..', 'client', 'dist');
app.use(express.static(clientDist));
app.get('*', (req, res) => {
  if (!req.path.startsWith('/api')) {
    res.sendFile(path.join(clientDist, 'index.html'));
  }
});

// 启动服务
const server = app.listen(PORT, () => {
  console.log(`ReviewMate 服务已启动: http://localhost:${PORT}`);
});
// Node.js HTTP Server 默认 2 分钟超时，AI 报告生成可能更久，设为 10 分钟
server.timeout = 600000;
server.headersTimeout = 610000; // 略大于 timeout，避免头解析超时先于请求超时

module.exports = app;
