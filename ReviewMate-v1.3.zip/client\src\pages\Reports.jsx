import { useState, useEffect } from 'react'
import { api } from '../api'
import { FileText, Download, Trash2, Eye } from 'lucide-react'
import ReactMarkdown from 'react-markdown'
import ErrorBoundary from '../components/ErrorBoundary'

const weekStart = (d) => { const n = new Date(d); n.setDate(n.getDate() - n.getDay() + 1); return n.toISOString().split('T')[0] }
const weekEnd = (d) => { const n = new Date(d); n.setDate(n.getDate() - n.getDay() + 7); return n.toISOString().split('T')[0] }
const today = () => new Date().toISOString().split('T')[0]
const monthStart = () => today().slice(0, 8) + '01'
const quarterStart = () => { const m = new Date().getMonth(); return `${today().slice(0,5)}-${String(Math.floor(m/3)*3+1).padStart(2,'0')}-01` }

export default function Reports() {
  const [reports, setReports] = useState([])
  const [loading, setLoading] = useState(true)
  const [loadError, setLoadError] = useState('')
  const [reportType, setReportType] = useState('weekly')
  const [startDate, setStartDate] = useState(weekStart(new Date()))
  const [endDate, setEndDate] = useState(today())
  const [generating, setGenerating] = useState(false)
  const [currentReport, setCurrentReport] = useState(null)
  const [viewingReport, setViewingReport] = useState(null)
  const [includeFiles, setIncludeFiles] = useState(false)
  const [dirPath, setDirPath] = useState('')
  const [deletingId, setDeletingId] = useState(null)

  useEffect(() => { loadReports() }, [])

  const loadReports = async (showLoading = true) => {
    if (showLoading) setLoading(true)
    setLoadError('')
    try {
      const res = await api.getReports({ limit: 20 })
      setReports(res.data)
    } catch (e) {
      console.error('加载报告列表失败:', e)
      if (showLoading) setLoadError(e.message || '加载失败')
    } finally {
      if (showLoading) setLoading(false)
    }
  }

  const handleTypeChange = (type) => {
    setReportType(type)
    const now = new Date()
    switch (type) {
      case 'weekly': setStartDate(weekStart(now)); setEndDate(today()); break
      case 'monthly': setStartDate(monthStart()); setEndDate(today()); break
      case 'summary': setStartDate(quarterStart()); setEndDate(today()); break
    }
  }

  const handleGenerate = async () => {
    setGenerating(true)
    setCurrentReport(null)
    try {
      const report = await api.generateReport({
        reportType, startDate, endDate,
        includeFiles, dirPath: includeFiles ? dirPath : undefined
      })
      console.log('报告生成成功, content 长度:', report.content?.length, 'title:', report.title)
      setCurrentReport(report)
    } catch (e) {
      console.error('报告生成失败:', e)
      alert('生成失败: ' + (e.message || '未知错误'))
    } finally {
      setGenerating(false)
    }
    // 后台刷新列表，不阻塞界面、失败也不弹窗
    loadReports(false).catch(e => console.error('刷新报告列表失败:', e))
  }

  const handleView = async (id) => {
    try {
      const r = await api.getReportDetail(id)
      setViewingReport(r)
    } catch (e) { console.error('查看报告失败:', e); alert('查看失败: ' + (e.message || '未知错误')) }
  }

  const handleDelete = async (id) => {
    if (!confirm('确认删除此报告？')) return
    setDeletingId(id)
    try {
      await api.deleteReport(id)
      // 乐观更新：立即从列表中移除
      setReports(prev => prev.filter(r => r.id !== id))
      // 后台刷新列表确保数据一致
      await loadReports()
    } catch (e) {
      console.error('删除报告失败:', e)
      alert('删除失败: ' + (e.message || '未知错误'))
    } finally {
      setDeletingId(null)
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">复盘报告</h2>
          <p className="text-sm text-slate-500 mt-1">生成和查看复盘报告</p>
        </div>
      </div>

      {/* 报告生成区 */}
      <div className="bg-white rounded-xl border border-slate-200 p-5">
        <h3 className="text-sm font-semibold text-slate-700 mb-4">生成新报告</h3>
        <div className="grid grid-cols-4 gap-4 mb-4">
          <div>
            <label className="block text-xs text-slate-500 mb-1">报告类型</label>
            <div className="flex gap-1">
              {[
                { value: 'weekly', label: '周报' },
                { value: 'monthly', label: '月报' },
                { value: 'summary', label: '工作总结' },
              ].map(t => (
                <button key={t.value} onClick={() => handleTypeChange(t.value)}
                  className={`flex-1 px-3 py-2 text-sm rounded-md border ${reportType === t.value ? 'bg-primary-50 border-primary-300 text-primary-600 font-medium' : 'border-slate-200 text-slate-500 hover:bg-slate-50'}`}>
                  {t.label}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="block text-xs text-slate-500 mb-1">开始日期</label>
            <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="w-full border border-slate-300 rounded-md px-3 py-2 text-sm" />
          </div>
          <div>
            <label className="block text-xs text-slate-500 mb-1">结束日期</label>
            <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} className="w-full border border-slate-300 rounded-md px-3 py-2 text-sm" />
          </div>
          <div className="flex items-end">
            <button onClick={handleGenerate} disabled={generating}
              className="w-full px-4 py-2 text-sm bg-primary-500 text-white rounded-lg hover:bg-primary-600 disabled:opacity-50">
              {generating ? '生成中...' : '生成报告'}
            </button>
          </div>
        </div>
        {/* 文件扫描选项 */}
        <div className="flex items-center gap-4 text-sm">
          <label className="flex items-center gap-2 cursor-pointer">
            <input type="checkbox" checked={includeFiles} onChange={e => setIncludeFiles(e.target.checked)} className="rounded" />
            <span className="text-slate-600">同时扫描工作文件目录</span>
          </label>
          {includeFiles && (
            <input type="text" value={dirPath} onChange={e => setDirPath(e.target.value)}
              className="flex-1 border border-slate-300 rounded-md px-3 py-1.5 text-sm" placeholder="输入工作目录路径，如 C:\Users\xxx\work-logs" />
          )}
        </div>
      </div>

      {/* 当前生成的报告预览 */}
      {currentReport && (
        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-slate-700 flex items-center gap-2">
              <FileText size={16} className="text-primary-500" /> {currentReport.title}
            </h3>
            <div className="flex gap-2">
              <button onClick={() => {
                if (!currentReport.content) return
                const blob = new Blob([currentReport.content], { type: 'text/markdown' })
                const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `${currentReport.title || 'report'}.md`; a.click()
              }} className="flex items-center gap-1 px-3 py-1.5 text-xs border border-slate-300 rounded-md hover:bg-slate-50">
                <Download size={12} /> 导出MD
              </button>
            </div>
          </div>
          <div className="prose prose-sm max-w-none prose-headings:text-slate-800 prose-p:text-slate-600 prose-strong:text-slate-700">
            {currentReport.content && typeof currentReport.content === 'string' ? (
              <ErrorBoundary key={currentReport.content.slice(0, 50)}>
                <ReactMarkdown>{currentReport.content}</ReactMarkdown>
              </ErrorBoundary>
            ) : (
              <p className="text-slate-400 text-sm">报告内容为空，请重新生成</p>
            )}
          </div>
        </div>
      )}

      {/* 历史报告列表 */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <div className="p-4 border-b border-slate-100">
          <h3 className="text-sm font-semibold text-slate-700">历史报告</h3>
        </div>
        <table className="w-full text-sm">
          <thead className="bg-slate-50 border-b border-slate-200">
            <tr>
              <th className="text-left px-4 py-3 font-medium text-slate-500">标题</th>
              <th className="text-left px-4 py-3 font-medium text-slate-500">类型</th>
              <th className="text-left px-4 py-3 font-medium text-slate-500">周期</th>
              <th className="text-left px-4 py-3 font-medium text-slate-500">生成时间</th>
              <th className="text-left px-4 py-3 font-medium text-slate-500">操作</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={5} className="text-center py-8 text-slate-400">加载中...</td></tr>
            ) : loadError ? (
              <tr><td colSpan={5} className="text-center py-8 text-red-500">
                <p>加载失败: {loadError}</p>
                <button onClick={loadReports} className="mt-2 px-4 py-2 text-sm bg-primary-500 text-white rounded-lg hover:bg-primary-600">重试</button>
              </td></tr>
            ) : reports.length === 0 ? (
              <tr><td colSpan={5} className="text-center py-8 text-slate-400">暂无报告，请先生成</td></tr>
            ) : (
              reports.map(r => (
                <tr key={r.id} className={`border-b border-slate-50 hover:bg-slate-50/50 ${deletingId === r.id ? 'opacity-50' : ''}`}>
                  <td className="px-4 py-3 text-slate-800 cursor-pointer hover:text-primary-600" onClick={() => handleView(r.id)}>{r.title}</td>
                  <td className="px-4 py-3">
                    <span className="px-2 py-0.5 text-xs rounded-full bg-primary-50 text-primary-600">
                      {{ weekly: '周报', monthly: '月报', summary: '总结' }[r.report_type] || r.report_type}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-slate-500">{r.period_start} ~ {r.period_end}</td>
                  <td className="px-4 py-3 text-slate-400">{r.created_at}</td>
                  <td className="px-4 py-3">
                    <div className="flex gap-2">
                      <button onClick={() => handleView(r.id)} className="text-slate-400 hover:text-primary-500"><Eye size={14} /></button>
                      <button onClick={() => handleDelete(r.id)} disabled={deletingId === r.id} className="text-slate-400 hover:text-red-500 disabled:opacity-30"><Trash2 size={14} /></button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* 查看报告详情弹窗 */}
      {viewingReport && (
        <div className="fixed inset-0 bg-black/30 flex items-center justify-center z-50" onClick={() => setViewingReport(null)}>
          <div className="bg-white rounded-xl p-6 w-full max-w-3xl max-h-[80vh] overflow-auto shadow-xl" onClick={e => e.stopPropagation()}>
            <h3 className="text-lg font-semibold mb-4">{viewingReport.title}</h3>
            <div className="prose prose-sm max-w-none">
              {viewingReport.content && typeof viewingReport.content === 'string' ? (
                <ErrorBoundary key={viewingReport.content.slice(0, 50)}>
                  <ReactMarkdown>{viewingReport.content}</ReactMarkdown>
                </ErrorBoundary>
              ) : (
                <p className="text-slate-400 text-sm">报告内容为空</p>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
