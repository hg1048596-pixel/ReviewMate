/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: { 50: '#e8f0fe', 100: '#d2e3fc', 200: '#a8c7fa', 300: '#7baaf7', 400: '#4e8df4', 500: '#1a73e8', 600: '#1557b0', 700: '#0f3d7a', 800: '#0a284d', 900: '#051526' },
        teal: { 50: '#e6faf5', 100: '#ccf5eb', 500: '#0d9488', 600: '#0f766e', 700: '#115e59' }
      },
      // 精调缓动曲线（仅 GPU 属性：transform + opacity）
      transitionTimingFunction: {
        'out-quart': 'cubic-bezier(0.25, 1, 0.5, 1)',
        'out-expo': 'cubic-bezier(0.16, 1, 0.3, 1)',
        'in-out-quart': 'cubic-bezier(0.65, 0, 0.35, 1)',
      },
      animation: {
        // 入场动画 — 终止在可见状态，fail-open
        'enter-up': 'enterUp 500ms cubic-bezier(0.25, 1, 0.5, 1) both',
        'enter-fade': 'enterFade 400ms cubic-bezier(0.25, 1, 0.5, 1) both',
        'enter-left': 'enterLeft 500ms cubic-bezier(0.25, 1, 0.5, 1) both',
        'enter-right': 'enterRight 500ms cubic-bezier(0.25, 1, 0.5, 1) both',
        'enter-scale': 'enterScale 450ms cubic-bezier(0.25, 1, 0.5, 1) both',
        'shimmer': 'shimmer 2.5s ease-in-out infinite',
      },
      keyframes: {
        enterUp: {
          '0%': { opacity: '0', transform: 'translateY(20px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        enterFade: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        enterLeft: {
          '0%': { opacity: '0', transform: 'translateX(-24px)' },
          '100%': { opacity: '1', transform: 'translateX(0)' },
        },
        enterRight: {
          '0%': { opacity: '0', transform: 'translateX(24px)' },
          '100%': { opacity: '1', transform: 'translateX(0)' },
        },
        enterScale: {
          '0%': { opacity: '0', transform: 'scale(0.92)' },
          '100%': { opacity: '1', transform: 'scale(1)' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
      },
    }
  },
  plugins: []
}
