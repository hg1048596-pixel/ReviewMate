const express = require('express');
const { getDb, createTables, backupDb, reloadConfig, getCurrentDbPath } = require('../db/init');
const fs = require('fs');
const path = require('path');
const { exec, spawn } = require('child_process');

const router = express.Router();

// 敏感字段列表 — 返回给前端时脱敏
const SENSITIVE_KEYS = ['ai_api_key', 'feishu_app_secret']

// 辅助：写入 db-config.json
function writeDbConfig(dbPath) {
  const configPath = path.join(__dirname, '..', '..', 'db-config.json');
  fs.writeFileSync(configPath, JSON.stringify({ db_path: path.resolve(dbPath) }, null, 2));
}

// GET /api/settings - 获取所有设置（敏感字段脱敏）
router.get('/', (req, res) => {
  let db;
  try {
    db = getDb();
    const settings = db.prepare('SELECT * FROM settings').all();
    const result = {};
    for (const s of settings) {
      try { result[s.key] = JSON.parse(s.value); } catch (e) { result[s.key] = s.value; }
    }
    // 敏感字段脱敏：仅返回前4位+星号，前端可据此判断是否已配置
    for (const key of SENSITIVE_KEYS) {
      if (result[key] && typeof result[key] === 'string' && result[key].length > 8) {
        result[key] = result[key].slice(0, 4) + '*'.repeat(Math.min(result[key].length - 4, 20))
      }
    }
    res.json(result);
  } catch (e) {
    res.status(500).json({ error: e.message });
  } finally {
    if (db) db.close();
  }
});

// PUT /api/settings/:key - 更新单个设置
router.put('/:key', (req, res) => {
  let db;
  try {
    db = getDb();
    const value = typeof req.body.value === 'string' ? req.body.value : JSON.stringify(req.body.value);
    db.prepare(
      'INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)'
    ).run(req.params.key, value);
    res.json({ key: req.params.key, value: req.body.value });
  } catch (e) {
    res.status(500).json({ error: e.message });
  } finally {
    if (db) db.close();
  }
});

// GET /api/settings/db-info - 获取数据库信息（含表统计）
router.get('/db-info', (req, res) => {
  let db;
  try {
    const dbPath = getCurrentDbPath();
    const stat = fs.statSync(dbPath);
    db = getDb();

    // 统计各表行数
    const tables = {};
    const tableList = ['work_records', 'performance_metrics', 'goals', 'review_reports', 'settings'];
    for (const t of tableList) {
      try {
        tables[t] = db.prepare(`SELECT COUNT(*) as c FROM ${t}`).get().c;
      } catch (_) {
        tables[t] = 0;
      }
    }

    res.json({
      path: path.resolve(dbPath),
      dir: path.dirname(path.resolve(dbPath)),
      fileName: path.basename(dbPath),
      sizeMB: (stat.size / (1024 * 1024)).toFixed(2),
      sizeBytes: stat.size,
      modifiedAt: stat.mtime.toISOString(),
      tables,
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  } finally {
    if (db) db.close();
  }
});

// POST /api/settings/move-db - 迁移数据库到新位置（使用 backup API 安全复制）
router.post('/move-db', (req, res) => {
  try {
    const { newPath } = req.body;
    if (!newPath) return res.status(400).json({ error: 'newPath 为必填项' });

    const absNewPath = path.resolve(newPath);
    const oldPath = getCurrentDbPath();

    // 检查目标路径是否和当前路径相同
    if (absNewPath === path.resolve(oldPath)) {
      return res.status(400).json({ error: '目标路径与当前数据库路径相同' });
    }

    // 检查目标文件是否已存在
    if (fs.existsSync(absNewPath)) {
      return res.status(409).json({ error: '目标路径已存在文件，请选择其他位置' });
    }

    // 使用 SQLite backup API 安全复制（保证数据完整性，避免锁冲突）
    backupDb(absNewPath);

    // 更新配置并热重载
    writeDbConfig(absNewPath);
    reloadConfig();

    res.json({
      success: true,
      oldPath: path.resolve(oldPath),
      newPath: absNewPath,
      message: `数据库已迁移到 ${absNewPath}，已自动生效。`,
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// POST /api/settings/open-db-folder - 打开数据库所在文件夹
router.post('/open-db-folder', (req, res) => {
  try {
    const dir = path.dirname(path.resolve(getCurrentDbPath()));
    const cmd = process.platform === 'win32'
      ? `start "" "${dir}"`
      : process.platform === 'darwin'
        ? `open "${dir}"`
        : `xdg-open "${dir}"`;
    exec(cmd, (err) => {
      if (err) {
        return res.status(500).json({ error: `无法打开文件夹: ${err.message}` });
      }
      res.json({ success: true, path: dir });
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// GET /api/settings/download-path - 获取当前下载路径
router.get('/download-path', (req, res) => {
  try {
    const docGen = require('../services/documentGenerator');
    const dir = docGen.getOutputDir();
    res.json({ path: dir });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// POST /api/settings/open-download-folder - 打开下载文件夹
router.post('/open-download-folder', (req, res) => {
  try {
    const docGen = require('../services/documentGenerator');
    const dir = docGen.getOutputDir();
    // 确保目录存在
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    const cmd = process.platform === 'win32'
      ? `start "" "${dir}"`
      : process.platform === 'darwin'
        ? `open "${dir}"`
        : `xdg-open "${dir}"`;
    exec(cmd, (err) => {
      if (err) {
        return res.status(500).json({ error: `无法打开文件夹: ${err.message}` });
      }
      res.json({ success: true, path: dir });
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// POST /api/settings/new-db - 新建空数据库（复用 createTables）
router.post('/new-db', (req, res) => {
  let db;
  try {
    const { path: newPath } = req.body;
    if (!newPath) return res.status(400).json({ error: 'path 为必填项' });

    const absPath = path.resolve(newPath);
    const dir = path.dirname(absPath);

    // 确保目录存在
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    // 检查文件是否已存在
    if (fs.existsSync(absPath)) {
      return res.status(409).json({ error: '目标文件已存在，请使用"切换数据库"或"迁移数据库"' });
    }

    // 创建新数据库并初始化表结构（复用共享建表函数）
    const Database = require('better-sqlite3');
    db = new Database(absPath);
    db.pragma('journal_mode = WAL');
    db.pragma('foreign_keys = ON');
    createTables(db);
    db.close();
    db = null;

    // 更新配置并热重载
    writeDbConfig(absPath);
    reloadConfig();

    res.json({
      success: true,
      path: absPath,
      message: `已创建新数据库 ${absPath}，已自动切换生效。`,
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  } finally {
    if (db) try { db.close(); } catch (_) { /* already closed */ }
  }
});

// POST /api/settings/switch-db - 切换到已有数据库
router.post('/switch-db', (req, res) => {
  try {
    const { path: targetPath } = req.body;
    if (!targetPath) return res.status(400).json({ error: 'path 为必填项' });

    const absPath = path.resolve(targetPath);

    // 检查文件是否存在
    if (!fs.existsSync(absPath)) {
      return res.status(404).json({ error: `数据库文件不存在: ${absPath}` });
    }

    // 更新配置并热重载
    writeDbConfig(absPath);
    reloadConfig();

    res.json({
      success: true,
      path: absPath,
      message: `已切换到数据库 ${absPath}，已自动生效。`,
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// POST /api/settings/reload-config - 手动重载配置（从 db-config.json 重新读取）
router.post('/reload-config', (req, res) => {
  try {
    const newPath = reloadConfig();
    if (!newPath) {
      return res.status(400).json({ error: '配置文件不存在或无效' });
    }
    res.json({ success: true, path: newPath, message: '配置已重载' });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// POST /api/settings/restart - 重启服务（降级方案，热重载失败时使用）
router.post('/restart', (req, res) => {
  const entryPath = path.resolve(__dirname, '..', 'index.js');
  res.json({ success: true, message: '后端服务正在重启...' });
  setTimeout(() => {
    console.log('收到重启请求，正在退出并重启进程...');
    // 启动新的独立进程来接替服务，然后退出当前进程
    const child = spawn(process.execPath, [entryPath], {
      cwd: path.resolve(__dirname, '..'),
      detached: true,
      stdio: 'inherit',
    });
    child.unref();
    process.exit(0);
  }, 500);
});

module.exports = router;
