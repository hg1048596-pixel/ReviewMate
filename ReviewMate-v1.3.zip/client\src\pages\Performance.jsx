import { useState, useEffect } from 'react'
import { api } from '../api'
import { BarChart3, TrendingUp, Target, PieChart } from 'lucide-react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart as RPie, Pie, Cell } from 'recharts'

const COLORS = ['#1a73e8', '#0d9488', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4', '#84cc16', '#ec4899']

export default function Performance() {
  const [metrics, setMetrics] = useState([])
  const [stats, setStats] = useState(null)
  const [loading, setLoading] = useState(true)
  const [weeks, setWeeks] = useState(12)

  useEffect(() => {
    Promise.all([
      api.getMetrics({ type: 'weekly', limit: weeks }),
      api.getStats({})
    ]).then(([m, s]) => {
      setMetrics(m)
      setStats(s)
    }).catch(console.error).finally(() => setLoading(false))
  }, [weeks])

  if (loading) return <div className="flex items-center justify-center h-64 text-slate-400">加载中...</div>

  const reversed = [...metrics].reverse()
  const completionData = reversed.map((m, i) => ({ name: m.period_start?.slice(5) || `W${i+1}`, 完成率: Math.round(m.completion_rate * 100) }))
  const hoursData = reversed.map(m => ({ name: m.period_start?.slice(5) || '', 投入工时: m.total_hours }))
  const tagData = stats?.tag_distribution ? Object.entries(stats.tag_distribution).map(([name, value]) => ({ name, value })) : []

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">绩效看板</h2>
          <p className="text-sm text-slate-500 mt-1">历史绩效指标追踪与趋势分析</p>
        </div>
        <select value={weeks} onChange={e => setWeeks(parseInt(e.target.value))} className="border border-slate-300 rounded-md px-3 py-1.5 text-sm">
          <option value={4}>近4周</option>
          <option value={8}>近8周</option>
          <option value={12}>近12周</option>
          <option value={24}>近24周</option>
        </select>
      </div>

      {/* 概要卡片 */}
      {stats && (
        <div className="grid grid-cols-4 gap-4">
          <MetricCard icon={<BarChart3 size={18} />} label="累计任务" value={stats.total_tasks} color="blue" />
          <MetricCard icon={<Target size={18} />} label="完成率" value={`${Math.round(stats.completion_rate * 100)}%`} color="teal" />
          <MetricCard icon={<TrendingUp size={18} />} label="产出密度" value={`${stats.output_density}项/天`} color="amber" />
          <MetricCard icon={<PieChart size={18} />} label="工作天数" value={`${stats.work_days}天`} color="purple" />
        </div>
      )}

      {/* 趋势图 */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <h3 className="text-sm font-semibold text-slate-700 mb-4">完成率趋势</h3>
          <ResponsiveContainer width="100%" height={240}>
            <LineChart data={completionData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="name" tick={{ fontSize: 11 }} stroke="#94a3b8" />
              <YAxis domain={[0, 100]} tick={{ fontSize: 11 }} stroke="#94a3b8" />
              <Tooltip formatter={(v) => `${v}%`} />
              <Line type="monotone" dataKey="完成率" stroke="#1a73e8" strokeWidth={2} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <h3 className="text-sm font-semibold text-slate-700 mb-4">工时投入趋势</h3>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={hoursData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="name" tick={{ fontSize: 11 }} stroke="#94a3b8" />
              <YAxis tick={{ fontSize: 11 }} stroke="#94a3b8" />
              <Tooltip formatter={(v) => `${v}h`} />
              <Bar dataKey="投入工时" fill="#0d9488" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* 标签分布 + 指标明细表 */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <h3 className="text-sm font-semibold text-slate-700 mb-4">工作类型分布</h3>
          {tagData.length > 0 ? (
            <div className="flex items-center">
              <ResponsiveContainer width="55%" height={180}>
                <RPie>
                  <Pie data={tagData} cx="50%" cy="50%" innerRadius={40} outerRadius={70} paddingAngle={2} dataKey="value">
                    {tagData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                  </Pie>
                </RPie>
              </ResponsiveContainer>
              <div className="space-y-1.5 text-sm">
                {tagData.map((t, i) => (
                  <div key={t.name} className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-sm" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                    <span className="text-slate-600">{t.name}: {t.value}项</span>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-center h-40 text-sm text-slate-400">暂无数据</div>
          )}
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <h3 className="text-sm font-semibold text-slate-700 mb-4">历史指标明细</h3>
          <div className="overflow-auto max-h-52">
            <table className="w-full text-sm">
              <thead className="border-b border-slate-100">
                <tr>
                  <th className="text-left py-2 text-slate-400 font-medium">周期</th>
                  <th className="text-right py-2 text-slate-400 font-medium">任务数</th>
                  <th className="text-right py-2 text-slate-400 font-medium">完成率</th>
                  <th className="text-right py-2 text-slate-400 font-medium">工时</th>
                </tr>
              </thead>
              <tbody>
                {metrics.length === 0 ? (
                  <tr><td colSpan={4} className="text-center py-6 text-slate-400">暂无历史数据</td></tr>
                ) : (
                  metrics.map(m => (
                    <tr key={m.id} className="border-b border-slate-50">
                      <td className="py-2 text-slate-600">{m.period_start} ~ {m.period_end}</td>
                      <td className="py-2 text-right text-slate-600">{m.completed_tasks}/{m.total_tasks}</td>
                      <td className="py-2 text-right">
                        <span className={m.completion_rate >= 0.8 ? 'text-green-600' : m.completion_rate >= 0.6 ? 'text-amber-600' : 'text-red-500'}>
                          {Math.round(m.completion_rate * 100)}%
                        </span>
                      </td>
                      <td className="py-2 text-right text-slate-600">{Number(m.total_hours).toFixed(2)}h</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  )
}

function MetricCard({ icon, label, value, color }) {
  const borders = { blue: 'border-l-primary-500', teal: 'border-l-teal-500', amber: 'border-l-amber-500', purple: 'border-l-purple-500' }
  const texts = { blue: 'text-primary-500', teal: 'text-teal-500', amber: 'text-amber-500', purple: 'text-purple-500' }
  return (
    <div className={`bg-white rounded-xl border border-slate-200 border-l-4 ${borders[color]} p-4`}>
      <div className="flex items-center justify-between mb-1"><span className="text-xs text-slate-400">{label}</span><span className={texts[color]}>{icon}</span></div>
      <div className="text-xl font-bold text-slate-800">{value}</div>
    </div>
  )
}
